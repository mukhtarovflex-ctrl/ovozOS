const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_123";
const BOB_UID = "bob_uid_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function pastDate(msOffset = 2000) {
  return new Date(Date.now() - msOffset);
}

function validUserProfile(uid, ts = pastDate(5000)) {
  return {
    userId: uid,
    displayName: "Sardor",
    onboardingDone: true,
    language: "uz",
    aiResponseLang: "auto",
    primaryCurrency: "UZS",
    themeMode: "system",
    textScale: "standard",
    accentPreset: "emerald",
    density: "comfortable",
    dateFormat: "dd.MM.yyyy",
    hideBalances: false,
    initialBalanceUzs: 1000000,
    initialBalanceUsd: 0,
    initialBalanceEur: 0,
    initialBalanceRub: 0,
    dashboardOrder: ["summary", "tasks", "finance", "goals", "debts", "recent"],
    hiddenCards: [],
    notifyAll: true,
    notifyTasks: true,
    notifyDebts: true,
    notifyGoals: true,
    notifyEvening: true,
    eveningReviewHour: 21,
    eveningReviewMinute: 0,
    notifyReports: true,
    notifySound: true,
    voiceSpokenReply: false,
    aiResponseLength: "standard",
    autoSaveVoice: false,
    keepVoiceTranscripts: true,
    pinLockEnabled: false,
    createdAt: ts,
    updatedAt: ts,
  };
}

function validTask(ts = pastDate(5000)) {
  return {
    title: "Taqdimotni topshirish",
    description: "Juma soat 15:00 da",
    dueDateMillis: Date.now() + 86400000,
    hasDueTime: true,
    priority: "high",
    category: "Ish",
    recurrence: "none",
    completed: false,
    completedAtMillis: 0,
    personId: "",
    personName: "",
    goalId: "",
    noteText: "",
    reminderEnabled: true,
    createdAt: ts,
    updatedAt: ts,
  };
}

function validTransaction(ts = pastDate(5000)) {
  return {
    kind: "expense",
    amount: 60000,
    currency: "UZS",
    category: "Oziq-ovqat",
    title: "Tushlik",
    note: "",
    occurredAtMillis: Date.now(),
    personId: "",
    personName: "",
    goalId: "",
    debtId: "",
    createdAt: ts,
    updatedAt: ts,
  };
}

function validDebt(ts = pastDate(5000)) {
  return {
    direction: "borrowed",
    personId: "person_anvar",
    personName: "Anvar",
    originalAmount: 500000,
    paidAmount: 0,
    currency: "UZS",
    note: "Qarz",
    issuedAtMillis: Date.now(),
    dueDateMillis: 0,
    closed: false,
    closedAtMillis: 0,
    createdAt: ts,
    updatedAt: ts,
  };
}

function validGoal(ts = pastDate(5000)) {
  return {
    title: "Yangi noutbuk",
    description: "Yanvargacha yig'ish",
    goalType: "financial",
    targetValue: 5000000,
    currentValue: 500000,
    unit: "UZS",
    currency: "UZS",
    startDateMillis: Date.now(),
    deadlineMillis: Date.now() + 2592000000,
    completed: false,
    createdAt: ts,
    updatedAt: ts,
  };
}

function validNote(ts = pastDate(5000)) {
  return {
    title: "Biznes g'oya",
    content: "Ovozli yordamchi ilovasi haqida fikr",
    category: "G'oya",
    colorTag: "emerald",
    pinned: false,
    archived: false,
    sourceVoice: true,
    linkedPersonId: "",
    linkedPersonName: "",
    linkedTaskId: "",
    linkedGoalId: "",
    createdAt: ts,
    updatedAt: ts,
  };
}

function validPerson(ts = pastDate(5000)) {
  return {
    name: "Anvar",
    phone: "+998901234567",
    note: "Do'st",
    avatarColor: "emerald",
    createdAt: ts,
    updatedAt: ts,
  };
}

function validActionLog(ts = pastDate(5000)) {
  return {
    batchId: "batch_001",
    actionType: "create",
    entityCollection: "tasks",
    entityId: "task_1",
    summaryText: "Taqdimot vazifasi yaratildi",
    beforeSummary: "",
    afterSummary: "Taqdimotni topshirish",
    beforeData: {},
    afterData: { title: "Taqdimotni topshirish" },
    sourceVoice: true,
    reverted: false,
    createdAt: ts,
  };
}

function validDailyReview(ts = pastDate(5000)) {
  return {
    dateKey: "2026-11-24",
    completedTasksCount: 3,
    pendingTasksCount: 1,
    completionPercent: 75,
    totalIncome: 0,
    totalExpense: 60000,
    currency: "UZS",
    topExpenseCategory: "Oziq-ovqat",
    aiSummary: "Bugun samarali kun bo'ldi.",
    tomorrowAdvice: "Ertaga muhim taqdimotdan boshlang.",
    createdAt: ts,
    updatedAt: ts,
  };
}

function validChatMessage(ts = pastDate(5000)) {
  return {
    role: "user",
    text: "Ertaga qanday rejalarim bor?",
    voiceInput: true,
    attachmentType: "none",
    createdAt: ts,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: denied across all collections", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauth.collection("users").doc(ALICE_UID).get());
  await assertFails(unauth.collection("users").doc(ALICE_UID).collection("tasks").get());
  await assertFails(
    unauth.collection("users").doc(ALICE_UID).collection("tasks").doc("t1").set(validTask())
  );
  await assertFails(unauth.collection("users").doc(ALICE_UID).collection("transactions").get());
  await assertFails(unauth.collection("users").doc(ALICE_UID).collection("debts").get());
});

test("UserProfile: owner create & partial update succeed; shadow fields & immutable edits fail", async () => {
  const alice = testEnv.authenticatedContext(ALICE_UID).firestore();
  const profileRef = alice.collection("users").doc(ALICE_UID);

  await assertSucceeds(profileRef.set(validUserProfile(ALICE_UID)));
  await assertSucceeds(profileRef.get());
  await assertSucceeds(
    profileRef.update({
      displayName: "Sardorbek",
      themeMode: "dark",
      updatedAt: pastDate(500),
    })
  );

  // Reject immutable createdAt modification
  await assertFails(
    profileRef.update({
      createdAt: pastDate(100),
      updatedAt: pastDate(100),
    })
  );

  // Reject shadow field
  await assertFails(
    profileRef.update({
      isAdmin: true,
      updatedAt: pastDate(100),
    })
  );

  // Reject future timestamp
  await assertFails(
    profileRef.update({
      displayName: "Future",
      updatedAt: new Date(Date.now() + 60000),
    })
  );
});

test("Cross-user isolation: Bob cannot read or write Alice's data", async () => {
  const alice = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bob = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(alice.collection("users").doc(ALICE_UID).set(validUserProfile(ALICE_UID)));
  await assertSucceeds(
    alice.collection("users").doc(ALICE_UID).collection("tasks").doc("task_1").set(validTask())
  );

  await assertFails(bob.collection("users").doc(ALICE_UID).get());
  await assertFails(bob.collection("users").doc(ALICE_UID).collection("tasks").get());
  await assertFails(bob.collection("users").doc(ALICE_UID).collection("tasks").doc("task_1").get());
  await assertFails(
    bob
      .collection("users")
      .doc(ALICE_UID)
      .collection("tasks")
      .doc("task_1")
      .update({ completed: true, updatedAt: pastDate(500) })
  );
});

test("All OvozOS subcollections: valid create, list, partial update, delete succeed; invalid payloads rejected", async () => {
  const alice = testEnv.authenticatedContext(ALICE_UID).firestore();
  const root = alice.collection("users").doc(ALICE_UID);

  // Tasks
  await assertSucceeds(root.collection("tasks").doc("t1").set(validTask()));
  await assertSucceeds(root.collection("tasks").get());
  await assertSucceeds(
    root.collection("tasks").doc("t1").update({
      completed: true,
      completedAtMillis: Date.now(),
      updatedAt: pastDate(500),
    })
  );
  // Reject @DocumentId "id" key in body
  await assertFails(
    root.collection("tasks").doc("t2").set({ ...validTask(), id: "t2" })
  );

  // Notes
  await assertSucceeds(root.collection("notes").doc("n1").set(validNote()));
  await assertSucceeds(root.collection("notes").get());
  await assertSucceeds(
    root.collection("notes").doc("n1").update({ pinned: true, updatedAt: pastDate(500) })
  );

  // Transactions
  await assertSucceeds(root.collection("transactions").doc("tx1").set(validTransaction()));
  await assertSucceeds(root.collection("transactions").get());
  await assertFails(
    root.collection("transactions").doc("tx2").set({ ...validTransaction(), amount: -100 })
  );

  // Debts
  await assertSucceeds(root.collection("debts").doc("d1").set(validDebt()));
  await assertSucceeds(root.collection("debts").get());
  await assertSucceeds(
    root.collection("debts").doc("d1").update({
      paidAmount: 200000,
      updatedAt: pastDate(500),
    })
  );
  // paidAmount > originalAmount must fail
  await assertFails(
    root.collection("debts").doc("d1").update({
      paidAmount: 600000,
      updatedAt: pastDate(200),
    })
  );

  // People
  await assertSucceeds(root.collection("people").doc("p1").set(validPerson()));
  await assertSucceeds(root.collection("people").get());

  // Goals
  await assertSucceeds(root.collection("goals").doc("g1").set(validGoal()));
  await assertSucceeds(root.collection("goals").get());
  await assertSucceeds(
    root.collection("goals").doc("g1").update({ currentValue: 1000000, updatedAt: pastDate(500) })
  );

  // Action logs
  await assertSucceeds(root.collection("action_logs").doc("log1").set(validActionLog()));
  await assertSucceeds(root.collection("action_logs").get());
  await assertSucceeds(root.collection("action_logs").doc("log1").update({ reverted: true }));
  await assertFails(
    root.collection("action_logs").doc("log1").update({ summaryText: "Tampered" })
  );

  // Daily reviews
  await assertSucceeds(root.collection("daily_reviews").doc("2026-11-24").set(validDailyReview()));
  await assertSucceeds(root.collection("daily_reviews").get());

  // Chat messages (append-only)
  await assertSucceeds(root.collection("chat_messages").doc("m1").set(validChatMessage()));
  await assertSucceeds(root.collection("chat_messages").get());
  await assertFails(root.collection("chat_messages").doc("m1").update({ text: "Edited" }));
});

test("Telegram rules: public config read-only, server collections denied, owner can only read/sync timezone/revoke link", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  const alice = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bob = testEnv.authenticatedContext(BOB_UID).firestore();

  // Seed server-managed docs bypassing rules (simulating Firebase Admin SDK)
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const adminDb = ctx.firestore();
    await adminDb.collection("app_config").doc("telegram").set({
      botUsername: "OvozOSBot",
      serverUrl: "https://example.run.app",
      updatedAt: pastDate(5000),
    });
    await adminDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("telegram_state")
      .doc("link")
      .set({
        linked: true,
        telegramUserId: "123456789",
        telegramChatId: "123456789",
        telegramUsername: "alice_tg",
        telegramFirstName: "Alice",
        linkedAtMillis: Date.now() - 10000,
        timezone: "Asia/Tashkent",
        remindersEnabled: true,
        hourlyIntervalMinutes: 60,
        activeStartHour: 8,
        activeEndHour: 22,
        smartRemindersEnabled: true,
        weeklyReportEnabled: true,
        weeklyReportDay: 0,
        weeklyReportHour: 20,
        replyMode: "text",
        voiceLanguage: "uz",
        updatedAt: pastDate(5000),
      });
    await adminDb.collection("telegram_links").doc("123456789").set({
      uid: ALICE_UID,
      active: true,
    });
  });

  // app_config/telegram: signed-in get allowed; unauth & writes denied
  await assertSucceeds(alice.collection("app_config").doc("telegram").get());
  await assertFails(unauth.collection("app_config").doc("telegram").get());
  await assertFails(
    alice.collection("app_config").doc("telegram").update({ botUsername: "FakeBot" })
  );

  // telegram_state/link: owner can read, update timezone, revoke linked->false; cannot forge linked->true or telegramUserId
  const aliceLinkRef = alice
    .collection("users")
    .doc(ALICE_UID)
    .collection("telegram_state")
    .doc("link");
  await assertSucceeds(aliceLinkRef.get());
  await assertSucceeds(
    aliceLinkRef.update({ timezone: "Asia/Samarkand", updatedAt: pastDate(500) })
  );
  await assertFails(
    aliceLinkRef.update({ telegramUserId: "999999", updatedAt: pastDate(500) })
  );
  await assertSucceeds(
    aliceLinkRef.update({ linked: false, updatedAt: pastDate(400) })
  );
  // Once unlinked, client cannot re-enable linked=true directly
  await assertFails(
    aliceLinkRef.update({ linked: true, updatedAt: pastDate(200) })
  );

  // Cross-user Bob denied
  await assertFails(
    bob.collection("users").doc(ALICE_UID).collection("telegram_state").doc("link").get()
  );

  // Server-only collections completely denied to clients
  await assertFails(alice.collection("telegram_links").doc("123456789").get());
  await assertFails(alice.collection("telegram_link_codes").doc("abc").set({ uid: ALICE_UID }));
  await assertFails(alice.collection("telegram_reminders").get());
  await assertFails(alice.collection("telegram_sessions").doc("123456789").get());
  await assertFails(alice.collection("telegram_processed_updates").doc("u1").get());
});

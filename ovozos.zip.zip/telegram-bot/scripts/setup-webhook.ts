import { loadConfig } from "../src/config";
import { initFirebase, publishTelegramPublicConfig } from "../src/firebase";
import { TelegramApiClient } from "../src/telegramApi";

async function run() {
  const config = loadConfig();
  if (!config.telegramBotToken) {
    throw new Error("TELEGRAM_BOT_TOKEN belgilanmagan (.env faylini tekshiring).");
  }
  if (!config.telegramWebhookSecret) {
    throw new Error("TELEGRAM_WEBHOOK_SECRET belgilanmagan.");
  }
  if (!config.publicBaseUrl) {
    throw new Error("PUBLIC_BASE_URL belgilanmagan (masalan: https://...run.app).");
  }

  const telegram = new TelegramApiClient(config.telegramBotToken);
  const me = await telegram.getMe();
  if (!me) {
    throw new Error("Telegram API bilan bog‘lanib bo‘lmadi. Bot tokenini tekshiring.");
  }

  const webhookUrl = `${config.publicBaseUrl}/telegram/webhook`;
  const okWebhook = await telegram.setWebhook(webhookUrl, config.telegramWebhookSecret);
  if (!okWebhook) {
    throw new Error("Webhookni o‘rnatib bo‘lmadi.");
  }

  // Minimal single slash command — voice & 5-button menu handle everything else
  await telegram.setMyCommands([
    { command: "start", description: "OvozOS yordamchini ishga tushirish" },
  ]);

  const { db } = initFirebase(config);
  await publishTelegramPublicConfig(db, me.username, config.publicBaseUrl);

  console.log(`✓ Bot tayyor: @${me.username}`);
  console.log(`✓ Webhook ulandi: ${webhookUrl}`);
  console.log(`✓ Firestore app_config/telegram yangilandi (Android avtomatik topadi).`);
}

run().catch((err) => {
  console.error("Xatolik:", (err as Error).message);
  process.exit(1);
});

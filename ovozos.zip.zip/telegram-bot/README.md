# OvozOS — Telegram shaxsiy yordamchi serveri

Bu papkada **OvozOS** Android ilovasi bilan yagona Firebase loyihasi (`gen-lang-client-0806637635`) va yagona Firestore bazasi (`ai-studio-android-ovozos-50127b10-2eff-4ef9-ad1c-13f773f75d53`) orqali ikki tomonlama ishlaydigan Telegram bot serveri joylashgan.

Bot Android ilovasi yopiq bo‘lganda ham mustaqil ishlaydi:
- Ovozli va matnli buyruqlarni Gemini orqali tahlil qilib, vazifalar, xarajatlar va oldi-berdilarni saqlaydi.
- Har soatlik eslatmalar, muddatdan 60 / 30 / 10 daqiqa oldin aqlli ogohlantirishlar, kechiktirish (15m / 30m / 1 soat), **Kun yakuni** va **Haftalik hisobot**ni avtomatik yuboradi.
- Barcha o‘zgarishlar real vaqtda Android ilovasi bilan sinxronlashtiriladi.

---

## 1. BotFather orqali Telegram bot yaratish

1. Telegramda `@BotFather` ni oching va `/newbot` yuboring.
2. Bot nomini kiriting (masalan: `OvozOS Yordamchi`).
3. Bot foydalanuvchi nomini kiriting (masalan: `OvozOSAssistantBot`, oxiri `bot` bilan tugashi kerak).
4. `@BotFather` sizga **Bot Token** beradi (`123456789:AAH...`). Uni **hech qachon** kodga yoki APK ichiga yozmang — faqat server muhit o‘zgaruvchisi (Secret) sifatida saqlang.
5. Tavsiya etilgan `@BotFather` sozlamalari:
   - `/setjoingroups` → **Disable** (bot faqat shaxsiy chatda ishlaydi).
   - `/setprivacy` → **Enable**.

---

## 2. Zarur muhit o‘zgaruvchilari (Secrets)

`telegram-bot/.env.example` dan nusxa oling (`cp telegram-bot/.env.example telegram-bot/.env`) va quyidagilarni to‘ldiring:

| O‘zgaruvchi | Tavsifi |
|---|---|
| `TELEGRAM_BOT_TOKEN` | `@BotFather` bergan bot tokeni |
| `TELEGRAM_BOT_USERNAME` | Bot foydalanuvchi nomi (`@` belgisiz, masalan `OvozOSAssistantBot`) |
| `TELEGRAM_WEBHOOK_SECRET` | Webhook himoya kaliti (kamida 32 belgi: `openssl rand -hex 24`) |
| `CRON_SECRET` | Scheduler endpoint himoya kaliti (`openssl rand -hex 24`) |
| `GEMINI_API_KEY` | Google AI Studio / Gemini API kaliti (ovoz, tahlil va ovozli javoblar uchun) |
| `FIREBASE_PROJECT_ID` | Mavjud loyiha: `gen-lang-client-0806637635` |
| `FIRESTORE_DATABASE_ID` | Mavjud baza: `ai-studio-android-ovozos-50127b10-2eff-4ef9-ad1c-13f773f75d53` |
| `PUBLIC_BASE_URL` | Joylashtirilgan serverning HTTPS manzili (masalan `https://...run.app`) |
| `GOOGLE_CLOUD_TTS_API_KEY` | *(Ixtiyoriy)* Google Cloud TTS kaliti; bo‘sh bo‘lsa Gemini TTS ishlatiladi |

---

## 3. Serverni joylashtirish (2 ta usul)

### A-usul: Firebase Cloud Functions v2 (Tavsiya etiladi — 1 daqiqalik scheduler tayyor)

1. Firebase CLI ga kiring va mavjud loyihani tanlang:
   ```bash
   firebase login
   firebase use gen-lang-client-0806637635
   ```
2. Maxfiy kalitlarni Google Cloud Secret Manager ga saqlang:
   ```bash
   firebase functions:secrets:set TELEGRAM_BOT_TOKEN --config telegram-bot/firebase.deploy.json
   firebase functions:secrets:set TELEGRAM_WEBHOOK_SECRET --config telegram-bot/firebase.deploy.json
   firebase functions:secrets:set GEMINI_API_KEY --config telegram-bot/firebase.deploy.json
   firebase functions:secrets:set CRON_SECRET --config telegram-bot/firebase.deploy.json
   ```
3. Serverni kompilyatsiya qiling va joylashtiring:
   ```bash
   npm --prefix telegram-bot install
   npm --prefix telegram-bot run build
   firebase deploy --config telegram-bot/firebase.deploy.json --only functions
   ```
   Bu ikki funksiya yaratadi:
   - `telegramBotApi` — Webhook va Android ulash API si (HTTPS URL chiqadi).
   - `telegramReminderTick` — har 1 daqiqada barcha aqlli, soatlik, kechiktirilgan eslatmalar hamda kunlik/haftalik hisobotlarni yuboruvchi avtomatik scheduler.

### B-usul: Cloud Run / Railway / Render / VPS (Docker)

1. `telegram-bot/Dockerfile` orqali konteyner yarating va joylashtiring:
   ```bash
   docker build -t ovozos-telegram-bot ./telegram-bot
   ```
2. Server muhitiga `.env.example` dagi barcha o‘zgaruvchilarni kiriting.
3. Agar server doimiy yoniq bo‘lsa (VPS / Railway), `ENABLE_LOCAL_SCHEDULER_LOOP=true` ni yoqing.
   Agar **Cloud Run** (serverless) ishlatsangiz, Cloud Scheduler yarating: har 1 daqiqada `POST https://<SERVER_URL>/cron/tick` so‘rovini `X-Cron-Secret: <CRON_SECRET>` sarlavhasi bilan yuborsin.

---

## 4. Webhook ni ro‘yxatdan o‘tkazish va Android ilovasiga manzilni ulash

Server joylashtirilgach, `telegram-bot/.env` ichida `PUBLIC_BASE_URL` ni o‘rnating (masalan, Cloud Functions yoki Cloud Run HTTPS manzili) va bitta buyruqni bajaring:

```bash
npm --prefix telegram-bot run setup:webhook
```

Ushbu skript avtomatik ravishda:
1. Telegramga `POST <PUBLIC_BASE_URL>/telegram/webhook` va `X-Telegram-Bot-Api-Secret-Token` ni ro‘yxatdan o‘tkazadi.
2. Bot buyruqlarini (`/start`, `/vazifalar`, `/xarajatlar`, `/qarzlar`, `/hisobot`, `/sozlamalar`, `/bekor`) o‘rnatadi.
3. Firestore dagi `app_config/telegram` hujjatiga ommaviy `botUsername` va `serverUrl` ni yozadi — natijada Android ilovasi **Sozlamalar → Telegram** bo‘limida server manzilini avtomatik taniydi!

---

## 5. Android ilovasidan Telegram hisobini ulash

1. Android ilovasini oching va Google hisobingiz bilan kiring.
2. **Boshqa → Sozlamalar → Telegram** bo‘limiga o‘ting.
3. **«Telegramni ulash»** tugmasini bosing — server 10 daqiqalik bir martalik xavfsiz kod yaratadi va Telegram botni avtomatik ochadi.
4. Telegramda **Start** → **«Ha, ulash»** ni bosing.
5. Shu zahoti ikki tomonlama sinxronizatsiya va eslatmalar ishga tushadi. Istalgan vaqt **«Hisobni uzish»** orqali ulanishni bir zumda to‘xtatishingiz mumkin.

---

## 6. Yangilangan Android APK ni yig‘ish

Android loyihasini yangi APK ko‘rinishida yig‘ish uchun:

- **Google AI Studio ichida:** yuqori o‘ng burchakdagi sozlamalar menyusidan **Export / Build APK** ni tanlang.
- **Lokal muhitda (Gradle):**
  ```bash
  gradle :app:assembleDebug
  # yoki imzolangan reliz uchun:
  gradle :app:assembleRelease
  ```
  Tayyor APK `app/build/outputs/apk/` papkasida paydo bo‘ladi.

---

## 7. Avtomatlashtirilgan testlarni ishga tushirish

Barcha 15 ta asosiy stsenariy (ikki tomonlama sinxronizatsiya, ko‘p amalli ovoz, soatlik va 60/30/10 daqiqalik aqlli eslatmalar, kechiktirish, dublikat, yo‘naltirilgan xabar, aniqlashtirish, kunlik/haftalik hisobot, ovozli javob va fallback, conflict-safe bekor qilish, foydalanuvchi izolyatsiyasi, hisobni uzish va qayta ishga tushishdan keyingi barqarorlik) ni tekshirish uchun:

```bash
npm --prefix telegram-bot test
```

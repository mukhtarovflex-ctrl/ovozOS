import {
  CurrencyCode,
  DebtItem,
  EXPENSE_CATEGORIES_UZ,
  FinanceTransaction,
  ParsedAction,
  SUPPORTED_CURRENCIES,
  TaskItem,
} from "./types";
import {
  dateKeyInZone,
  endOfDayInZone,
  isOverdueInZone,
  isSameDayInZone,
  isTodayInZone,
  isTomorrowInZone,
  startOfDayInZone,
} from "./time";

export function guessExpenseCategoryUz(title: string): string {
  const l = (title || "").toLowerCase();
  if (
    [
      "tushlik",
      "nonushta",
      "kechki",
      "ovqat",
      "kafe",
      "restoran",
      "choy",
      "kofe",
      "non",
      "bozor",
      "do‘kon",
      "dokon",
      "food",
      "обед",
      "еда",
    ].some((k) => l.includes(k))
  ) {
    return "Oziq-ovqat";
  }
  if (
    [
      "taksi",
      "taxi",
      "metro",
      "avtobus",
      "benzin",
      "yo‘l",
      "yol",
      "transport",
      "yandex",
      "проезд",
      "такси",
    ].some((k) => l.includes(k))
  ) {
    return "Transport";
  }
  if (
    [
      "kurs",
      "kitob",
      "o‘qish",
      "oqish",
      "universitet",
      "maktab",
      "dars",
      "ta'lim",
      "ta’lim",
    ].some((k) => l.includes(k))
  ) {
    return "Ta’lim";
  }
  if (["kiyim", "oyoq kiyim", "ko‘ylak", "shim", "kurtka"].some((k) => l.includes(k))) {
    return "Kiyim-kechak";
  }
  if (["kino", "o‘yin", "oyin", "dam", "park", "sayr"].some((k) => l.includes(k))) {
    return "Ko‘ngilochar";
  }
  if (
    ["obuna", "netflix", "spotify", "telegram", "youtube", "chatgpt", "icloud"].some((k) =>
      l.includes(k)
    )
  ) {
    return "Obunalar";
  }
  if (
    ["dori", "shifokor", "dorixona", "klinika", "tish", "sport", "zal"].some((k) => l.includes(k))
  ) {
    return "Sog‘liq";
  }
  if (["ijara", "kommunal", "svet", "gaz", "suv", "uy"].some((k) => l.includes(k))) {
    return "Uy-joy";
  }
  if (
    ["internet", "paynet", "mobil", "telefon", "aloqa", "beeline", "ucell", "uzmobile"].some((k) =>
      l.includes(k)
    )
  ) {
    return "Aloqa";
  }
  if (["xarid", "texnika", "sovg‘a", "sovga"].some((k) => l.includes(k))) {
    return "Xaridlar";
  }
  return "Boshqa";
}

export function normalizeExpenseCategory(cat: string, title: string): string {
  const clean = (cat || "").trim();
  const exact = EXPENSE_CATEGORIES_UZ.find((c) => c.toLowerCase() === clean.toLowerCase());
  if (exact) return exact;
  return guessExpenseCategoryUz(`${clean} ${title}`);
}

export function normalizeCurrency(raw: string | undefined, fallback: CurrencyCode): CurrencyCode {
  const up = (raw || "").trim().toUpperCase();
  if ((SUPPORTED_CURRENCIES as string[]).includes(up)) return up as CurrencyCode;
  return fallback;
}

const UZ_STOPWORDS = new Set([
  "kerak",
  "qilish",
  "qilishim",
  "ishlash",
  "ishlashim",
  "yechish",
  "yechishim",
  "yozib",
  "qoy",
  "qo'y",
  "qo‘y",
  "bajarish",
  "bajarishim",
  "uchun",
  "bilan",
  "ertaga",
  "bugun",
  "soat",
  "kuni",
  "da",
  "ni",
  "dan",
  "ga",
  "va",
  "esa",
  "men",
  "vazifa",
  "vazifasini",
  "vazifani",
]);

/**
 * Strips common Uzbek suffixes to compare core task roots (e.g. "matematikadan" -> "matematika", "testini" -> "test").
 */
export function tokenizeTaskTitle(title: string): string[] {
  const normalized = (title || "")
    .toLowerCase()
    .replace(/[‘’`']/g, "'")
    .replace(/[^a-z0-9а-яё' ]+/gi, " ");
  const rawTokens = normalized.split(/\s+/).filter((t) => t.length >= 2);
  const stems: string[] = [];
  for (const tok of rawTokens) {
    if (UZ_STOPWORDS.has(tok)) continue;
    let stem = tok;
    for (const suf of [
      "laridan",
      "larini",
      "lariga",
      "lashim",
      "ishim",
      "sini",
      "dan",
      "ning",
      "dagi",
      "lar",
      "ini",
      "ni",
      "ga",
      "da",
      "im",
    ]) {
      if (stem.length > suf.length + 3 && stem.endsWith(suf)) {
        stem = stem.slice(0, -suf.length);
        break;
      }
    }
    if (stem.length >= 2 && !UZ_STOPWORDS.has(stem)) {
      stems.push(stem);
    }
  }
  return Array.from(new Set(stems));
}

export function computeTaskSimilarity(titleA: string, titleB: string): number {
  const a = tokenizeTaskTitle(titleA);
  const b = tokenizeTaskTitle(titleB);
  if (a.length === 0 || b.length === 0) return 0;

  let overlap = 0;
  for (const ta of a) {
    if (b.some((tb) => tb === ta || (ta.length >= 4 && tb.startsWith(ta)) || (tb.length >= 4 && ta.startsWith(tb)))) {
      overlap++;
    }
  }
  const union = new Set([...a, ...b]).size;
  const jaccard = union > 0 ? overlap / union : 0;
  const containment = overlap / Math.min(a.length, b.length);
  return Math.max(jaccard, containment * 0.85);
}

/**
 * Duplicate task detection (Requirement 10):
 * Considers semantic title stem similarity + same calendar day + time proximity.
 * Avoids falsely merging distinct tasks (e.g., different dates or different times > 2h apart).
 */
export function findPotentialDuplicateTask(
  candidate: { title: string; dueDateMillis: number; hasDueTime: boolean },
  existingTasks: TaskItem[],
  timeZone: string
): TaskItem | null {
  const openTasks = existingTasks.filter((t) => !t.completed);
  let bestTask: TaskItem | null = null;
  let bestScore = 0;

  for (const existing of openTasks) {
    const titleSim = computeTaskSimilarity(candidate.title, existing.title);
    if (titleSim < 0.55) continue;

    // If both have explicit dates, they must fall on the same day to be duplicates
    if (candidate.dueDateMillis > 0 && existing.dueDateMillis > 0) {
      if (!isSameDayInZone(candidate.dueDateMillis, existing.dueDateMillis, timeZone)) {
        continue;
      }
      // If both have explicit clock times and are more than 2 hours apart, treat as distinct tasks
      if (candidate.hasDueTime && existing.hasDueTime) {
        const diffHours = Math.abs(candidate.dueDateMillis - existing.dueDateMillis) / 3_600_000;
        if (diffHours > 2) continue;
      }
    }

    const totalScore = titleSim + (candidate.dueDateMillis > 0 && existing.dueDateMillis > 0 ? 0.15 : 0);
    if (totalScore > bestScore) {
      bestScore = totalScore;
      bestTask = existing;
    }
  }

  return bestScore >= 0.6 ? bestTask : null;
}

/**
 * Validates and sanitizes Gemini-produced actions against real user records before persisting.
 */
export function validateParsedActions(
  actions: ParsedAction[],
  primaryCurrency: CurrencyCode,
  existingTasks: TaskItem[],
  existingDebts: DebtItem[]
): ParsedAction[] {
  const taskIds = new Set(existingTasks.map((t) => t.id));
  const debtIds = new Set(existingDebts.map((d) => d.id));
  const validated: ParsedAction[] = [];

  for (const act of actions) {
    const cleanTitle = (act.title || "").trim().slice(0, 200);
    const currency = normalizeCurrency(act.currency, primaryCurrency);

    if (act.type === "CREATE_EXPENSE") {
      if (!Number.isFinite(act.amount) || act.amount <= 0) continue;
      const cat = normalizeExpenseCategory(act.category, cleanTitle);
      validated.push({
        ...act,
        title: cleanTitle || cat,
        category: cat,
        currency,
        amount: Math.round(act.amount * 100) / 100,
      });
    } else if (act.type === "CREATE_DEBT_BORROWED" || act.type === "CREATE_DEBT_LENT") {
      if (!Number.isFinite(act.amount) || act.amount <= 0) continue;
      const person = (act.personName || cleanTitle).trim().slice(0, 80);
      if (!person) continue;
      validated.push({
        ...act,
        title: cleanTitle || person,
        personName: person,
        currency,
        amount: Math.round(act.amount * 100) / 100,
      });
    } else if (act.type === "PAY_DEBT") {
      const safeId = act.matchedEntityId && debtIds.has(act.matchedEntityId) ? act.matchedEntityId : "";
      validated.push({
        ...act,
        matchedEntityId: safeId,
        currency,
        amount: Number.isFinite(act.amount) && act.amount > 0 ? Math.round(act.amount * 100) / 100 : 0,
      });
    } else if (act.type === "COMPLETE_TASK") {
      const safeId = act.matchedEntityId && taskIds.has(act.matchedEntityId) ? act.matchedEntityId : "";
      validated.push({
        ...act,
        title: cleanTitle || "Vazifa",
        matchedEntityId: safeId,
      });
    } else if (act.type === "CREATE_TASK") {
      if (!cleanTitle) continue;
      validated.push({
        ...act,
        title: cleanTitle,
        category: (act.category || "Shaxsiy").trim().slice(0, 40) || "Shaxsiy",
        priority: ["low", "medium", "high"].includes(act.priority) ? act.priority : "medium",
        recurrence: ["none", "daily", "weekly", "monthly"].includes(act.recurrence)
          ? act.recurrence
          : "none",
      });
    } else if (act.type === "UNDO_LAST_ACTION" || act.type === "ANSWER_QUESTION") {
      validated.push(act);
    }
  }
  return validated;
}

export interface DailyReportMetrics {
  dateKey: string;
  completedTodayCount: number;
  remainingTodayTasks: TaskItem[];
  overdueTasks: TaskItem[];
  tomorrowTasks: TaskItem[];
  expensesByCurrency: Record<string, number>;
  primaryCurrency: CurrencyCode;
  primaryExpenseTotal: number;
  topExpenseCategory: string;
  topExpenseCategoryAmount: number;
}

export function computeDailyReportMetrics(
  tasks: TaskItem[],
  transactions: FinanceTransaction[],
  primaryCurrency: CurrencyCode,
  timeZone: string,
  nowMillis = Date.now()
): DailyReportMetrics {
  const todayStart = startOfDayInZone(nowMillis, timeZone);
  const todayEnd = endOfDayInZone(nowMillis, timeZone);

  const completedToday = tasks.filter(
    (t) =>
      t.completed &&
      ((t.completedAtMillis >= todayStart && t.completedAtMillis <= todayEnd) ||
        isTodayInZone(t.dueDateMillis, timeZone, nowMillis))
  );
  const remainingToday = tasks.filter(
    (t) => !t.completed && isTodayInZone(t.dueDateMillis, timeZone, nowMillis)
  );
  const overdue = tasks.filter((t) => isOverdueInZone(t.dueDateMillis, t.completed, timeZone, nowMillis));
  const tomorrow = tasks.filter(
    (t) => !t.completed && isTomorrowInZone(t.dueDateMillis, timeZone, nowMillis)
  );

  // Strictly kind === "expense" ONLY — never mix debt payments or income!
  const todayExpenses = transactions.filter(
    (tx) => tx.kind === "expense" && isTodayInZone(tx.occurredAtMillis, timeZone, nowMillis)
  );
  const expensesByCurrency: Record<string, number> = {};
  const catTotalsPrimary: Record<string, number> = {};

  for (const tx of todayExpenses) {
    expensesByCurrency[tx.currency] = (expensesByCurrency[tx.currency] || 0) + tx.amount;
    if (tx.currency === primaryCurrency) {
      catTotalsPrimary[tx.category] = (catTotalsPrimary[tx.category] || 0) + tx.amount;
    }
  }

  let topCategory = "";
  let topCategoryAmount = 0;
  for (const [cat, amt] of Object.entries(catTotalsPrimary)) {
    if (amt > topCategoryAmount) {
      topCategory = cat;
      topCategoryAmount = amt;
    }
  }

  return {
    dateKey: dateKeyInZone(nowMillis, timeZone),
    completedTodayCount: completedToday.length,
    remainingTodayTasks: remainingToday,
    overdueTasks: overdue,
    tomorrowTasks: tomorrow,
    expensesByCurrency,
    primaryCurrency,
    primaryExpenseTotal: expensesByCurrency[primaryCurrency] || 0,
    topExpenseCategory: topCategory,
    topExpenseCategoryAmount: topCategoryAmount,
  };
}

export interface WeeklyReportMetrics {
  completedCount: number;
  incompleteCount: number;
  overdueCount: number;
  expensesByCurrency: Record<string, number>;
  prevWeekExpensesByCurrency: Record<string, number>;
  primaryCurrency: CurrencyCode;
  primaryTotal: number;
  prevPrimaryTotal: number;
  primaryChangePercent: number | null; // null if previous week had zero data (never fake stats!)
  topCategory: string;
  topCategoryAmount: number;
  topCategoryChangePercent: number | null;
  activeBorrowedByCurrency: Record<string, number>;
  activeLentByCurrency: Record<string, number>;
  activeDebtCount: number;
}

export function computeWeeklyReportMetrics(
  tasks: TaskItem[],
  transactions: FinanceTransaction[],
  debts: DebtItem[],
  primaryCurrency: CurrencyCode,
  timeZone: string,
  nowMillis = Date.now()
): WeeklyReportMetrics {
  const endMs = endOfDayInZone(nowMillis, timeZone);
  const startMs = startOfDayInZone(nowMillis, timeZone) - 6 * 86_400_000;
  const prevEndMs = startMs - 1;
  const prevStartMs = startMs - 7 * 86_400_000;

  const completedInWeek = tasks.filter(
    (t) =>
      t.completed &&
      ((t.completedAtMillis >= startMs && t.completedAtMillis <= endMs) ||
        (t.dueDateMillis >= startMs && t.dueDateMillis <= endMs))
  );
  const incompleteInWeek = tasks.filter(
    (t) => !t.completed && t.dueDateMillis >= startMs && t.dueDateMillis <= endMs
  );
  const overdue = tasks.filter((t) => isOverdueInZone(t.dueDateMillis, t.completed, timeZone, nowMillis));

  const thisWeekExpenses = transactions.filter(
    (tx) => tx.kind === "expense" && tx.occurredAtMillis >= startMs && tx.occurredAtMillis <= endMs
  );
  const prevWeekExpenses = transactions.filter(
    (tx) => tx.kind === "expense" && tx.occurredAtMillis >= prevStartMs && tx.occurredAtMillis <= prevEndMs
  );

  const expensesByCurrency: Record<string, number> = {};
  const prevWeekExpensesByCurrency: Record<string, number> = {};
  const catCurr: Record<string, number> = {};
  const catPrev: Record<string, number> = {};

  for (const tx of thisWeekExpenses) {
    expensesByCurrency[tx.currency] = (expensesByCurrency[tx.currency] || 0) + tx.amount;
    if (tx.currency === primaryCurrency) {
      catCurr[tx.category] = (catCurr[tx.category] || 0) + tx.amount;
    }
  }
  for (const tx of prevWeekExpenses) {
    prevWeekExpensesByCurrency[tx.currency] =
      (prevWeekExpensesByCurrency[tx.currency] || 0) + tx.amount;
    if (tx.currency === primaryCurrency) {
      catPrev[tx.category] = (catPrev[tx.category] || 0) + tx.amount;
    }
  }

  const primaryTotal = expensesByCurrency[primaryCurrency] || 0;
  const prevPrimaryTotal = prevWeekExpensesByCurrency[primaryCurrency] || 0;
  const primaryChangePercent =
    prevPrimaryTotal > 0 ? Math.round(((primaryTotal - prevPrimaryTotal) / prevPrimaryTotal) * 100) : null;

  let topCategory = "";
  let topCategoryAmount = 0;
  for (const [cat, amt] of Object.entries(catCurr)) {
    if (amt > topCategoryAmount) {
      topCategory = cat;
      topCategoryAmount = amt;
    }
  }
  const prevTopAmt = topCategory ? catPrev[topCategory] || 0 : 0;
  const topCategoryChangePercent =
    topCategory && prevTopAmt > 0
      ? Math.round(((topCategoryAmount - prevTopAmt) / prevTopAmt) * 100)
      : null;

  const activeDebts = debts.filter((d) => !d.closed && d.originalAmount - d.paidAmount > 0.001);
  const activeBorrowedByCurrency: Record<string, number> = {};
  const activeLentByCurrency: Record<string, number> = {};
  for (const d of activeDebts) {
    const rem = Math.max(0, d.originalAmount - d.paidAmount);
    if (d.direction === "borrowed") {
      activeBorrowedByCurrency[d.currency] = (activeBorrowedByCurrency[d.currency] || 0) + rem;
    } else {
      activeLentByCurrency[d.currency] = (activeLentByCurrency[d.currency] || 0) + rem;
    }
  }

  return {
    completedCount: completedInWeek.length,
    incompleteCount: incompleteInWeek.length,
    overdueCount: overdue.length,
    expensesByCurrency,
    prevWeekExpensesByCurrency,
    primaryCurrency,
    primaryTotal,
    prevPrimaryTotal,
    primaryChangePercent,
    topCategory,
    topCategoryAmount,
    topCategoryChangePercent,
    activeBorrowedByCurrency,
    activeLentByCurrency,
    activeDebtCount: activeDebts.length,
  };
}

import { CurrencyCode } from "./types";

const UZ_WEEKDAYS = [
  "Yakshanba",
  "Dushanba",
  "Seshanba",
  "Chorshanba",
  "Payshanba",
  "Juma",
  "Shanba",
];

const UZ_MONTHS = [
  "yanvar",
  "fevral",
  "mart",
  "aprel",
  "may",
  "iyun",
  "iyul",
  "avgust",
  "sentyabr",
  "oktyabr",
  "noyabr",
  "dekabr",
];

export interface ZonedParts {
  year: number;
  month: number; // 1-12
  day: number; // 1-31
  hour: number; // 0-23
  minute: number; // 0-59
  second: number; // 0-59
  dayOfWeek: number; // 0=Sunday .. 6=Saturday
}

export function normalizeTimezone(tz?: string): string {
  const candidate = (tz || "").trim() || "Asia/Tashkent";
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: candidate }).format(new Date());
    return candidate;
  } catch {
    return "Asia/Tashkent";
  }
}

export function getZonedParts(millis: number, timeZone: string): ZonedParts {
  const tz = normalizeTimezone(timeZone);
  const dtf = new Intl.DateTimeFormat("en-US", {
    timeZone: tz,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    weekday: "short",
    hourCycle: "h23",
  });
  const parts = dtf.formatToParts(new Date(millis));
  const map: Record<string, string> = {};
  for (const p of parts) {
    map[p.type] = p.value;
  }
  const weekdayMap: Record<string, number> = {
    Sun: 0,
    Mon: 1,
    Tue: 2,
    Wed: 3,
    Thu: 4,
    Fri: 5,
    Sat: 6,
  };
  return {
    year: parseInt(map.year || "2026", 10),
    month: parseInt(map.month || "1", 10),
    day: parseInt(map.day || "1", 10),
    hour: parseInt(map.hour || "0", 10) % 24,
    minute: parseInt(map.minute || "0", 10),
    second: parseInt(map.second || "0", 10),
    dayOfWeek: weekdayMap[map.weekday || "Sun"] ?? 0,
  };
}

/**
 * Converts a local wall-clock date/time in `timeZone` into UTC epoch milliseconds.
 */
export function zonedDateTimeToUtcMillis(
  year: number,
  month: number,
  day: number,
  hour: number,
  minute: number,
  timeZone: string
): number {
  const tz = normalizeTimezone(timeZone);
  const guessUtc = Date.UTC(year, month - 1, day, hour, minute, 0, 0);
  const observed = getZonedParts(guessUtc, tz);
  const observedAsUtc = Date.UTC(
    observed.year,
    observed.month - 1,
    observed.day,
    observed.hour,
    observed.minute,
    0,
    0
  );
  const offsetMs = observedAsUtc - guessUtc;
  let adjusted = guessUtc - offsetMs;
  // Second pass handles DST boundaries accurately
  const check = getZonedParts(adjusted, tz);
  const checkAsUtc = Date.UTC(
    check.year,
    check.month - 1,
    check.day,
    check.hour,
    check.minute,
    0,
    0
  );
  adjusted -= checkAsUtc - guessUtc;
  return adjusted;
}

export function dateKeyInZone(millis: number, timeZone: string): string {
  const p = getZonedParts(millis, timeZone);
  return `${p.year}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}`;
}

export function startOfDayInZone(millis: number, timeZone: string): number {
  const p = getZonedParts(millis, timeZone);
  return zonedDateTimeToUtcMillis(p.year, p.month, p.day, 0, 0, timeZone);
}

export function endOfDayInZone(millis: number, timeZone: string): number {
  return startOfDayInZone(millis, timeZone) + 86_400_000 - 1;
}

export function isSameDayInZone(a: number, b: number, timeZone: string): boolean {
  if (a <= 0 || b <= 0) return false;
  return dateKeyInZone(a, timeZone) === dateKeyInZone(b, timeZone);
}

export function isTodayInZone(millis: number, timeZone: string, nowMillis = Date.now()): boolean {
  return isSameDayInZone(millis, nowMillis, timeZone);
}

export function isTomorrowInZone(millis: number, timeZone: string, nowMillis = Date.now()): boolean {
  const tomorrow = startOfDayInZone(nowMillis, timeZone) + 86_400_000 + 3_600_000;
  return isSameDayInZone(millis, tomorrow, timeZone);
}

export function isOverdueInZone(
  dueDateMillis: number,
  completed: boolean,
  timeZone: string,
  nowMillis = Date.now()
): boolean {
  if (completed || dueDateMillis <= 0) return false;
  return dueDateMillis < startOfDayInZone(nowMillis, timeZone);
}

export function parseIsoInZone(
  iso: string,
  hasTime: boolean,
  timeZone: string
): { millis: number; hasDueTime: boolean } {
  const clean = (iso || "").trim();
  if (!clean) return { millis: 0, hasDueTime: false };

  // Match YYYY-MM-DDTHH:mm or YYYY-MM-DD HH:mm
  const dtMatch = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})/.exec(clean);
  if (dtMatch) {
    const [, y, mo, d, h, mi] = dtMatch;
    const millis = zonedDateTimeToUtcMillis(
      parseInt(y, 10),
      parseInt(mo, 10),
      parseInt(d, 10),
      parseInt(h, 10),
      parseInt(mi, 10),
      timeZone
    );
    return { millis, hasDueTime: true };
  }

  // Match YYYY-MM-DD (date-only: never fabricate a fake due time!)
  const dMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(clean);
  if (dMatch) {
    const [, y, mo, d] = dMatch;
    // Store at 12:00 local noon for date-only tasks so timezone shifts never move the calendar day,
    // while keeping hasDueTime = false so smart 60/30/10m alerts never fire on undated times!
    const millis = zonedDateTimeToUtcMillis(
      parseInt(y, 10),
      parseInt(mo, 10),
      parseInt(d, 10),
      12,
      0,
      timeZone
    );
    return { millis, hasDueTime: hasTime && false };
  }

  const fallback = Date.parse(clean);
  if (!Number.isNaN(fallback) && fallback > 0) {
    return { millis: fallback, hasDueTime: hasTime };
  }
  return { millis: 0, hasDueTime: false };
}

export function formatUzDateShort(millis: number, timeZone: string): string {
  if (millis <= 0) return "";
  const p = getZonedParts(millis, timeZone);
  return `${p.day}-${UZ_MONTHS[p.month - 1]}`;
}

export function formatUzWeekday(dayOfWeek: number): string {
  return UZ_WEEKDAYS[((dayOfWeek % 7) + 7) % 7] || "Yakshanba";
}

export function formatTime24InZone(millis: number, timeZone: string): string {
  if (millis <= 0) return "";
  const p = getZonedParts(millis, timeZone);
  return `${String(p.hour).padStart(2, "0")}:${String(p.minute).padStart(2, "0")}`;
}

export function formatDueLabelUz(
  dueDateMillis: number,
  hasDueTime: boolean,
  timeZone: string,
  nowMillis = Date.now()
): string {
  if (dueDateMillis <= 0) return "";
  const dayLabel = isTodayInZone(dueDateMillis, timeZone, nowMillis)
    ? "bugun"
    : isTomorrowInZone(dueDateMillis, timeZone, nowMillis)
      ? "ertaga"
      : `${formatUzWeekday(getZonedParts(dueDateMillis, timeZone).dayOfWeek).toLowerCase()}, ${formatUzDateShort(dueDateMillis, timeZone)}`;
  if (hasDueTime) {
    return `${dayLabel}, ${formatTime24InZone(dueDateMillis, timeZone)}`;
  }
  return dayLabel;
}

export function formatMoneyUz(amount: number, currency: CurrencyCode | string = "UZS"): string {
  const absVal = Math.abs(Number.isFinite(amount) ? amount : 0);
  const rounded = currency === "UZS" ? Math.round(absVal) : Math.round(absVal * 100) / 100;
  const parts = rounded.toString().split(".");
  const intFormatted = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  const numStr = parts.length > 1 ? `${intFormatted}.${parts[1]}` : intFormatted;
  const sign = amount < 0 ? "−" : "";
  switch (String(currency).toUpperCase()) {
    case "USD":
      return `${sign}$${numStr}`;
    case "EUR":
      return `${sign}€${numStr}`;
    case "RUB":
      return `${sign}${numStr} ₽`;
    default:
      return `${sign}${numStr} so‘m`;
  }
}

export function weekKeyInZone(millis: number, timeZone: string): string {
  const p = getZonedParts(millis, timeZone);
  const utcDate = new Date(Date.UTC(p.year, p.month - 1, p.day));
  const dayNum = utcDate.getUTCDay() || 7;
  utcDate.setUTCDate(utcDate.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(utcDate.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(((utcDate.getTime() - yearStart.getTime()) / 86_400_000 + 1) / 7);
  return `${utcDate.getUTCFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

export function isHourWithinWindow(hour: number, startHour: number, endHour: number): boolean {
  if (startHour === endHour) return true;
  if (startHour < endHour) {
    return hour >= startHour && hour < endHour;
  }
  // Wraps midnight
  return hour >= startHour || hour < endHour;
}

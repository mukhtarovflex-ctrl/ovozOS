import {
  CurrencyCode,
  DebtItem,
  FinanceTransaction,
  ParsedAction,
  TaskItem,
  TelegramUserState,
  UserProfile,
} from "./types";
import { InlineButton } from "./telegramApi";
import { escapeHtml } from "./security";
import {
  formatDueLabelUz,
  formatMoneyUz,
  formatTime24InZone,
  formatUzDateShort,
  formatUzWeekday,
  isOverdueInZone,
  isTodayInZone,
  startOfDayInZone,
} from "./time";

export function formatActionLineUz(action: ParsedAction, timeZone: string): string {
  switch (action.type) {
    case "CREATE_TASK": {
      const due = formatDueLabelUz(action.dueDateMillis, action.hasDueTime, timeZone);
      return `✓ ${escapeHtml(action.title)}${due ? ` — ${escapeHtml(due)}` : ""}`;
    }
    case "COMPLETE_TASK":
      return `✓ Bajarildi: ${escapeHtml(action.title)}`;
    case "CREATE_EXPENSE": {
      const cat = action.category || "Xarajat";
      return `✓ ${escapeHtml(cat)} xarajati — <b>${escapeHtml(
        formatMoneyUz(action.amount, action.currency)
      )}</b>${action.title && action.title.toLowerCase() !== cat.toLowerCase() ? ` (${escapeHtml(action.title)})` : ""}`;
    }
    case "CREATE_DEBT_BORROWED":
      return `✓ ${escapeHtml(action.personName || action.title)}dan olingan qarz — <b>${escapeHtml(
        formatMoneyUz(action.amount, action.currency)
      )}</b>`;
    case "CREATE_DEBT_LENT":
      return `✓ ${escapeHtml(action.personName || action.title)}ga berilgan qarz — <b>${escapeHtml(
        formatMoneyUz(action.amount, action.currency)
      )}</b>`;
    case "PAY_DEBT":
      return `✓ Qarz to‘lovi (${escapeHtml(action.personName || action.title)})${
        action.amount > 0 ? ` — <b>${escapeHtml(formatMoneyUz(action.amount, action.currency))}</b>` : ""
      }`;
    default:
      return `✓ ${escapeHtml(action.title)}`;
  }
}

export function buildDraftConfirmationMessage(
  actions: ParsedAction[],
  isForwarded: boolean,
  timeZone: string,
  draftId: string
): { text: string; inline_keyboard: InlineButton[][] } {
  const duplicateAct = actions.find(
    (a) => a.type === "CREATE_TASK" && a.duplicateTaskId && !a.duplicateResolution
  );

  if (duplicateAct) {
    const due = formatDueLabelUz(duplicateAct.dueDateMillis, duplicateAct.hasDueTime, timeZone);
    const text = [
      "<b>Bu vazifa allaqachon mavjud</b>",
      "",
      `Mavjud: ${escapeHtml(duplicateAct.duplicateTaskTitle || duplicateAct.title)}`,
      `Yangi: ${escapeHtml(duplicateAct.title)}${due ? ` — ${escapeHtml(due)}` : ""}`,
    ].join("\n");
    return {
      text,
      inline_keyboard: [
        [{ text: "Mavjud vazifani yangilash", callback_data: `dup:upd:${draftId}:${duplicateAct.localId}` }],
        [{ text: "Baribir yangi yaratish", callback_data: `dup:new:${draftId}:${duplicateAct.localId}` }],
        [{ text: "Bekor qilish", callback_data: `draft:cancel:${draftId}` }],
      ],
    };
  }

  const activeActions = actions.filter((a) => a.selected && a.duplicateResolution !== "skip");
  let header: string;
  if (isForwarded && activeActions.length === 1 && activeActions[0].type === "CREATE_TASK") {
    const a = activeActions[0];
    const due = formatDueLabelUz(a.dueDateMillis, a.hasDueTime, timeZone);
    const text = [
      "<b>Yangi vazifa</b>",
      "",
      escapeHtml(a.title),
      ...(due ? [`Muddat: <b>${escapeHtml(due)}</b>`] : []),
    ].join("\n");
    return {
      text,
      inline_keyboard: [
        [
          { text: "✓ Saqlash", callback_data: `draft:save:${draftId}` },
          { text: "Tahrirlash", callback_data: `draft:editmenu:${draftId}` },
        ],
        [{ text: "Bekor qilish", callback_data: `draft:cancel:${draftId}` }],
      ],
    };
  }

  header =
    activeActions.length === 1
      ? "<b>1 ta amal aniqlandi:</b>"
      : `<b>${activeActions.length} ta amal aniqlandi:</b>`;

  const lines = [header, "", ...activeActions.map((a) => formatActionLineUz(a, timeZone))];

  return {
    text: lines.join("\n"),
    inline_keyboard: [
      [
        { text: "✓ Saqlash", callback_data: `draft:save:${draftId}` },
        { text: "Tahrirlash", callback_data: `draft:editmenu:${draftId}` },
      ],
      [{ text: "Bekor qilish", callback_data: `draft:cancel:${draftId}` }],
    ],
  };
}

export function buildTasksListMessage(
  tasks: TaskItem[],
  filter: "today" | "all" | "overdue",
  timeZone: string,
  nowMillis = Date.now()
): { text: string; inline_keyboard: InlineButton[][] } {
  const open = tasks.filter((t) => !t.completed);
  const filtered =
    filter === "today"
      ? open.filter((t) => isTodayInZone(t.dueDateMillis, timeZone, nowMillis))
      : filter === "overdue"
        ? open.filter((t) => isOverdueInZone(t.dueDateMillis, t.completed, timeZone, nowMillis))
        : open;

  const sorted = [...filtered].sort((a, b) => {
    const ad = a.dueDateMillis > 0 ? a.dueDateMillis : Number.MAX_SAFE_INTEGER;
    const bd = b.dueDateMillis > 0 ? b.dueDateMillis : Number.MAX_SAFE_INTEGER;
    return ad - bd;
  });

  const title =
    filter === "today"
      ? "Bugungi vazifalar"
      : filter === "overdue"
        ? "Kechikkan vazifalar"
        : "Barcha faol vazifalar";

  const lines = [`<b>${title}</b>`, ""];
  const keyboard: InlineButton[][] = [
    [
      { text: filter === "today" ? "• Bugun" : "Bugun", callback_data: "tlist:today" },
      { text: filter === "all" ? "• Barchasi" : "Barchasi", callback_data: "tlist:all" },
      { text: filter === "overdue" ? "• Kechikkan" : "Kechikkan", callback_data: "tlist:overdue" },
    ],
  ];

  if (sorted.length === 0) {
    lines.push(filter === "today" ? "Bugun vazifalar yo‘q." : "Faol vazifalar yo‘q.");
  } else {
    sorted.slice(0, 8).forEach((t, idx) => {
      const due = formatDueLabelUz(t.dueDateMillis, t.hasDueTime, timeZone, nowMillis);
      lines.push(`${idx + 1}. ☐ ${escapeHtml(t.title)}${due ? ` · <i>${escapeHtml(due)}</i>` : ""}`);
      const short = t.title.length > 18 ? `${t.title.slice(0, 17)}…` : t.title;
      keyboard.push([
        { text: `✓ ${idx + 1}. ${short}`, callback_data: `tdone:${t.id}` },
        { text: "Keyinroq", callback_data: `tsnzmenu:${t.id}` },
        { text: "Tahrir", callback_data: `tedit:${t.id}` },
      ]);
    });
    if (sorted.length > 8) {
      lines.push("", `<i>+ yana ${sorted.length - 8} ta vazifa</i>`);
    }
  }

  return { text: lines.join("\n"), inline_keyboard: keyboard };
}

export function buildExpensesMessage(
  transactions: FinanceTransaction[],
  primaryCurrency: CurrencyCode,
  timeZone: string,
  period: "today" | "week",
  nowMillis = Date.now()
): { text: string; inline_keyboard: InlineButton[][] } {
  const expenses = transactions.filter((tx) => tx.kind === "expense");
  const startMs =
    period === "today"
      ? startOfDayInZone(nowMillis, timeZone)
      : startOfDayInZone(nowMillis, timeZone) - 6 * 86_400_000;
  const scoped = expenses
    .filter((tx) => tx.occurredAtMillis >= startMs)
    .sort((a, b) => b.occurredAtMillis - a.occurredAtMillis);

  const totals: Record<string, number> = {};
  for (const tx of scoped) {
    totals[tx.currency] = (totals[tx.currency] || 0) + tx.amount;
  }

  const totalLine =
    Object.entries(totals)
      .map(([c, a]) => formatMoneyUz(a, c))
      .join(", ") || formatMoneyUz(0, primaryCurrency);

  const lines = [
    `<b>${period === "today" ? "Bugungi xarajatlar" : "Shu haftalik xarajatlar"}</b>`,
    `Jami: <b>${escapeHtml(totalLine)}</b>`,
    "",
  ];

  if (scoped.length === 0) {
    lines.push("Xarajatlar yo‘q.");
  } else {
    scoped.slice(0, 10).forEach((tx) => {
      const dateStr = formatUzDateShort(tx.occurredAtMillis, timeZone);
      lines.push(
        `• ${escapeHtml(tx.title)} (${escapeHtml(tx.category)}) — <b>${escapeHtml(
          formatMoneyUz(tx.amount, tx.currency)
        )}</b> · <i>${escapeHtml(dateStr)}</i>`
      );
    });
  }

  return {
    text: lines.join("\n"),
    inline_keyboard: [
      [
        { text: period === "today" ? "• Bugun" : "Bugun", callback_data: "exp:today" },
        { text: period === "week" ? "• Shu hafta" : "Shu hafta", callback_data: "exp:week" },
      ],
    ],
  };
}

export function buildDebtsMessage(
  debts: DebtItem[],
  timeZone: string
): { text: string; inline_keyboard: InlineButton[][] } {
  const active = debts.filter((d) => !d.closed && d.originalAmount - d.paidAmount > 0.001);
  const borrowed = active.filter((d) => d.direction === "borrowed");
  const lent = active.filter((d) => d.direction === "lent");

  const lines = ["<b>Oldi-berdi</b>", ""];
  if (active.length === 0) {
    lines.push("Faol qarzlar yo‘q.");
  } else {
    if (borrowed.length > 0) {
      lines.push("<b>Men qaytarishim kerak:</b>");
      borrowed.slice(0, 8).forEach((d) => {
        const rem = Math.max(0, d.originalAmount - d.paidAmount);
        const due = d.dueDateMillis > 0 ? ` · ${formatUzDateShort(d.dueDateMillis, timeZone)}` : "";
        lines.push(`• ${escapeHtml(d.personName)} — <b>${escapeHtml(formatMoneyUz(rem, d.currency))}</b>${due}`);
      });
      lines.push("");
    }
    if (lent.length > 0) {
      lines.push("<b>Menga qaytarishlari kerak:</b>");
      lent.slice(0, 8).forEach((d) => {
        const rem = Math.max(0, d.originalAmount - d.paidAmount);
        const due = d.dueDateMillis > 0 ? ` · ${formatUzDateShort(d.dueDateMillis, timeZone)}` : "";
        lines.push(`• ${escapeHtml(d.personName)} — <b>${escapeHtml(formatMoneyUz(rem, d.currency))}</b>${due}`);
      });
    }
  }

  return { text: lines.join("\n"), inline_keyboard: [] };
}

export function buildSettingsMessage(
  profile: UserProfile,
  state: TelegramUserState
): { text: string; inline_keyboard: InlineButton[][] } {
  const replyModeLabel =
    state.replyMode === "voice"
      ? "Faqat ovoz"
      : state.replyMode === "both"
        ? "Matn va ovoz"
        : "Faqat matn";
  const langLabel =
    state.voiceLanguage === "ru" ? "Rus" : state.voiceLanguage === "en" ? "Ingliz" : "O‘zbek";
  const eveningTime = `${String(profile.eveningReviewHour).padStart(2, "0")}:${String(
    profile.eveningReviewMinute
  ).padStart(2, "0")}`;
  const weeklyLabel = `${formatUzWeekday(state.weeklyReportDay)}, ${String(
    state.weeklyReportHour
  ).padStart(2, "0")}:00`;

  const lines = [
    "<b>Sozlamalar</b>",
    "",
    `Hisob: <b>${escapeHtml(profile.displayName)}</b>${
      state.telegramUsername ? ` (@${escapeHtml(state.telegramUsername)})` : ""
    }`,
    `Vaqt mintaqasi: <code>${escapeHtml(state.timezone)}</code>`,
    `Eslatmalar: <b>${state.remindersEnabled ? "Yoqilgan" : "O‘chirilgan"}</b>`,
    `Har soatlik oraliq: <b>${state.hourlyIntervalMinutes} daqiqa</b> (${String(
      state.activeStartHour
    ).padStart(2, "0")}:00–${String(state.activeEndHour).padStart(2, "0")}:00)`,
    `Aqlli eslatmalar (60/30/10 daq): <b>${state.smartRemindersEnabled ? "Yoqilgan" : "O‘chirilgan"}</b>`,
    `Kun yakuni: <b>${profile.notifyEvening ? eveningTime : "O‘chirilgan"}</b>`,
    `Haftalik hisobot: <b>${state.weeklyReportEnabled ? weeklyLabel : "O‘chirilgan"}</b>`,
    `Javob turi: <b>${replyModeLabel}</b> · Ovoz tili: <b>${langLabel}</b>`,
  ];

  const inline_keyboard: InlineButton[][] = [
    [
      {
        text: state.remindersEnabled ? "Eslatmalar: Yoqilgan" : "Eslatmalar: O‘chiq",
        callback_data: "set:rem_toggle",
      },
      {
        text: `Oraliq: ${state.hourlyIntervalMinutes} daq`,
        callback_data: "set:interval_next",
      },
    ],
    [
      {
        text: `Boshlash: ${String(state.activeStartHour).padStart(2, "0")}:00`,
        callback_data: "set:start_next",
      },
      {
        text: `Tugash: ${String(state.activeEndHour).padStart(2, "0")}:00`,
        callback_data: "set:end_next",
      },
    ],
    [
      {
        text: state.smartRemindersEnabled ? "Aqlli: Yoqilgan" : "Aqlli: O‘chiq",
        callback_data: "set:smart_toggle",
      },
      {
        text: profile.notifyEvening ? `Kun yakuni: ${eveningTime}` : "Kun yakuni: O‘chiq",
        callback_data: "set:evening_next",
      },
    ],
    [
      {
        text: `Haftalik: ${formatUzWeekday(state.weeklyReportDay).slice(0, 4)} ${String(
          state.weeklyReportHour
        ).padStart(2, "0")}:00`,
        callback_data: "set:weekly_next",
      },
      {
        text: `Javob: ${replyModeLabel}`,
        callback_data: "set:reply_next",
      },
    ],
    [
      { text: `Ovoz tili: ${langLabel}`, callback_data: "set:vlang_next" },
      { text: "Hisobni uzish", callback_data: "set:unlink_ask" },
    ],
  ];

  return { text: lines.join("\n"), inline_keyboard };
}

/**
 * Builds deterministic, strictly grounded facts from the user's real Firestore records
 * so Gemini answers memory questions with 100% accurate numbers and zero hallucination.
 */
export function buildGroundedMemoryFacts(
  tasks: TaskItem[],
  transactions: FinanceTransaction[],
  debts: DebtItem[],
  primaryCurrency: CurrencyCode,
  timeZone: string,
  nowMillis = Date.now()
): string {
  const openTasks = tasks.filter((t) => !t.completed);
  const todayTasks = openTasks.filter((t) => isTodayInZone(t.dueDateMillis, timeZone, nowMillis));
  const overdueTasks = openTasks.filter((t) =>
    isOverdueInZone(t.dueDateMillis, t.completed, timeZone, nowMillis)
  );

  const expenses = transactions
    .filter((tx) => tx.kind === "expense")
    .sort((a, b) => b.occurredAtMillis - a.occurredAtMillis);
  const todayStart = startOfDayInZone(nowMillis, timeZone);
  const weekStart = todayStart - 6 * 86_400_000;
  const monthStart = todayStart - 29 * 86_400_000;

  const sumByCurrency = (list: FinanceTransaction[]) => {
    const map: Record<string, number> = {};
    for (const tx of list) map[tx.currency] = (map[tx.currency] || 0) + tx.amount;
    return (
      Object.entries(map)
        .map(([c, a]) => formatMoneyUz(a, c))
        .join(", ") || formatMoneyUz(0, primaryCurrency)
    );
  };

  const activeDebts = debts.filter((d) => !d.closed && d.originalAmount - d.paidAmount > 0.001);

  return [
    `TODAY OPEN TASKS (${todayTasks.length}): ${
      todayTasks
        .slice(0, 12)
        .map((t) => `${t.title}${t.hasDueTime ? ` (${formatTime24InZone(t.dueDateMillis, timeZone)})` : ""}`)
        .join("; ") || "yo‘q"
    }`,
    `OVERDUE TASKS (${overdueTasks.length}): ${
      overdueTasks
        .slice(0, 10)
        .map((t) => `${t.title} (${formatUzDateShort(t.dueDateMillis, timeZone)})`)
        .join("; ") || "yo‘q"
    }`,
    `ALL OPEN TASKS COUNT: ${openTasks.length}`,
    `TODAY EXPENSES TOTAL: ${sumByCurrency(expenses.filter((e) => e.occurredAtMillis >= todayStart))}`,
    `THIS WEEK (7d) EXPENSES TOTAL: ${sumByCurrency(expenses.filter((e) => e.occurredAtMillis >= weekStart))}`,
    `THIS MONTH (30d) EXPENSES TOTAL: ${sumByCurrency(expenses.filter((e) => e.occurredAtMillis >= monthStart))}`,
    `RECENT EXPENSES (latest 8): ${
      expenses
        .slice(0, 8)
        .map(
          (e) =>
            `${e.title} (${e.category}): ${formatMoneyUz(e.amount, e.currency)} [${formatUzDateShort(
              e.occurredAtMillis,
              timeZone
            )}]`
        )
        .join("; ") || "yo‘q"
    }`,
    `ACTIVE DEBTS (${activeDebts.length}): ${
      activeDebts
        .map(
          (d) =>
            `${d.personName} (${d.direction === "borrowed" ? "men qaytarishim kerak" : "menga qaytarishi kerak"}): qoldiq ${formatMoneyUz(
              Math.max(0, d.originalAmount - d.paidAmount),
              d.currency
            )} (jami ${formatMoneyUz(d.originalAmount, d.currency)})`
        )
        .join("; ") || "yo‘q"
    }`,
  ].join("\n");
}

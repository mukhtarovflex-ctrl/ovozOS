import { onRequest } from "firebase-functions/v2/https";
import { onSchedule } from "firebase-functions/v2/scheduler";
import { loadConfig } from "./config";
import { initFirebase } from "./firebase";
import { FirestoreOvozRepository } from "./repository";
import { TelegramApiClient } from "./telegramApi";
import { GeminiServerService } from "./geminiService";
import { OvozTtsService } from "./ttsService";
import { OvozBotHandler } from "./botHandler";
import { createHttpApp } from "./httpApp";
import { runSchedulerTick } from "./scheduler";

function buildRuntime() {
  const config = loadConfig();
  const { db, auth } = initFirebase(config);
  const store = new FirestoreOvozRepository(db);
  const telegram = new TelegramApiClient(config.telegramBotToken);
  const gemini = new GeminiServerService(config);
  const tts = new OvozTtsService(config);
  const handler = new OvozBotHandler(config, store, telegram, gemini, tts);
  const app = createHttpApp({ config, store, telegram, gemini, handler, auth });
  return { config, store, telegram, gemini, app };
}

let cachedRuntime: ReturnType<typeof buildRuntime> | null = null;
function getRuntime() {
  if (!cachedRuntime) {
    cachedRuntime = buildRuntime();
  }
  return cachedRuntime;
}

/**
 * Single HTTPS Cloud Function serving:
 * - POST /telegram/webhook
 * - POST /api/telegram/link-code
 * - GET  /api/telegram/status
 * - POST /api/telegram/unlink
 * - GET  /health
 */
export const telegramBotApi = onRequest(
  {
    region: "asia-east1",
    memory: "512MiB",
    timeoutSeconds: 60,
    secrets: ["TELEGRAM_BOT_TOKEN", "TELEGRAM_WEBHOOK_SECRET", "GEMINI_API_KEY", "CRON_SECRET"],
  },
  (req, res) => {
    const { app } = getRuntime();
    app(req, res);
  }
);

/**
 * Single shared Cloud Scheduler task running every 1 minute across all linked users
 * (cost-efficient — never creates per-user or per-task Cloud Scheduler jobs!).
 */
export const telegramReminderTick = onSchedule(
  {
    schedule: "every 1 minutes",
    region: "asia-east1",
    memory: "512MiB",
    timeoutSeconds: 55,
    secrets: ["TELEGRAM_BOT_TOKEN", "GEMINI_API_KEY"],
  },
  async () => {
    const { store, telegram, gemini } = getRuntime();
    const summary = await runSchedulerTick(store, telegram, gemini);
    console.log("[Scheduler] tick complete:", JSON.stringify(summary));
  }
);

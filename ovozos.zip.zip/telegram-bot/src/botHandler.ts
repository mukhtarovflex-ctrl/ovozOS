import crypto from "crypto";
import { BotConfig } from "./config";
import { OvozStore } from "./repository";
import { MAIN_REPLY_KEYBOARD, ReplyMarkup, TelegramClient } from "./telegramApi";
import { GeminiClient } from "./geminiService";
import { TtsService } from "./ttsService";
import {
  computeDailyReportMetrics,
  computeWeeklyReportMetrics,
  findPotentialDuplicateTask,
  guessExpenseCategoryUz,
  validateParsedActions,
} from "./analytics";
import {
  buildDailyReviewMessage,
  buildWeeklyReportMessage,
  syncSmartRemindersForTask,
} from "./scheduler";
import {
  buildDebtsMessage,
  buildDraftConfirmationMessage,
  buildExpensesMessage,
  buildGroundedMemoryFacts,
  buildSettingsMessage,
  buildTasksListMessage,
} from "./botFormatters";
import { checkRateLimit, escapeHtml, sanitizeUntrustedText } from "./security";
import {
  dateKeyInZone,
  formatDueLabelUz,
  formatMoneyUz,
  parseIsoInZone,
  startOfDayInZone,
} from "./time";
import {
  BotSession,
  ParsedAction,
  TelegramCallbackQuery,
  TelegramMessage,
  TelegramUpdate,
  TelegramUserState,
  UserProfile,
} from "./types";

export class OvozBotHandler {
  constructor(
    private readonly config: BotConfig,
    private readonly store: OvozStore,
    private readonly telegram: TelegramClient,
    private readonly gemini: GeminiClient,
    private readonly tts: TtsService
  ) {}

  async handleUpdate(update: TelegramUpdate): Promise<void> {
    if (!update || typeof update.update_id !== "number") return;

    // Webhook retry idempotency: never create duplicate tasks/expenses/debts on Telegram redelivery!
    const claimed = await this.store.claimUpdateIdempotency(`upd_${update.update_id}`);
    if (!claimed) return;

    if (update.callback_query) {
      await this.handleCallbackQuery(update.callback_query);
      return;
    }
    if (update.message) {
      await this.handleMessage(update.message);
    }
  }

  private async sendAssistantReply(
    chatId: string | number,
    htmlText: string,
    state: TelegramUserState,
    replyMarkup?: ReplyMarkup
  ): Promise<number | undefined> {
    if (state.replyMode === "voice" || state.replyMode === "both") {
      const audio = await this.tts.synthesize(htmlText, state.voiceLanguage);
      if (audio) {
        if (state.replyMode === "voice") {
          const sentVoice = await this.telegram.sendVoice(chatId, audio.audioBuffer, {
            mimeType: audio.mimeType,
            filename: audio.filename,
            reply_markup: replyMarkup,
          });
          if (sentVoice) return sentVoice.message_id;
        } else {
          const sentMsg = await this.telegram.sendMessage(chatId, htmlText, {
            reply_markup: replyMarkup,
          });
          await this.telegram.sendVoice(chatId, audio.audioBuffer, {
            mimeType: audio.mimeType,
            filename: audio.filename,
          });
          return sentMsg?.message_id;
        }
      }
    }
    const sent = await this.telegram.sendMessage(chatId, htmlText, {
      reply_markup: replyMarkup,
    });
    return sent?.message_id;
  }

  private async handleMessage(msg: TelegramMessage): Promise<void> {
    const from = msg.from;
    if (!from || from.is_bot) return;

    // Requirement 17: strictly private chats only — never leak financial/personal data in groups!
    if (msg.chat.type !== "private") {
      return;
    }

    const tgUserId = String(from.id);
    const chatId = String(msg.chat.id);
    const rawText = (msg.text || msg.caption || "").trim();

    // Handle /start [linkCode] before requiring an active link
    if (rawText.startsWith("/start")) {
      const code = rawText.split(/\s+/)[1]?.trim() || "";
      await this.handleStartCommand(tgUserId, chatId, code);
      return;
    }

    // Verify Telegram ID <-> Firebase UID link on EVERY request
    const link = await this.store.getLinkByTelegramUserId(tgUserId);
    if (!link) {
      await this.telegram.sendMessage(
        chatId,
        "OvozOS hisobingiz hali ulanmagan.\n\nAndroid ilovasida <b>Sozlamalar → Telegram → Telegramni ulash</b> tugmasini bosing."
      );
      return;
    }

    const state = await this.store.getTelegramUserState(link.uid);
    if (!state || !state.linked) {
      await this.telegram.sendMessage(
        chatId,
        "OvozOS hisobingiz uzilgan. Qayta ulash uchun Android ilovasidagi Sozlamalar → Telegram bo‘limidan foydalaning."
      );
      return;
    }

    // Rate limiting check
    const session = await this.store.getSession(tgUserId);
    const rl = checkRateLimit(
      session.rateLimitCount,
      session.rateLimitWindowStart,
      this.config.rateLimitMaxPerMinute
    );
    session.rateLimitCount = rl.nextCount;
    session.rateLimitWindowStart = rl.nextWindowStart;
    if (!rl.allowed) {
      await this.store.saveSession(session);
      await this.telegram.sendMessage(
        chatId,
        "Juda ko‘p so‘rov yuborildi. Iltimos, bir daqiqadan so‘ng qayta urinib ko‘ring."
      );
      return;
    }

    // Keep chatId updated
    if (state.telegramChatId !== chatId) {
      await this.store.updateTelegramUserState(link.uid, { telegramChatId: chatId });
    }

    const profile = await this.store.getUserProfile(link.uid);

    // Check permanent 5-button menu labels (instant response, no Gemini cost)
    if (rawText === "Vazifalar") {
      const tasks = await this.store.listTasks(link.uid);
      const view = buildTasksListMessage(tasks, "today", state.timezone);
      await this.telegram.sendMessage(chatId, view.text, {
        reply_markup: { inline_keyboard: view.inline_keyboard },
      });
      return;
    }
    if (rawText === "Xarajatlar") {
      const txs = await this.store.listTransactions(link.uid);
      const view = buildExpensesMessage(txs, profile.primaryCurrency, state.timezone, "today");
      await this.telegram.sendMessage(chatId, view.text, {
        reply_markup: { inline_keyboard: view.inline_keyboard },
      });
      return;
    }
    if (rawText === "Oldi-berdi") {
      const debts = await this.store.listDebts(link.uid);
      const view = buildDebtsMessage(debts, state.timezone);
      await this.telegram.sendMessage(chatId, view.text);
      return;
    }
    if (rawText === "Hisobotlar") {
      await this.telegram.sendMessage(chatId, "<b>Hisobotlar</b>\n\nQaysi hisobotni ko‘rmoqchisiz?", {
        reply_markup: {
          inline_keyboard: [
            [
              { text: "Kun yakuni", callback_data: "rep:daily" },
              { text: "Haftalik hisobot", callback_data: "rep:weekly" },
            ],
          ],
        },
      });
      return;
    }
    if (rawText === "Sozlamalar") {
      const view = buildSettingsMessage(profile, state);
      await this.telegram.sendMessage(chatId, view.text, {
        reply_markup: { inline_keyboard: view.inline_keyboard },
      });
      return;
    }

    // Handle active inline text edit for a draft action or existing task
    if (session.pendingEdit && rawText) {
      await this.applyPendingDraftEdit(link.uid, chatId, session, rawText, state);
      return;
    }
    if (session.pendingTaskEdit && rawText) {
      await this.applyPendingTaskEdit(link.uid, chatId, session, rawText, state);
      return;
    }

    // Otherwise process voice or text command via Gemini
    await this.processCommandMessage(link.uid, chatId, msg, session, profile, state);
  }

  private async handleStartCommand(
    tgUserId: string,
    chatId: string,
    code: string
  ): Promise<void> {
    if (!code) {
      const existing = await this.store.getLinkByTelegramUserId(tgUserId);
      if (existing) {
        await this.telegram.sendMessage(
          chatId,
          "OvozOS tayyor. Ovozli yoki yozma xabar yuboring.",
          { reply_markup: MAIN_REPLY_KEYBOARD }
        );
      } else {
        await this.telegram.sendMessage(
          chatId,
          "<b>OvozOS Telegram yordamchi</b>\n\nHisobingizni ulash uchun Android ilovasida <b>Sozlamalar → Telegram → Telegramni ulash</b> tugmasini bosing."
        );
      }
      return;
    }

    const found = await this.store.peekLinkCode(code);
    if (!found) {
      await this.telegram.sendMessage(
        chatId,
        "Ulanish kodi noto‘g‘ri yoki muddati tugagan. Android ilovasidan yangi ulanish havolasini oling."
      );
      return;
    }

    const session = await this.store.getSession(tgUserId);
    session.pendingLinkCodeHash = found.codeHash;
    session.pendingLinkUid = found.doc.uid;
    session.pendingLinkTimezone = found.doc.timezone;
    await this.store.saveSession(session);

    const profile = await this.store.getUserProfile(found.doc.uid);
    await this.telegram.sendMessage(
      chatId,
      `<b>OvozOS hisobini bog‘lash</b>\n\nHisob: <b>${escapeHtml(
        profile.displayName
      )}</b>\nUshbu Telegram akkauntini OvozOS hisobingiz bilan bog‘lashni tasdiqlaysizmi?`,
      {
        reply_markup: {
          inline_keyboard: [
            [
              { text: "✓ Tasdiqlash", callback_data: "link:confirm" },
              { text: "Bekor qilish", callback_data: "link:cancel" },
            ],
          ],
        },
      }
    );
  }

  private async processCommandMessage(
    uid: string,
    chatId: string,
    msg: TelegramMessage,
    session: BotSession,
    profile: UserProfile,
    state: TelegramUserState
  ): Promise<void> {
    const isForwarded = Boolean(
      msg.forward_origin || msg.forward_date || msg.forward_from || msg.forward_from_chat
    );
    const originalMessageDateMillis =
      (msg.forward_origin?.date || msg.forward_date || 0) * 1000;
    const isVoice = Boolean(msg.voice || msg.audio);
    let audioBuffer: Buffer | undefined;
    let audioMimeType: string | undefined;

    await this.telegram.sendChatAction(chatId, "typing");

    if (isVoice) {
      const fileId = msg.voice?.file_id || msg.audio?.file_id || "";
      const downloaded = await this.telegram.downloadFileBuffer(fileId);
      if (!downloaded) {
        await this.telegram.sendMessage(
          chatId,
          "Ovozli xabarni yuklab bo‘lmadi. Iltimos, qisqaroq ovozli xabar yuboring yoki matn yozing."
        );
        return;
      }
      audioBuffer = downloaded.buffer;
      audioMimeType = downloaded.mimeType;
    }

    const textInput = (msg.text || msg.caption || "").trim();
    if (!audioBuffer && !textInput) return;

    const [tasks, debts, people, transactions] = await Promise.all([
      this.store.listTasks(uid),
      this.store.listDebts(uid),
      this.store.listPeople(uid),
      this.store.listTransactions(uid),
    ]);
    const recentExpenses = transactions.filter((t) => t.kind === "expense").slice(0, 20);

    // Expire stale clarification context after 10 minutes
    const priorClarification =
      session.clarificationContext &&
      Date.now() - session.clarificationContext.updatedAtMillis < 10 * 60_000
        ? session.clarificationContext
        : null;

    let analysis;
    try {
      analysis = await this.gemini.parseMessage({
        text: textInput || undefined,
        audioBuffer,
        audioMimeType,
        isForwarded: isForwarded || Boolean(priorClarification?.isForwarded),
        originalMessageDateMillis:
          originalMessageDateMillis || priorClarification?.originalMessageDateMillis,
        priorClarification: priorClarification
          ? {
              originalText: priorClarification.originalText,
              assistantQuestion: priorClarification.assistantQuestion,
            }
          : null,
        primaryCurrency: profile.primaryCurrency,
        timeZone: state.timezone,
        tasks,
        debts,
        people,
        recentExpenses,
      });
    } catch (err) {
      console.error("[Bot] Gemini parse error:", (err as Error).message);
      await this.telegram.sendMessage(
        chatId,
        "Xabarni tahlil qilishda vaqtinchalik xatolik yuz berdi. Bir ozdan so‘ng qayta urinib ko‘ring."
      );
      return;
    } finally {
      // Security Requirement 20: clear audio buffer reference immediately after analysis
      audioBuffer = undefined;
    }

    // 1. Clarification needed? Remember context and NEVER write ambiguous data to Firestore!
    if (analysis.clarificationQuestion) {
      const combinedOriginal = priorClarification
        ? `${priorClarification.originalText}\nJavob: ${analysis.transcript || textInput}`
        : analysis.transcript || textInput;
      session.clarificationContext = {
        originalText: sanitizeUntrustedText(combinedOriginal, 1000),
        assistantQuestion: analysis.clarificationQuestion,
        sourceVoice: isVoice || Boolean(priorClarification?.sourceVoice),
        isForwarded: isForwarded || Boolean(priorClarification?.isForwarded),
        originalMessageDateMillis:
          originalMessageDateMillis || priorClarification?.originalMessageDateMillis,
        turnCount: (priorClarification?.turnCount || 0) + 1,
        updatedAtMillis: Date.now(),
      };
      await this.store.saveSession(session);
      await this.sendAssistantReply(chatId, escapeHtml(analysis.clarificationQuestion), state);
      return;
    }

    // Clear clarification context once resolved
    session.clarificationContext = null;

    // 2. Pure memory question? Compute grounded facts deterministically & answer!
    if (
      analysis.isQuestionOnly ||
      (analysis.actions.length === 1 && analysis.actions[0].type === "ANSWER_QUESTION")
    ) {
      await this.store.saveSession(session);
      const facts = buildGroundedMemoryFacts(
        tasks,
        transactions,
        debts,
        profile.primaryCurrency,
        state.timezone
      );
      const answer = await this.gemini.answerFromMemory({
        question: analysis.transcript || textInput,
        primaryCurrency: profile.primaryCurrency,
        timeZone: state.timezone,
        groundedFacts: facts,
      });
      await this.sendAssistantReply(chatId, escapeHtml(answer), state);
      return;
    }

    // 3. Undo last action command ("Oxirgi qilgan ishingni bekor qil")
    if (analysis.actions.some((a) => a.type === "UNDO_LAST_ACTION")) {
      await this.store.saveSession(session);
      await this.handleUndoLatestBatch(uid, chatId, state);
      return;
    }

    // 4. Validate parsed actions against real schemas and user ownership
    const validated = validateParsedActions(
      analysis.actions,
      profile.primaryCurrency,
      tasks,
      debts
    );

    if (validated.length === 0) {
      await this.store.saveSession(session);
      await this.sendAssistantReply(
        chatId,
        "Vazifa, xarajat yoki qarz aniqlanmadi. Qisqa va aniqroq yozing yoki ovozli xabar yuboring.",
        state
      );
      return;
    }

    // 5. Check ambiguous COMPLETE_TASK (if multiple similar open tasks match and no exact ID)
    const ambiguousComplete = validated.find((a) => {
      if (a.type !== "COMPLETE_TASK" || a.matchedEntityId) return false;
      const matches = tasks.filter(
        (t) => !t.completed && t.title.toLowerCase().includes(a.title.toLowerCase().slice(0, 8))
      );
      return matches.length > 1;
    });
    if (ambiguousComplete) {
      const matches = tasks
        .filter(
          (t) =>
            !t.completed &&
            t.title.toLowerCase().includes(ambiguousComplete.title.toLowerCase().slice(0, 8))
        )
        .slice(0, 4);
      const question = `Qaysi vazifani nazarda tutdingiz?\n${matches
        .map((m, i) => `${i + 1}. ${m.title}`)
        .join("\n")}`;
      session.clarificationContext = {
        originalText: sanitizeUntrustedText(analysis.transcript || textInput, 800),
        assistantQuestion: question,
        sourceVoice: isVoice,
        isForwarded,
        turnCount: 1,
        updatedAtMillis: Date.now(),
      };
      await this.store.saveSession(session);
      await this.sendAssistantReply(chatId, escapeHtml(question), state);
      return;
    }

    // 6. Duplicate task detection (Requirement 10)
    for (const act of validated) {
      if (act.type === "CREATE_TASK") {
        const dup = findPotentialDuplicateTask(
          { title: act.title, dueDateMillis: act.dueDateMillis, hasDueTime: act.hasDueTime },
          tasks,
          state.timezone
        );
        if (dup) {
          act.duplicateTaskId = dup.id;
          act.duplicateTaskTitle = dup.title;
        }
      }
    }

    const hasFinancial = validated.some((a) =>
      ["CREATE_EXPENSE", "CREATE_DEBT_BORROWED", "CREATE_DEBT_LENT", "PAY_DEBT"].includes(a.type)
    );
    const hasDuplicates = validated.some((a) => Boolean(a.duplicateTaskId));

    // Requirement 3: Respect autoSaveVoice ONLY for non-financial, non-duplicate, non-forwarded commands
    if (profile.autoSaveVoice && !hasFinancial && !hasDuplicates && !isForwarded) {
      await this.store.saveSession(session);
      await this.commitActionsAndReport(uid, chatId, validated, isVoice, state);
      return;
    }

    // Store pending draft & show confirmation card with Saqlash / Tahrirlash / Bekor qilish
    const draftId = crypto.randomBytes(4).toString("hex");
    const preview = buildDraftConfirmationMessage(validated, isForwarded, state.timezone, draftId);
    const msgId = await this.sendAssistantReply(chatId, preview.text, state, {
      inline_keyboard: preview.inline_keyboard,
    });
    session.pendingDraft = {
      id: draftId,
      rawText: sanitizeUntrustedText(analysis.transcript || textInput, 1000),
      sourceVoice: isVoice,
      isForwarded,
      actions: validated,
      createdAtMillis: Date.now(),
      messageId: msgId,
    };
    await this.store.saveSession(session);
  }

  private async commitActionsAndReport(
    uid: string,
    chatId: string,
    actions: ParsedAction[],
    sourceVoice: boolean,
    state: TelegramUserState,
    editMessageId?: number
  ): Promise<void> {
    const batchId = `tg_${crypto.randomBytes(4).toString("hex")}`;
    const [existingTasks, existingDebts] = await Promise.all([
      this.store.listTasks(uid),
      this.store.listDebts(uid),
    ]);

    const savedLines: string[] = [];
    const failedLines: string[] = [];

    for (const act of actions) {
      if (!act.selected || act.duplicateResolution === "skip") continue;
      try {
        let personId = "";
        let personName = act.personName.trim();
        if (personName) {
          const p = await this.store.ensurePerson(uid, personName, batchId, sourceVoice);
          personId = p.id;
          personName = p.name;
        }

        if (act.type === "CREATE_TASK") {
          if (act.duplicateResolution === "update_existing" && act.duplicateTaskId) {
            const existing = existingTasks.find((t) => t.id === act.duplicateTaskId);
            if (existing) {
              const updated = {
                ...existing,
                title: act.title || existing.title,
                dueDateMillis: act.dueDateMillis > 0 ? act.dueDateMillis : existing.dueDateMillis,
                hasDueTime: act.dueDateMillis > 0 ? act.hasDueTime : existing.hasDueTime,
                priority: act.priority || existing.priority,
              };
              await this.store.updateTask(
                uid,
                existing,
                updated,
                `Vazifa yangilandi: ${updated.title}`,
                batchId,
                sourceVoice
              );
              await syncSmartRemindersForTask(this.store, uid, chatId, updated);
              savedLines.push(`✓ Yangilandi: ${escapeHtml(updated.title)}`);
              continue;
            }
          }
          const created = await this.store.addTask(
            uid,
            {
              title: act.title || "Vazifa",
              description: act.subtitle || "",
              dueDateMillis: act.dueDateMillis,
              hasDueTime: act.hasDueTime,
              priority: act.priority,
              category: act.category || "Shaxsiy",
              recurrence: act.recurrence || "none",
              completed: false,
              completedAtMillis: 0,
              personId,
              personName,
              goalId: "",
              noteText: "",
              reminderEnabled: act.dueDateMillis > 0,
            },
            batchId,
            sourceVoice
          );
          if (created.hasDueTime && created.dueDateMillis > Date.now()) {
            await syncSmartRemindersForTask(this.store, uid, chatId, created);
          }
          const due = formatDueLabelUz(created.dueDateMillis, created.hasDueTime, state.timezone);
          savedLines.push(`✓ ${escapeHtml(created.title)}${due ? ` — ${escapeHtml(due)}` : ""}`);
        } else if (act.type === "COMPLETE_TASK") {
          const target =
            existingTasks.find((t) => t.id === act.matchedEntityId) ||
            existingTasks.find(
              (t) => !t.completed && t.title.toLowerCase().includes(act.title.toLowerCase())
            );
          if (target) {
            await this.store.completeTaskWithRecurrence(
              uid,
              target,
              state.timezone,
              batchId,
              sourceVoice
            );
            savedLines.push(`✓ Bajarildi: ${escapeHtml(target.title)}`);
          } else {
            failedLines.push(`Mos vazifa topilmadi: ${escapeHtml(act.title)}`);
          }
        } else if (act.type === "CREATE_EXPENSE") {
          const cat = act.category || guessExpenseCategoryUz(act.title);
          const created = await this.store.addExpense(
            uid,
            {
              amount: act.amount,
              currency: act.currency,
              category: cat,
              title: act.title || cat,
              note: act.subtitle || "",
              occurredAtMillis: act.dueDateMillis > 0 ? act.dueDateMillis : Date.now(),
              personId,
              personName,
              goalId: "",
              debtId: "",
            },
            batchId,
            sourceVoice
          );
          savedLines.push(
            `✓ ${escapeHtml(created.category)} — ${escapeHtml(
              formatMoneyUz(created.amount, created.currency)
            )}`
          );
        } else if (act.type === "CREATE_DEBT_BORROWED" || act.type === "CREATE_DEBT_LENT") {
          const created = await this.store.addDebt(
            uid,
            {
              direction: act.type === "CREATE_DEBT_LENT" ? "lent" : "borrowed",
              personId,
              personName: personName || act.title || "Inson",
              originalAmount: act.amount,
              paidAmount: 0,
              currency: act.currency,
              note: act.subtitle || "",
              issuedAtMillis: Date.now(),
              dueDateMillis: act.dueDateMillis,
              closed: false,
              closedAtMillis: 0,
            },
            batchId,
            sourceVoice
          );
          savedLines.push(
            `✓ ${escapeHtml(created.personName)} (${
              created.direction === "lent" ? "berildi" : "olindi"
            }) — ${escapeHtml(formatMoneyUz(created.originalAmount, created.currency))}`
          );
        } else if (act.type === "PAY_DEBT") {
          const target =
            existingDebts.find((d) => d.id === act.matchedEntityId && !d.closed) ||
            existingDebts.find(
              (d) => !d.closed && d.personName.toLowerCase() === (personName || act.title).toLowerCase()
            );
          if (target) {
            const payAmt =
              act.amount > 0 ? act.amount : Math.max(0, target.originalAmount - target.paidAmount);
            const updated = await this.store.recordDebtPayment(
              uid,
              target,
              payAmt,
              batchId,
              sourceVoice
            );
            const rem = Math.max(0, updated.originalAmount - updated.paidAmount);
            savedLines.push(
              updated.closed
                ? `✓ ${escapeHtml(updated.personName)} qarzi yopildi`
                : `✓ ${escapeHtml(updated.personName)} qarzidan to‘landi (qoldiq: ${escapeHtml(
                    formatMoneyUz(rem, updated.currency)
                  )})`
            );
          } else {
            failedLines.push(`Faol qarz topilmadi: ${escapeHtml(personName || act.title)}`);
          }
        }
      } catch (err) {
        console.error("[Bot] Commit action error:", (err as Error).message);
        failedLines.push(`Saqlanmadi: ${escapeHtml(act.title)}`);
      }
    }

    // NEVER claim "Saqlandi" if Firestore write failed!
    const textParts: string[] = [];
    if (savedLines.length > 0) {
      textParts.push(`<b>Saqlandi (${savedLines.length}):</b>`, ...savedLines);
    }
    if (failedLines.length > 0) {
      if (textParts.length > 0) textParts.push("");
      textParts.push("<b>Saqlanmagan amallar:</b>", ...failedLines);
    }
    const finalText = textParts.join("\n") || "Hech qanday amal saqlanmadi.";

    const inlineKeyboard =
      savedLines.length > 0
        ? [
            [
              {
                text: savedLines.length > 1 ? "Barchasini bekor qilish" : "Bekor qilish",
                callback_data: `undo:batch:${batchId}`,
              },
              ...(savedLines.length > 1
                ? [{ text: "Alohida bekor qilish", callback_data: `undo:pick:${batchId}` }]
                : []),
            ],
          ]
        : [];

    if (editMessageId) {
      const edited = await this.telegram.editMessageText(chatId, editMessageId, finalText, {
        reply_markup: inlineKeyboard.length > 0 ? { inline_keyboard: inlineKeyboard } : undefined,
      });
      if (!edited) {
        await this.telegram.sendMessage(chatId, finalText, {
          reply_markup: inlineKeyboard.length > 0 ? { inline_keyboard: inlineKeyboard } : undefined,
        });
      }
    } else {
      await this.sendAssistantReply(
        chatId,
        finalText,
        state,
        inlineKeyboard.length > 0 ? { inline_keyboard: inlineKeyboard } : undefined
      );
    }
  }

  private async handleUndoLatestBatch(
    uid: string,
    chatId: string,
    state: TelegramUserState
  ): Promise<void> {
    const logs = (await this.store.listActionLogs(uid, 20)).filter((l) => !l.reverted);
    if (logs.length === 0) {
      await this.sendAssistantReply(chatId, "Bekor qilinadigan oxirgi amal topilmadi.", state);
      return;
    }
    const latestBatchId = logs[0].batchId;
    const res = await this.store.undoBatchSafe(uid, latestBatchId);
    let reply = "";
    if (res.undoneCount > 0) {
      reply = `<b>${res.undoneCount} ta amal bekor qilindi.</b>`;
    }
    if (res.skippedConflictCount > 0) {
      reply += `${reply ? "\n" : ""}${res.skippedConflictCount} ta yozuv boshqa qurilmada o‘zgartirilgani sababli bekor qilinmadi.`;
    }
    await this.sendAssistantReply(chatId, reply || "Amalni bekor qilib bo‘lmadi.", state);
  }

  private async applyPendingDraftEdit(
    uid: string,
    chatId: string,
    session: BotSession,
    rawText: string,
    state: TelegramUserState
  ): Promise<void> {
    const edit = session.pendingEdit!;
    const draft = session.pendingDraft;
    session.pendingEdit = null;
    if (!draft || draft.id !== edit.draftId || !draft.actions[edit.actionIndex]) {
      await this.store.saveSession(session);
      return;
    }
    const act = draft.actions[edit.actionIndex];
    if (edit.field === "title") {
      act.title = sanitizeUntrustedText(rawText, 200);
    } else if (edit.field === "amount") {
      const cleaned = rawText.replace(/[^\d.]/g, "");
      const num = parseFloat(cleaned);
      if (Number.isFinite(num) && num > 0) act.amount = num;
    } else if (edit.field === "due") {
      const parsed = parseIsoInZone(rawText.trim(), rawText.includes(":"), state.timezone);
      if (parsed.millis > 0) {
        act.dueDateMillis = parsed.millis;
        act.hasDueTime = parsed.hasDueTime;
        act.dueDateIso = rawText.trim();
      }
    }
    await this.store.saveSession(session);
    const preview = buildDraftConfirmationMessage(
      draft.actions,
      draft.isForwarded,
      state.timezone,
      draft.id
    );
    await this.telegram.sendMessage(chatId, preview.text, {
      reply_markup: { inline_keyboard: preview.inline_keyboard },
    });
  }

  private async applyPendingTaskEdit(
    uid: string,
    chatId: string,
    session: BotSession,
    rawText: string,
    state: TelegramUserState
  ): Promise<void> {
    const edit = session.pendingTaskEdit!;
    session.pendingTaskEdit = null;
    await this.store.saveSession(session);

    const task = await this.store.getTask(uid, edit.taskId);
    if (!task) {
      await this.telegram.sendMessage(chatId, "Vazifa topilmadi.");
      return;
    }
    if (edit.field === "title") {
      const updated = { ...task, title: sanitizeUntrustedText(rawText, 200) || task.title };
      await this.store.updateTask(uid, task, updated, `Vazifa nomi o‘zgardi: ${updated.title}`, `ed_${Date.now()}`, false);
      await this.telegram.sendMessage(chatId, `✓ Yangilandi: <b>${escapeHtml(updated.title)}</b>`);
    } else {
      const parsed = parseIsoInZone(rawText.trim(), rawText.includes(":"), state.timezone);
      if (parsed.millis <= 0) {
        await this.telegram.sendMessage(
          chatId,
          "Vaqtni <code>YYYY-MM-DD HH:mm</code> yoki <code>YYYY-MM-DD</code> ko‘rinishida yuboring."
        );
        return;
      }
      const updated = { ...task, dueDateMillis: parsed.millis, hasDueTime: parsed.hasDueTime };
      await this.store.updateTask(uid, task, updated, `Muddat o‘zgardi: ${updated.title}`, `ed_${Date.now()}`, false);
      await syncSmartRemindersForTask(this.store, uid, chatId, updated);
      const dueStr = formatDueLabelUz(updated.dueDateMillis, updated.hasDueTime, state.timezone);
      await this.telegram.sendMessage(
        chatId,
        `✓ Muddat yangilandi: <b>${escapeHtml(updated.title)}</b> — ${escapeHtml(dueStr)}`
      );
    }
  }

  private async handleCallbackQuery(cb: TelegramCallbackQuery): Promise<void> {
    const data = cb.data || "";
    const tgUserId = String(cb.from.id);
    const chatId = String(cb.message?.chat.id || cb.from.id);
    const messageId = cb.message?.message_id;

    if (cb.message && cb.message.chat.type !== "private") {
      await this.telegram.answerCallbackQuery(cb.id);
      return;
    }

    // 1. Account linking confirmation callbacks
    if (data === "link:confirm" || data === "link:cancel") {
      const session = await this.store.getSession(tgUserId);
      if (data === "link:cancel") {
        session.pendingLinkCodeHash = undefined;
        session.pendingLinkUid = undefined;
        await this.store.saveSession(session);
        await this.telegram.answerCallbackQuery(cb.id, "Bekor qilindi");
        if (messageId) {
          await this.telegram.editMessageText(chatId, messageId, "Hisobni bog‘lash bekor qilindi.");
        }
        return;
      }
      if (!session.pendingLinkCodeHash) {
        await this.telegram.answerCallbackQuery(cb.id, "Kod muddati tugagan", true);
        return;
      }
      const bound = await this.store.consumeLinkCodeAndBind(session.pendingLinkCodeHash, {
        telegramUserId: tgUserId,
        telegramChatId: chatId,
        telegramUsername: cb.from.username || "",
        telegramFirstName: cb.from.first_name || "",
      });
      session.pendingLinkCodeHash = undefined;
      session.pendingLinkUid = undefined;
      await this.store.saveSession(session);

      if (!bound) {
        await this.telegram.answerCallbackQuery(cb.id, "Kod allaqachon ishlatilgan yoki eskirgan", true);
        return;
      }
      await this.telegram.answerCallbackQuery(cb.id, "Ulandi!");
      if (messageId) {
        await this.telegram.editMessageText(
          chatId,
          messageId,
          "<b>OvozOS hisobingiz muvaffaqiyatli ulandi ✓</b>"
        );
      }
      await this.telegram.sendMessage(
        chatId,
        "Endi istalgan vaqtda ovozli yoki yozma xabar yuboring — qolganini OvozOS bajaradi.",
        { reply_markup: MAIN_REPLY_KEYBOARD }
      );
      return;
    }

    // All other callbacks require an active verified link
    const link = await this.store.getLinkByTelegramUserId(tgUserId);
    if (!link) {
      await this.telegram.answerCallbackQuery(cb.id, "Avval OvozOS hisobini ulang", true);
      return;
    }
    const state = await this.store.getTelegramUserState(link.uid);
    if (!state || !state.linked) {
      await this.telegram.answerCallbackQuery(cb.id, "Hisob uzilgan", true);
      return;
    }

    const parts = data.split(":");
    const prefix = parts[0];

    // 2. Draft save / cancel / edit / duplicate resolution
    if (prefix === "draft") {
      const action = parts[1];
      const draftId = parts[2];
      const session = await this.store.getSession(tgUserId);
      const draft = session.pendingDraft;

      if (!draft || draft.id !== draftId) {
        await this.telegram.answerCallbackQuery(cb.id, "Bu amal eskirgan", true);
        return;
      }

      if (action === "cancel") {
        session.pendingDraft = null;
        session.pendingEdit = null;
        await this.store.saveSession(session);
        await this.telegram.answerCallbackQuery(cb.id, "Bekor qilindi");
        if (messageId) {
          await this.telegram.editMessageText(chatId, messageId, "Bekor qilindi.");
        }
        return;
      }

      if (action === "save") {
        session.pendingDraft = null;
        session.pendingEdit = null;
        await this.store.saveSession(session);
        await this.telegram.answerCallbackQuery(cb.id, "Saqlanmoqda...");
        await this.commitActionsAndReport(
          link.uid,
          chatId,
          draft.actions,
          draft.sourceVoice,
          state,
          messageId
        );
        return;
      }

      if (action === "editmenu") {
        await this.telegram.answerCallbackQuery(cb.id);
        const rows = draft.actions.map((a, idx) => [
          { text: `Nom: ${a.title.slice(0, 18)}`, callback_data: `draft:edfield:${draftId}:${idx}:title` },
          ...(a.amount > 0
            ? [{ text: "Summa", callback_data: `draft:edfield:${draftId}:${idx}:amount` }]
            : [{ text: "Muddat", callback_data: `draft:edfield:${draftId}:${idx}:due` }]),
        ]);
        rows.push([{ text: "← Orqaga", callback_data: `draft:back:${draftId}` }]);
        if (messageId) {
          await this.telegram.editMessageText(chatId, messageId, "Qaysi maydonni tahrirlaysiz?", {
            reply_markup: { inline_keyboard: rows },
          });
        }
        return;
      }

      if (action === "edfield") {
        const idx = parseInt(parts[3] || "0", 10);
        const field = parts[4] as "title" | "amount" | "due";
        session.pendingEdit = { draftId, actionIndex: idx, field };
        await this.store.saveSession(session);
        await this.telegram.answerCallbackQuery(cb.id);
        const prompt =
          field === "title"
            ? "Yangi nomni yozing:"
            : field === "amount"
              ? "Yangi summani raqam bilan yozing (masalan: 45000):"
              : "Yangi muddatni yozing (masalan: 2026-11-26 15:00):";
        await this.telegram.sendMessage(chatId, prompt);
        return;
      }

      if (action === "back") {
        await this.telegram.answerCallbackQuery(cb.id);
        const preview = buildDraftConfirmationMessage(
          draft.actions,
          draft.isForwarded,
          state.timezone,
          draft.id
        );
        if (messageId) {
          await this.telegram.editMessageText(chatId, messageId, preview.text, {
            reply_markup: { inline_keyboard: preview.inline_keyboard },
          });
        }
        return;
      }
    }

    // 3. Duplicate task resolution
    if (prefix === "dup") {
      const mode = parts[1]; // upd | new
      const draftId = parts[2];
      const localId = parts[3];
      const session = await this.store.getSession(tgUserId);
      const draft = session.pendingDraft;
      if (!draft || draft.id !== draftId) {
        await this.telegram.answerCallbackQuery(cb.id, "Eskirgan amal", true);
        return;
      }
      const target = draft.actions.find((a) => a.localId === localId);
      if (target) {
        target.duplicateResolution = mode === "upd" ? "update_existing" : "create_new";
      }
      await this.store.saveSession(session);
      await this.telegram.answerCallbackQuery(cb.id, "Tanlandi");
      const preview = buildDraftConfirmationMessage(
        draft.actions,
        draft.isForwarded,
        state.timezone,
        draft.id
      );
      if (messageId) {
        await this.telegram.editMessageText(chatId, messageId, preview.text, {
          reply_markup: { inline_keyboard: preview.inline_keyboard },
        });
      }
      return;
    }

    // 4. Task completion / snooze / edit / reschedule
    if (prefix === "tdone") {
      const taskId = parts[1];
      const task = await this.store.getTask(link.uid, taskId);
      if (!task) {
        await this.telegram.answerCallbackQuery(cb.id, "Vazifa topilmadi", true);
        return;
      }
      const batchId = `tgchk_${crypto.randomBytes(3).toString("hex")}`;
      const { nextTask } = await this.store.completeTaskWithRecurrence(
        link.uid,
        task,
        state.timezone,
        batchId,
        false
      );
      if (nextTask && nextTask.hasDueTime) {
        await syncSmartRemindersForTask(this.store, link.uid, chatId, nextTask);
      }
      await this.telegram.answerCallbackQuery(cb.id, "Bajarildi ✓");
      if (messageId) {
        const nextLine = nextTask
          ? `\n<i>Keyingi takrorlanish: ${escapeHtml(
              formatDueLabelUz(nextTask.dueDateMillis, nextTask.hasDueTime, state.timezone)
            )}</i>`
          : "";
        await this.telegram.editMessageText(
          chatId,
          messageId,
          `✅ <s>${escapeHtml(task.title)}</s>${nextLine}`,
          {
            reply_markup: {
              inline_keyboard: [[{ text: "Bekor qilish", callback_data: `undo:batch:${batchId}` }]],
            },
          }
        );
      }
      return;
    }

    if (prefix === "tsnzmenu") {
      const taskId = parts[1];
      const task = await this.store.getTask(link.uid, taskId);
      if (!task || task.completed) {
        await this.telegram.answerCallbackQuery(cb.id, "Vazifa allaqachon bajarilgan");
        return;
      }
      await this.telegram.answerCallbackQuery(cb.id);
      const text = `<b>Keyinroq eslatish</b>\n\n${escapeHtml(task.title)}`;
      const markup = {
        inline_keyboard: [
          [
            { text: "15 daqiqadan keyin", callback_data: `tsnz:${taskId}:15` },
            { text: "30 daqiqadan keyin", callback_data: `tsnz:${taskId}:30` },
          ],
          [{ text: "1 soatdan keyin", callback_data: `tsnz:${taskId}:60` }],
        ],
      };
      if (messageId) {
        await this.telegram.editMessageText(chatId, messageId, text, { reply_markup: markup });
      } else {
        await this.telegram.sendMessage(chatId, text, { reply_markup: markup });
      }
      return;
    }

    if (prefix === "tsnz") {
      const taskId = parts[1];
      const mins = Math.max(5, parseInt(parts[2] || "30", 10));
      const task = await this.store.getTask(link.uid, taskId);
      if (!task || task.completed) {
        await this.telegram.answerCallbackQuery(cb.id, "Vazifa allaqachon bajarilgan");
        return;
      }
      // Requirement 6: Snooze NEVER modifies the task's original dueDateMillis!
      const now = Date.now();
      await this.store.upsertReminder(
        {
          uid: link.uid,
          telegramChatId: chatId,
          taskId: task.id,
          kind: "snooze",
          triggerAtMillis: now + mins * 60_000,
          taskDueDateMillis: task.dueDateMillis,
          status: "pending",
          createdAtMillis: now,
          sentAtMillis: 0,
        },
        `${link.uid}_${task.id}_snooze`
      );
      await this.telegram.answerCallbackQuery(cb.id, `${mins} daqiqadan keyin eslatiladi`);
      if (messageId) {
        await this.telegram.editMessageText(
          chatId,
          messageId,
          `⏰ <b>${escapeHtml(task.title)}</b> — ${mins} daqiqadan keyin qayta eslatiladi.`
        );
      }
      return;
    }

    if (prefix === "tedit" || prefix === "tresch") {
      const taskId = parts[1];
      const task = await this.store.getTask(link.uid, taskId);
      if (!task) {
        await this.telegram.answerCallbackQuery(cb.id, "Vazifa topilmadi");
        return;
      }
      await this.telegram.answerCallbackQuery(cb.id);
      if (prefix === "tresch") {
        const session = await this.store.getSession(tgUserId);
        session.pendingTaskEdit = { taskId, field: "due" };
        await this.store.saveSession(session);
        await this.telegram.sendMessage(
          chatId,
          `<b>${escapeHtml(task.title)}</b> uchun yangi muddatni yozing (masalan: <code>2026-11-26 16:00</code>) yoki tezkor tanlang:`,
          {
            reply_markup: {
              inline_keyboard: [
                [
                  { text: "+1 soat", callback_data: `tqresch:${taskId}:1h` },
                  { text: "Ertaga 10:00", callback_data: `tqresch:${taskId}:tmrw10` },
                ],
              ],
            },
          }
        );
      } else {
        await this.telegram.sendMessage(chatId, `<b>${escapeHtml(task.title)}</b>`, {
          reply_markup: {
            inline_keyboard: [
              [
                { text: "Nomini o‘zgartirish", callback_data: `tedask:${taskId}:title` },
                { text: "Muddatni o‘zgartirish", callback_data: `tresch:${taskId}` },
              ],
            ],
          },
        });
      }
      return;
    }

    if (prefix === "tedask") {
      const taskId = parts[1];
      const session = await this.store.getSession(tgUserId);
      session.pendingTaskEdit = { taskId, field: "title" };
      await this.store.saveSession(session);
      await this.telegram.answerCallbackQuery(cb.id);
      await this.telegram.sendMessage(chatId, "Vazifaning yangi nomini yozing:");
      return;
    }

    if (prefix === "tqresch") {
      const taskId = parts[1];
      const preset = parts[2];
      const task = await this.store.getTask(link.uid, taskId);
      if (!task) {
        await this.telegram.answerCallbackQuery(cb.id, "Vazifa topilmadi");
        return;
      }
      const newDue =
        preset === "1h"
          ? Math.max(Date.now(), task.dueDateMillis) + 3_600_000
          : startOfDayInZone(Date.now(), state.timezone) + 86_400_000 + 10 * 3_600_000;
      const updated = { ...task, dueDateMillis: newDue, hasDueTime: true };
      await this.store.updateTask(
        link.uid,
        task,
        updated,
        `Muddat ko‘chirildi: ${updated.title}`,
        `rs_${Date.now()}`,
        false
      );
      await syncSmartRemindersForTask(this.store, link.uid, chatId, updated);
      const session = await this.store.getSession(tgUserId);
      session.pendingTaskEdit = null;
      await this.store.saveSession(session);
      await this.telegram.answerCallbackQuery(cb.id, "Muddat yangilandi ✓");
      if (messageId) {
        await this.telegram.editMessageText(
          chatId,
          messageId,
          `✓ <b>${escapeHtml(updated.title)}</b> — ${escapeHtml(
            formatDueLabelUz(updated.dueDateMillis, true, state.timezone)
          )}`
        );
      }
      return;
    }

    // 5. Menu tabs (update existing message in place!)
    if (prefix === "tlist") {
      const filter = (parts[1] || "today") as "today" | "all" | "overdue";
      const tasks = await this.store.listTasks(link.uid);
      const view = buildTasksListMessage(tasks, filter, state.timezone);
      await this.telegram.answerCallbackQuery(cb.id);
      if (messageId) {
        await this.telegram.editMessageText(chatId, messageId, view.text, {
          reply_markup: { inline_keyboard: view.inline_keyboard },
        });
      }
      return;
    }

    if (prefix === "exp") {
      const period = parts[1] === "week" ? "week" : "today";
      const [profile, txs] = await Promise.all([
        this.store.getUserProfile(link.uid),
        this.store.listTransactions(link.uid),
      ]);
      const view = buildExpensesMessage(txs, profile.primaryCurrency, state.timezone, period);
      await this.telegram.answerCallbackQuery(cb.id);
      if (messageId) {
        await this.telegram.editMessageText(chatId, messageId, view.text, {
          reply_markup: { inline_keyboard: view.inline_keyboard },
        });
      }
      return;
    }

    // 6. Reports & Kun yakuni actions
    if (prefix === "rep" || prefix === "rev") {
      const sub = parts[1];
      const profile = await this.store.getUserProfile(link.uid);
      if (prefix === "rep" && sub === "daily") {
        await this.telegram.answerCallbackQuery(cb.id);
        const [tasks, txs] = await Promise.all([
          this.store.listTasks(link.uid),
          this.store.listTransactions(link.uid),
        ]);
        const metrics = computeDailyReportMetrics(tasks, txs, profile.primaryCurrency, state.timezone);
        const summary = await this.gemini.summarizeDailyReport(metrics, state.timezone);
        const view = buildDailyReviewMessage(metrics, summary, state.timezone, Date.now());
        if (messageId) {
          await this.telegram.editMessageText(chatId, messageId, view.text, {
            reply_markup: { inline_keyboard: view.inline_keyboard },
          });
        }
        return;
      }
      if (prefix === "rep" && sub === "weekly") {
        await this.telegram.answerCallbackQuery(cb.id);
        const [tasks, txs, debts] = await Promise.all([
          this.store.listTasks(link.uid),
          this.store.listTransactions(link.uid),
          this.store.listDebts(link.uid),
        ]);
        const metrics = computeWeeklyReportMetrics(
          tasks,
          txs,
          debts,
          profile.primaryCurrency,
          state.timezone
        );
        const summary = await this.gemini.summarizeWeeklyReport(metrics);
        const text = buildWeeklyReportMessage(metrics, summary);
        if (messageId) {
          await this.telegram.editMessageText(chatId, messageId, text);
        }
        return;
      }
      if (prefix === "rev" && sub === "remaining") {
        const tasks = await this.store.listTasks(link.uid);
        const view = buildTasksListMessage(tasks, "today", state.timezone);
        await this.telegram.answerCallbackQuery(cb.id);
        await this.telegram.sendMessage(chatId, view.text, {
          reply_markup: { inline_keyboard: view.inline_keyboard },
        });
        return;
      }
      if (prefix === "rev" && sub === "tomorrow") {
        const tasks = await this.store.listTasks(link.uid);
        const metrics = computeDailyReportMetrics(tasks, [], profile.primaryCurrency, state.timezone);
        const lines = ["<b>Ertangi reja</b>", ""];
        if (metrics.tomorrowTasks.length === 0) {
          lines.push("Ertaga uchun vazifalar rejalashtirilmagan.");
        } else {
          metrics.tomorrowTasks.forEach((t, i) => {
            const due = formatDueLabelUz(t.dueDateMillis, t.hasDueTime, state.timezone);
            lines.push(`${i + 1}. ☐ ${escapeHtml(t.title)} · <i>${escapeHtml(due)}</i>`);
          });
        }
        await this.telegram.answerCallbackQuery(cb.id);
        await this.telegram.sendMessage(chatId, lines.join("\n"));
        return;
      }
      if (prefix === "rev" && sub === "move_ask") {
        const tasks = await this.store.listTasks(link.uid);
        const metrics = computeDailyReportMetrics(tasks, [], profile.primaryCurrency, state.timezone);
        if (metrics.remainingTodayTasks.length === 0) {
          await this.telegram.answerCallbackQuery(cb.id, "Qolgan vazifalar yo‘q");
          return;
        }
        const session = await this.store.getSession(tgUserId);
        session.pendingMoveTomorrow = {
          taskIds: metrics.remainingTodayTasks.map((t) => t.id),
          dateKey: dateKeyInZone(Date.now(), state.timezone),
        };
        await this.store.saveSession(session);
        await this.telegram.answerCallbackQuery(cb.id);
        await this.telegram.sendMessage(
          chatId,
          `Bugungi bajarilmagan <b>${metrics.remainingTodayTasks.length} ta</b> vazifani ertangi kunga ko‘chirishni tasdiqlaysizmi?`,
          {
            reply_markup: {
              inline_keyboard: [
                [
                  { text: "✓ Ha, ko‘chirish", callback_data: "rev:move_yes" },
                  { text: "Bekor qilish", callback_data: "rev:move_no" },
                ],
              ],
            },
          }
        );
        return;
      }
      if (prefix === "rev" && (sub === "move_yes" || sub === "move_no")) {
        const session = await this.store.getSession(tgUserId);
        const pending = session.pendingMoveTomorrow;
        session.pendingMoveTomorrow = null;
        await this.store.saveSession(session);
        if (sub === "move_no" || !pending) {
          await this.telegram.answerCallbackQuery(cb.id, "Bekor qilindi");
          if (messageId) await this.telegram.editMessageText(chatId, messageId, "Ko‘chirish bekor qilindi.");
          return;
        }
        const batchId = `mv_${crypto.randomBytes(3).toString("hex")}`;
        let moved = 0;
        for (const tid of pending.taskIds) {
          const t = await this.store.getTask(link.uid, tid);
          if (t && !t.completed) {
            const shiftedDue = t.dueDateMillis > 0
              ? t.dueDateMillis + 86_400_000
              : startOfDayInZone(Date.now(), state.timezone) + 86_400_000 + 12 * 3_600_000;
            const updated = { ...t, dueDateMillis: shiftedDue };
            await this.store.updateTask(link.uid, t, updated, `Ertaga ko‘chirildi: ${t.title}`, batchId, false);
            if (updated.hasDueTime) {
              await syncSmartRemindersForTask(this.store, link.uid, chatId, updated);
            }
            moved++;
          }
        }
        await this.telegram.answerCallbackQuery(cb.id, `${moved} ta vazifa ko‘chirildi`);
        if (messageId) {
          await this.telegram.editMessageText(
            chatId,
            messageId,
            `✓ <b>${moved} ta</b> vazifa ertangi kunga ko‘chirildi.`
          );
        }
        return;
      }
    }

    // 7. Undo callbacks (entire batch OR pick individual action in batch)
    if (prefix === "undo") {
      const mode = parts[1];
      const targetId = parts[2];
      if (mode === "batch") {
        const res = await this.store.undoBatchSafe(link.uid, targetId);
        await this.telegram.answerCallbackQuery(
          cb.id,
          res.undoneCount > 0 ? `${res.undoneCount} ta amal bekor qilindi` : "Bekor qilinmadi"
        );
        if (messageId) {
          let txt = res.undoneCount > 0 ? `↩️ <b>${res.undoneCount} ta amal bekor qilindi.</b>` : "Bekor qilinadigan amal topilmadi.";
          if (res.skippedConflictCount > 0) {
            txt += `\n${res.skippedConflictCount} ta yozuv boshqa qurilmada o‘zgartirilgani uchun saqlab qolindi.`;
          }
          await this.telegram.editMessageText(chatId, messageId, txt);
        }
        return;
      }
      if (mode === "pick") {
        const logs = (await this.store.listActionLogs(link.uid, 30)).filter(
          (l) => l.batchId === targetId && !l.reverted
        );
        await this.telegram.answerCallbackQuery(cb.id);
        if (logs.length === 0) return;
        const rows = logs.map((l) => [
          { text: `↩️ ${l.summaryText.slice(0, 32)}`, callback_data: `undo:one:${l.id}` },
        ]);
        if (messageId) {
          await this.telegram.editMessageText(chatId, messageId, "Qaysi amalni bekor qilasiz?", {
            reply_markup: { inline_keyboard: rows },
          });
        }
        return;
      }
      if (mode === "one") {
        const logs = await this.store.listActionLogs(link.uid, 30);
        const log = logs.find((l) => l.id === targetId);
        if (!log) {
          await this.telegram.answerCallbackQuery(cb.id, "Amal topilmadi");
          return;
        }
        const res = await this.store.undoActionLogSafe(link.uid, log);
        const msgText =
          res.status === "undone"
            ? `↩️ Bekor qilindi: ${escapeHtml(log.summaryText)}`
            : res.status === "conflict"
              ? "Bu yozuv boshqa qurilmada o‘zgartirilgan, shu sababli bekor qilinmadi."
              : "Allaqachon bekor qilingan.";
        await this.telegram.answerCallbackQuery(cb.id, res.status === "undone" ? "Bekor qilindi" : "O‘tkazib yuborildi");
        if (messageId) {
          await this.telegram.editMessageText(chatId, messageId, msgText);
        }
        return;
      }
    }

    // 8. Settings callbacks (automatically saved, synced with Android profile where shared!)
    if (prefix === "set") {
      const key = parts[1];
      if (key === "unlink_ask") {
        await this.telegram.answerCallbackQuery(cb.id);
        if (messageId) {
          await this.telegram.editMessageText(
            chatId,
            messageId,
            "<b>Telegram hisobini uzish</b>\n\nHisob uzilganda botning ma’lumotlarga kirishi va barcha avtomatik eslatmalar darhol to‘xtaydi. Davom etasizmi?",
            {
              reply_markup: {
                inline_keyboard: [
                  [
                    { text: "Ha, uzish", callback_data: "set:unlink_yes" },
                    { text: "Bekor qilish", callback_data: "set:back" },
                  ],
                ],
              },
            }
          );
        }
        return;
      }
      if (key === "unlink_yes") {
        await this.store.unlinkAccount(link.uid, tgUserId);
        await this.telegram.answerCallbackQuery(cb.id, "Hisob uzildi");
        if (messageId) {
          await this.telegram.editMessageText(
            chatId,
            messageId,
            "Telegram hisobingiz OvozOS tizimidan uzildi. Eslatmalar darhol to‘xtatildi."
          );
        }
        return;
      }

      const profile = await this.store.getUserProfile(link.uid);
      if (key === "rem_toggle") {
        await this.store.updateTelegramUserState(link.uid, {
          remindersEnabled: !state.remindersEnabled,
        });
      } else if (key === "interval_next") {
        const order = [30, 60, 120, 180];
        const next = order[(order.indexOf(state.hourlyIntervalMinutes) + 1) % order.length];
        await this.store.updateTelegramUserState(link.uid, { hourlyIntervalMinutes: next });
      } else if (key === "start_next") {
        const order = [7, 8, 9, 10];
        const next = order[(order.indexOf(state.activeStartHour) + 1) % order.length];
        await this.store.updateTelegramUserState(link.uid, { activeStartHour: next });
      } else if (key === "end_next") {
        const order = [20, 21, 22, 23];
        const next = order[(order.indexOf(state.activeEndHour) + 1) % order.length];
        await this.store.updateTelegramUserState(link.uid, { activeEndHour: next });
      } else if (key === "smart_toggle") {
        await this.store.updateTelegramUserState(link.uid, {
          smartRemindersEnabled: !state.smartRemindersEnabled,
        });
      } else if (key === "evening_next") {
        // Shared setting with Android! Cycles 20:00 -> 21:00 -> 22:00 -> Off -> 20:00
        if (!profile.notifyEvening) {
          await this.store.updateUserProfile(link.uid, { notifyEvening: true, eveningReviewHour: 20, eveningReviewMinute: 0 });
        } else if (profile.eveningReviewHour < 22) {
          await this.store.updateUserProfile(link.uid, { eveningReviewHour: profile.eveningReviewHour + 1, eveningReviewMinute: 0 });
        } else {
          await this.store.updateUserProfile(link.uid, { notifyEvening: false });
        }
      } else if (key === "weekly_next") {
        // Cycles Sunday 20:00 -> Saturday 20:00 -> Friday 19:00 -> Off -> Sunday 20:00
        if (!state.weeklyReportEnabled) {
          await this.store.updateTelegramUserState(link.uid, {
            weeklyReportEnabled: true,
            weeklyReportDay: 0,
            weeklyReportHour: 20,
          });
        } else if (state.weeklyReportDay === 0) {
          await this.store.updateTelegramUserState(link.uid, { weeklyReportDay: 6, weeklyReportHour: 20 });
        } else if (state.weeklyReportDay === 6) {
          await this.store.updateTelegramUserState(link.uid, { weeklyReportDay: 5, weeklyReportHour: 19 });
        } else {
          await this.store.updateTelegramUserState(link.uid, { weeklyReportEnabled: false });
        }
      } else if (key === "reply_next") {
        const order: Array<"text" | "voice" | "both"> = ["text", "voice", "both"];
        const next = order[(order.indexOf(state.replyMode) + 1) % order.length];
        await this.store.updateTelegramUserState(link.uid, { replyMode: next });
      } else if (key === "vlang_next") {
        const order: Array<"uz" | "ru" | "en"> = ["uz", "ru", "en"];
        const next = order[(order.indexOf(state.voiceLanguage) + 1) % order.length];
        await this.store.updateTelegramUserState(link.uid, { voiceLanguage: next });
      }

      const [freshProfile, freshState] = await Promise.all([
        this.store.getUserProfile(link.uid),
        this.store.getTelegramUserState(link.uid),
      ]);
      await this.telegram.answerCallbackQuery(cb.id, "Saqlandi");
      if (messageId && freshState) {
        const view = buildSettingsMessage(freshProfile, freshState);
        await this.telegram.editMessageText(chatId, messageId, view.text, {
          reply_markup: { inline_keyboard: view.inline_keyboard },
        });
      }
      return;
    }

    await this.telegram.answerCallbackQuery(cb.id);
  }
}

import express, { Request, Response } from "express";
import type * as admin from "firebase-admin";
import { BotConfig } from "./config";
import { OvozStore } from "./repository";
import { TelegramClient } from "./telegramApi";
import { GeminiClient } from "./geminiService";
import { OvozBotHandler } from "./botHandler";
import { runSchedulerTick } from "./scheduler";
import { verifyFirebaseBearerToken, verifySecretHeader } from "./security";
import { normalizeTimezone } from "./time";
import { TelegramUpdate } from "./types";

export interface HttpAppDeps {
  config: BotConfig;
  store: OvozStore;
  telegram: TelegramClient;
  gemini: GeminiClient;
  handler: OvozBotHandler;
  auth: admin.auth.Auth;
}

export function createHttpApp(deps: HttpAppDeps): express.Express {
  const { config, store, telegram, gemini, handler, auth } = deps;
  const app = express();

  // Limit JSON payload size to protect server memory
  app.use(express.json({ limit: "1mb" }));

  // Health probe (no secrets returned)
  app.get("/health", (_req: Request, res: Response) => {
    res.json({
      ok: true,
      service: "ovozos-telegram-bot",
      botConfigured: Boolean(config.telegramBotToken),
      geminiConfigured: Boolean(config.geminiApiKey),
    });
  });

  // 1. Secure Telegram Webhook receiver
  app.post("/telegram/webhook", async (req: Request, res: Response) => {
    const providedSecret = req.header("X-Telegram-Bot-Api-Secret-Token");
    if (!verifySecretHeader(providedSecret, config.telegramWebhookSecret)) {
      res.status(401).json({ ok: false, error: "Invalid webhook secret" });
      return;
    }

    const update = req.body as TelegramUpdate;
    if (!update || typeof update.update_id !== "number") {
      res.status(400).json({ ok: false, error: "Invalid update payload" });
      return;
    }

    try {
      await handler.handleUpdate(update);
      res.status(200).json({ ok: true });
    } catch (err) {
      console.error("[Webhook] Unhandled error:", (err as Error).message);
      // Respond 200 to prevent infinite Telegram retry storm on non-transient logic errors
      res.status(200).json({ ok: false });
    }
  });

  // 2. Android -> Server: Create one-time 10-minute Telegram link code
  app.post("/api/telegram/link-code", async (req: Request, res: Response) => {
    const user = await verifyFirebaseBearerToken(req, auth);
    if (!user) {
      res.status(401).json({ ok: false, error: "Unauthorized" });
      return;
    }

    try {
      const tz = normalizeTimezone(
        typeof req.body?.timezone === "string" ? req.body.timezone : undefined
      );
      const { rawCode, expiresAtMillis } = await store.createLinkCode(user.uid, tz);

      // Resolve public bot username (env first, else live getMe)
      let botUsername = config.telegramBotUsername;
      if (!botUsername && config.telegramBotToken) {
        const me = await telegram.getMe();
        botUsername = me?.username || "";
      }

      const deepLink = botUsername
        ? `https://t.me/${botUsername}?start=${encodeURIComponent(rawCode)}`
        : "";

      res.status(200).json({
        ok: true,
        code: rawCode,
        botUsername,
        deepLink,
        expiresAtMillis,
      });
    } catch (err) {
      console.error("[API] link-code failed:", (err as Error).message);
      res.status(500).json({ ok: false, error: "Ulanish kodini yaratib bo‘lmadi." });
    }
  });

  // 3. Android -> Server: Check live Telegram link status & bot health
  app.get("/api/telegram/status", async (req: Request, res: Response) => {
    const user = await verifyFirebaseBearerToken(req, auth);
    if (!user) {
      res.status(401).json({ ok: false, error: "Unauthorized" });
      return;
    }

    try {
      const state = await store.getTelegramUserState(user.uid);
      const botMe = config.telegramBotToken ? await telegram.getMe() : null;
      const botUsername = botMe?.username || config.telegramBotUsername || "";
      res.status(200).json({
        ok: true,
        botOnline: Boolean(botMe),
        botUsername,
        linked: Boolean(state?.linked),
        telegramUsername: state?.telegramUsername || "",
        telegramFirstName: state?.telegramFirstName || "",
        linkedAtMillis: state?.linkedAtMillis || 0,
        timezone: state?.timezone || "Asia/Tashkent",
      });
    } catch (err) {
      console.error("[API] status failed:", (err as Error).message);
      res.status(500).json({ ok: false, error: "Holatni tekshirib bo‘lmadi." });
    }
  });

  // 4. Android -> Server: Immediately unlink Telegram account & cancel all scheduled reminders
  app.post("/api/telegram/unlink", async (req: Request, res: Response) => {
    const user = await verifyFirebaseBearerToken(req, auth);
    if (!user) {
      res.status(401).json({ ok: false, error: "Unauthorized" });
      return;
    }

    try {
      const prev = await store.getTelegramUserState(user.uid);
      await store.unlinkAccount(user.uid, prev?.telegramUserId);
      if (prev?.linked && prev.telegramChatId) {
        await telegram
          .sendMessage(
            prev.telegramChatId,
            "Telegram hisobingiz OvozOS Android ilovasidan uzildi. Avtomatik eslatmalar to‘xtatildi."
          )
          .catch(() => undefined);
      }
      res.status(200).json({ ok: true });
    } catch (err) {
      console.error("[API] unlink failed:", (err as Error).message);
      res.status(500).json({ ok: false, error: "Hisobni uzishda xatolik yuz berdi." });
    }
  });

  // 5. External Cloud Scheduler / Cron endpoint (for Cloud Run / Railway / Render)
  app.post("/cron/tick", async (req: Request, res: Response) => {
    const secret = req.header("X-Cron-Secret");
    if (!verifySecretHeader(secret, config.cronSecret)) {
      res.status(401).json({ ok: false, error: "Invalid cron secret" });
      return;
    }

    try {
      const summary = await runSchedulerTick(store, telegram, gemini);
      res.status(200).json({ ok: true, summary });
    } catch (err) {
      console.error("[Cron] tick error:", (err as Error).message);
      res.status(500).json({ ok: false, error: "Scheduler tick failed" });
    }
  });

  return app;
}

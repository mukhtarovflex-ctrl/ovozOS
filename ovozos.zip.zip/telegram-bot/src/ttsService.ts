import { GoogleGenAI } from "@google/genai";
import { BotConfig } from "./config";
import { VoiceLang } from "./types";

export interface TtsSynthesisResult {
  audioBuffer: Buffer;
  mimeType: string;
  filename: string;
}

export interface TtsService {
  synthesize(text: string, lang: VoiceLang): Promise<TtsSynthesisResult | null>;
}

/**
 * Strips HTML tags and markdown symbols so spoken voice replies sound natural and concise.
 */
export function cleanTextForSpeech(htmlText: string): string {
  return (htmlText || "")
    .replace(/<[^>]+>/g, " ")
    .replace(/[✓○☐✅❌•·—]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 600);
}

/**
 * Wraps raw 16-bit signed linear PCM (24kHz mono from Gemini TTS) in a standard RIFF WAV container.
 */
function pcm16ToWav(pcm: Buffer, sampleRate = 24000, channels = 1): Buffer {
  const byteRate = sampleRate * channels * 2;
  const blockAlign = channels * 2;
  const header = Buffer.alloc(44);
  header.write("RIFF", 0);
  header.writeUInt32LE(36 + pcm.length, 4);
  header.write("WAVE", 8);
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16); // PCM chunk size
  header.writeUInt16LE(1, 20); // PCM format
  header.writeUInt16LE(channels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(16, 34); // bits per sample
  header.write("data", 36);
  header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]);
}

export class OvozTtsService implements TtsService {
  private readonly ai: GoogleGenAI | null;

  constructor(private readonly config: BotConfig) {
    this.ai = config.geminiApiKey ? new GoogleGenAI({ apiKey: config.geminiApiKey }) : null;
  }

  async synthesize(htmlText: string, lang: VoiceLang): Promise<TtsSynthesisResult | null> {
    const spokenText = cleanTextForSpeech(htmlText);
    if (!spokenText) return null;

    if (this.config.ttsProvider === "google_cloud" && this.config.googleCloudTtsApiKey) {
      const cloudRes = await this.synthesizeGoogleCloudTts(spokenText, lang);
      if (cloudRes) return cloudRes;
    }

    return this.synthesizeGeminiTts(spokenText, lang);
  }

  private async synthesizeGoogleCloudTts(
    text: string,
    lang: VoiceLang
  ): Promise<TtsSynthesisResult | null> {
    try {
      const languageCode = lang === "ru" ? "ru-RU" : lang === "en" ? "en-US" : "tr-TR";
      const res = await fetch(
        `https://texttospeech.googleapis.com/v1/text:synthesize?key=${encodeURIComponent(
          this.config.googleCloudTtsApiKey
        )}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            input: { text },
            voice: { languageCode, ssmlGender: "NEUTRAL" },
            audioConfig: { audioEncoding: "OGG_OPUS", speakingRate: 1.03 },
          }),
        }
      );
      if (!res.ok) return null;
      const data = (await res.json()) as { audioContent?: string };
      if (!data.audioContent) return null;
      return {
        audioBuffer: Buffer.from(data.audioContent, "base64"),
        mimeType: "audio/ogg",
        filename: "ovozos_reply.ogg",
      };
    } catch (err) {
      console.warn("[TTS] Google Cloud TTS failed:", (err as Error).message);
      return null;
    }
  }

  private async synthesizeGeminiTts(
    text: string,
    lang: VoiceLang
  ): Promise<TtsSynthesisResult | null> {
    if (!this.ai) return null;
    try {
      const langPrompt =
        lang === "ru"
          ? "Read the following Russian response clearly, naturally, and concisely:"
          : lang === "en"
            ? "Read the following English response clearly, naturally, and concisely:"
            : "Read the following Uzbek (Latin) response clearly with natural Uzbek pronunciation, calm and concise:";

      const response = await this.ai.models.generateContent({
        model: this.config.geminiTtsModel,
        contents: [{ role: "user", parts: [{ text: `${langPrompt}\n\n${text}` }] }],
        config: {
          responseModalities: ["AUDIO"],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: "Aoede" },
            },
          },
        } as never,
      });

      const candidates = (response as { candidates?: Array<{ content?: { parts?: Array<{ inlineData?: { data?: string; mimeType?: string } }> } }> }).candidates;
      const part = candidates?.[0]?.content?.parts?.find((p) => p.inlineData?.data);
      const inline = part?.inlineData;
      if (!inline?.data) return null;

      const rawBuf = Buffer.from(inline.data, "base64");
      const mime = (inline.mimeType || "audio/L16;rate=24000").toLowerCase();
      if (mime.includes("ogg")) {
        return { audioBuffer: rawBuf, mimeType: "audio/ogg", filename: "ovozos_reply.ogg" };
      }
      if (mime.includes("wav")) {
        return { audioBuffer: rawBuf, mimeType: "audio/wav", filename: "ovozos_reply.wav" };
      }
      // Convert raw PCM to WAV for immediate playback in Telegram
      return {
        audioBuffer: pcm16ToWav(rawBuf, 24000, 1),
        mimeType: "audio/wav",
        filename: "ovozos_reply.wav",
      };
    } catch (err) {
      console.warn("[TTS] Gemini TTS failed, falling back to text:", (err as Error).message);
      return null;
    }
  }
}

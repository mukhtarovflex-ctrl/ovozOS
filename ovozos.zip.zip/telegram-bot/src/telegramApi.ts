export interface InlineButton {
  text: string;
  callback_data?: string;
  url?: string;
}

export interface ReplyMarkup {
  inline_keyboard?: InlineButton[][];
  keyboard?: Array<Array<{ text: string }>>;
  resize_keyboard?: boolean;
  is_persistent?: boolean;
  remove_keyboard?: boolean;
}

export interface SentMessageResult {
  message_id: number;
  chat: { id: number };
}

export interface TelegramClient {
  sendMessage(
    chatId: string | number,
    text: string,
    options?: {
      parse_mode?: "HTML";
      reply_markup?: ReplyMarkup;
      disable_notification?: boolean;
    }
  ): Promise<SentMessageResult | null>;
  editMessageText(
    chatId: string | number,
    messageId: number,
    text: string,
    options?: {
      parse_mode?: "HTML";
      reply_markup?: ReplyMarkup;
    }
  ): Promise<boolean>;
  answerCallbackQuery(callbackQueryId: string, text?: string, showAlert?: boolean): Promise<void>;
  sendVoice(
    chatId: string | number,
    audioBuffer: Buffer,
    options?: {
      caption?: string;
      filename?: string;
      mimeType?: string;
      reply_markup?: ReplyMarkup;
    }
  ): Promise<SentMessageResult | null>;
  sendChatAction(chatId: string | number, action: "typing" | "record_voice"): Promise<void>;
  downloadFileBuffer(fileId: string): Promise<{ buffer: Buffer; mimeType: string } | null>;
  getMe(): Promise<{ id: number; username: string; first_name: string } | null>;
  setWebhook(webhookUrl: string, secretToken: string): Promise<boolean>;
  setMyCommands(commands: Array<{ command: string; description: string }>): Promise<boolean>;
}

/**
 * Permanent minimal 5-button main menu per Requirement 16:
 * Vazifalar, Xarajatlar, Oldi-berdi, Hisobotlar, Sozlamalar.
 */
export const MAIN_REPLY_KEYBOARD: ReplyMarkup = {
  keyboard: [
    [{ text: "Vazifalar" }, { text: "Xarajatlar" }],
    [{ text: "Oldi-berdi" }, { text: "Hisobotlar" }],
    [{ text: "Sozlamalar" }],
  ],
  resize_keyboard: true,
  is_persistent: true,
};

export class TelegramApiClient implements TelegramClient {
  private readonly baseUrl: string;
  private readonly fileBaseUrl: string;

  constructor(private readonly botToken: string) {
    this.baseUrl = `https://api.telegram.org/bot${botToken}`;
    this.fileBaseUrl = `https://api.telegram.org/file/bot${botToken}`;
  }

  private async postJson<T>(method: string, body: Record<string, unknown>): Promise<T | null> {
    if (!this.botToken) return null;
    try {
      const res = await fetch(`${this.baseUrl}/${method}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const json = (await res.json()) as { ok?: boolean; result?: T; description?: string };
      if (!json.ok) {
        // Avoid logging sensitive message payloads; log only method & Telegram error code/description
        console.warn(`[TelegramAPI] ${method} failed: ${json.description || res.status}`);
        return null;
      }
      return json.result ?? null;
    } catch (err) {
      console.error(`[TelegramAPI] ${method} network error:`, (err as Error).message);
      return null;
    }
  }

  async sendMessage(
    chatId: string | number,
    text: string,
    options?: {
      parse_mode?: "HTML";
      reply_markup?: ReplyMarkup;
      disable_notification?: boolean;
    }
  ): Promise<SentMessageResult | null> {
    return this.postJson<SentMessageResult>("sendMessage", {
      chat_id: chatId,
      text: text.slice(0, 4096),
      parse_mode: options?.parse_mode ?? "HTML",
      reply_markup: options?.reply_markup,
      disable_notification: options?.disable_notification,
    });
  }

  async editMessageText(
    chatId: string | number,
    messageId: number,
    text: string,
    options?: {
      parse_mode?: "HTML";
      reply_markup?: ReplyMarkup;
    }
  ): Promise<boolean> {
    const res = await this.postJson<unknown>("editMessageText", {
      chat_id: chatId,
      message_id: messageId,
      text: text.slice(0, 4096),
      parse_mode: options?.parse_mode ?? "HTML",
      reply_markup: options?.reply_markup,
    });
    return res !== null;
  }

  async answerCallbackQuery(
    callbackQueryId: string,
    text?: string,
    showAlert = false
  ): Promise<void> {
    await this.postJson("answerCallbackQuery", {
      callback_query_id: callbackQueryId,
      text: text?.slice(0, 190),
      show_alert: showAlert,
    });
  }

  async sendVoice(
    chatId: string | number,
    audioBuffer: Buffer,
    options?: {
      caption?: string;
      filename?: string;
      mimeType?: string;
      reply_markup?: ReplyMarkup;
    }
  ): Promise<SentMessageResult | null> {
    if (!this.botToken) return null;
    try {
      const form = new FormData();
      form.append("chat_id", String(chatId));
      const mime = options?.mimeType || "audio/ogg";
      const isOgg = mime.includes("ogg");
      const filename = options?.filename || (isOgg ? "reply.ogg" : "reply.wav");
      const blob = new Blob([new Uint8Array(audioBuffer)], { type: mime });
      const endpoint = isOgg ? "sendVoice" : "sendAudio";
      form.append(isOgg ? "voice" : "audio", blob, filename);
      if (options?.caption) {
        form.append("caption", options.caption.slice(0, 1024));
        form.append("parse_mode", "HTML");
      }
      if (options?.reply_markup) {
        form.append("reply_markup", JSON.stringify(options.reply_markup));
      }
      const res = await fetch(`${this.baseUrl}/${endpoint}`, {
        method: "POST",
        body: form,
      });
      const json = (await res.json()) as {
        ok?: boolean;
        result?: SentMessageResult;
        description?: string;
      };
      if (!json.ok) {
        console.warn(`[TelegramAPI] ${endpoint} failed: ${json.description || res.status}`);
        return null;
      }
      return json.result ?? null;
    } catch (err) {
      console.error("[TelegramAPI] sendVoice error:", (err as Error).message);
      return null;
    }
  }

  async sendChatAction(chatId: string | number, action: "typing" | "record_voice"): Promise<void> {
    await this.postJson("sendChatAction", { chat_id: chatId, action });
  }

  async downloadFileBuffer(fileId: string): Promise<{ buffer: Buffer; mimeType: string } | null> {
    if (!this.botToken) return null;
    const fileInfo = await this.postJson<{ file_path?: string; file_size?: number }>("getFile", {
      file_id: fileId,
    });
    if (!fileInfo?.file_path) return null;
    // Cap audio download to 12 MB to prevent memory abuse
    if (fileInfo.file_size && fileInfo.file_size > 12 * 1024 * 1024) {
      return null;
    }
    try {
      const res = await fetch(`${this.fileBaseUrl}/${fileInfo.file_path}`);
      if (!res.ok) return null;
      const arr = await res.arrayBuffer();
      const buffer = Buffer.from(arr);
      const lower = fileInfo.file_path.toLowerCase();
      const mimeType = lower.endsWith(".mp3")
        ? "audio/mpeg"
        : lower.endsWith(".m4a")
          ? "audio/mp4"
          : lower.endsWith(".wav")
            ? "audio/wav"
            : "audio/ogg";
      return { buffer, mimeType };
    } catch (err) {
      console.error("[TelegramAPI] downloadFileBuffer error:", (err as Error).message);
      return null;
    }
  }

  async getMe(): Promise<{ id: number; username: string; first_name: string } | null> {
    return this.postJson<{ id: number; username: string; first_name: string }>("getMe", {});
  }

  async setWebhook(webhookUrl: string, secretToken: string): Promise<boolean> {
    const res = await this.postJson<unknown>("setWebhook", {
      url: webhookUrl,
      secret_token: secretToken,
      allowed_updates: ["message", "callback_query"],
      drop_pending_updates: false,
    });
    return res !== null;
  }

  async setMyCommands(
    commands: Array<{ command: string; description: string }>
  ): Promise<boolean> {
    const res = await this.postJson<unknown>("setMyCommands", { commands });
    return res !== null;
  }
}

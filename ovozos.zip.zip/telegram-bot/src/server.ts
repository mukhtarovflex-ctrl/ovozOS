import { loadConfig } from "./config";
import { initFirebase, publishTelegramPublicConfig } from "./firebase";
import { FirestoreOvozRepository } from "./repository";
import { TelegramApiClient } from "./telegramApi";
import { GeminiServerService } from "./geminiService";
import { OvozTtsService } from "./ttsService";
import { OvozBotHandler } from "./botHandler";
import { createHttpApp } from "./httpApp";
import { runSchedulerTick } from "./scheduler";

async function main() {
  const config = loadConfig();
  const { db, auth } = initFirebase(config);
  const store = new FirestoreOvozRepository(db);
  const telegram = new TelegramApiClient(config.telegramBotToken);
  const gemini = new GeminiServerService(config);
  const tts = new OvozTtsService(config);
  const handler = new OvozBotHandler(config, store, telegram, gemini, tts);
  const app = createHttpApp({ config, store, telegram, gemini, handler, auth });

  // Publish non-secret public bot metadata to Firestore so Android discovers the bot automatically
  if (config.publicBaseUrl || config.telegramBotUsername) {
    let botUsername = config.telegramBotUsername;
    if (!botUsername && config.telegramBotToken) {
      const me = await telegram.getMe();
      botUsername = me?.username || "";
    }
    if (botUsername || config.publicBaseUrl) {
      await publishTelegramPublicConfig(db, botUsername, config.publicBaseUrl).catch((err) => {
        console.warn("[Boot] Failed publishing app_config/telegram:", (err as Error).message);
      });
    }
  }

  // Optional in-process 1-minute scheduler loop for standalone hosts (Railway / Render / VPS)
  if (config.enableInternalCron && config.telegramBotToken) {
    let running = false;
    setInterval(async () => {
      if (running) return;
      running = true;
      try {
        await runSchedulerTick(store, telegram, gemini);
      } catch (err) {
        console.error("[Cron] Tick failed:", (err as Error).message);
      } finally {
        running = false;
      }
    }, 60_000);
  }

  app.listen(config.port, () => {
    console.log(
      `[OvozOS Telegram Bot] Server listening on port ${config.port} (db=${config.firestoreDatabaseId})`
    );
  });
}

main().catch((err) => {
  console.error("[OvozOS Telegram Bot] Fatal startup error:", err);
  process.exit(1);
});

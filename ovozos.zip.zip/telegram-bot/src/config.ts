import dotenv from "dotenv";

dotenv.config();

export interface BotConfig {
  telegramBotToken: string;
  telegramBotUsername: string;
  telegramWebhookSecret: string;
  geminiApiKey: string;
  geminiModel: string;
  geminiFastModel: string;
  geminiTtsModel: string;
  firebaseProjectId: string;
  firestoreDatabaseId: string;
  firebaseServiceAccountJson: string;
  publicBaseUrl: string;
  cronSecret: string;
  ttsProvider: "gemini" | "google_cloud";
  googleCloudTtsApiKey: string;
  port: number;
  enableInternalCron: boolean;
  rateLimitMaxPerMinute: number;
}

export function loadConfig(env: NodeJS.ProcessEnv = process.env): BotConfig {
  return {
    telegramBotToken: (env.TELEGRAM_BOT_TOKEN || "").trim(),
    telegramBotUsername: (env.TELEGRAM_BOT_USERNAME || "").trim().replace(/^@/, ""),
    telegramWebhookSecret: (env.TELEGRAM_WEBHOOK_SECRET || "").trim(),
    geminiApiKey: (env.GEMINI_API_KEY || "").trim(),
    geminiModel: (env.GEMINI_MODEL || "gemini-3.8-flash").trim(),
    geminiFastModel: (env.GEMINI_FAST_MODEL || "gemini-3.5-flash-lite").trim(),
    geminiTtsModel: (env.GEMINI_TTS_MODEL || "gemini-3.1-flash-tts-preview").trim(),
    firebaseProjectId: (env.FIREBASE_PROJECT_ID || "gen-lang-client-0806637635").trim(),
    firestoreDatabaseId: (
      env.FIRESTORE_DATABASE_ID ||
      "ai-studio-android-ovozos-50127b10-2eff-4ef9-ad1c-13f773f75d53"
    ).trim(),
    firebaseServiceAccountJson: (env.FIREBASE_SERVICE_ACCOUNT_JSON || "").trim(),
    publicBaseUrl: (env.PUBLIC_BASE_URL || "").trim().replace(/\/+$/, ""),
    cronSecret: (env.CRON_SECRET || "").trim(),
    ttsProvider: env.TTS_PROVIDER === "google_cloud" ? "google_cloud" : "gemini",
    googleCloudTtsApiKey: (env.GOOGLE_CLOUD_TTS_API_KEY || "").trim(),
    port: Math.max(1, parseInt(env.PORT || "8080", 10) || 8080),
    enableInternalCron: env.ENABLE_INTERNAL_CRON !== "false",
    rateLimitMaxPerMinute: Math.max(5, parseInt(env.RATE_LIMIT_MAX_PER_MINUTE || "25", 10) || 25),
  };
}

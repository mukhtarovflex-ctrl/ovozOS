import * as admin from "firebase-admin";
import { getFirestore, Firestore, FieldValue } from "firebase-admin/firestore";
import { BotConfig } from "./config";

let initializedApp: admin.app.App | null = null;
let firestoreInstance: Firestore | null = null;

export function initFirebase(config: BotConfig): {
  app: admin.app.App;
  db: Firestore;
  auth: admin.auth.Auth;
} {
  if (!initializedApp) {
    if (admin.apps.length > 0 && admin.apps[0]) {
      initializedApp = admin.apps[0];
    } else if (config.firebaseServiceAccountJson) {
      const parsed = JSON.parse(config.firebaseServiceAccountJson);
      initializedApp = admin.initializeApp({
        credential: admin.credential.cert(parsed),
        projectId: config.firebaseProjectId,
      });
    } else {
      // Uses Application Default Credentials (Cloud Functions / Cloud Run / GOOGLE_APPLICATION_CREDENTIALS)
      initializedApp = admin.initializeApp({
        projectId: config.firebaseProjectId,
      });
    }
  }

  if (!firestoreInstance) {
    // CRITICAL: Connect to the exact named Firestore database used by the OvozOS Android app!
    firestoreInstance = getFirestore(initializedApp, config.firestoreDatabaseId);
  }

  return {
    app: initializedApp,
    db: firestoreInstance,
    auth: admin.auth(initializedApp),
  };
}

/**
 * Publishes non-secret public bot metadata (`botUsername`, `serverUrl`) to `app_config/telegram`
 * so the Android app discovers the bot automatically without manual configuration.
 */
export async function publishTelegramPublicConfig(
  db: Firestore,
  botUsername: string,
  serverUrl: string
): Promise<void> {
  const cleanUser = botUsername.trim().replace(/^@/, "");
  const cleanUrl = serverUrl.trim().replace(/\/+$/, "");
  if (!cleanUser && !cleanUrl) return;

  await db
    .collection("app_config")
    .doc("telegram")
    .set(
      {
        botUsername: cleanUser,
        serverUrl: cleanUrl,
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
}

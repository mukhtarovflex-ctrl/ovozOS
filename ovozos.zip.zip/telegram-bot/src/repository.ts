import crypto from "crypto";
import { Firestore, FieldValue, Timestamp } from "firebase-admin/firestore";
import {
  ActionLogItem,
  BotSession,
  CurrencyCode,
  DEFAULT_TELEGRAM_USER_STATE,
  DebtItem,
  FinanceTransaction,
  PersonItem,
  ReminderKind,
  ScheduledReminder,
  TaskItem,
  TelegramLinkRecord,
  TelegramUserState,
  UserProfile,
} from "./types";
import { generateOneTimeLinkCode, hashLinkCode } from "./security";
import { isSameDayInZone, normalizeTimezone } from "./time";

export interface LinkCodeDoc {
  uid: string;
  timezone: string;
  createdAtMillis: number;
  expiresAtMillis: number;
  used: boolean;
}

export interface UndoResult {
  undoneCount: number;
  skippedConflictCount: number;
  summaries: string[];
}

export interface OvozStore {
  // Idempotency & sessions
  claimUpdateIdempotency(dedupKey: string): Promise<boolean>;
  getSession(telegramUserId: string): Promise<BotSession>;
  saveSession(session: BotSession): Promise<void>;

  // Account linking
  createLinkCode(uid: string, timezone: string): Promise<{ rawCode: string; expiresAtMillis: number }>;
  peekLinkCode(rawCode: string): Promise<{ codeHash: string; doc: LinkCodeDoc } | null>;
  consumeLinkCodeAndBind(
    codeHash: string,
    telegramUser: {
      telegramUserId: string;
      telegramChatId: string;
      telegramUsername: string;
      telegramFirstName: string;
    }
  ): Promise<{ uid: string; timezone: string } | null>;
  getLinkByTelegramUserId(telegramUserId: string): Promise<TelegramLinkRecord | null>;
  getTelegramUserState(uid: string): Promise<TelegramUserState | null>;
  updateTelegramUserState(uid: string, patch: Partial<TelegramUserState>): Promise<void>;
  unlinkAccount(uid: string, telegramUserId?: string): Promise<void>;
  listActiveLinks(): Promise<TelegramLinkRecord[]>;

  // User profile (shared with Android)
  getUserProfile(uid: string): Promise<UserProfile>;
  updateUserProfile(uid: string, patch: Record<string, unknown>): Promise<void>;

  // Tasks, Expenses, Debts, People, Action Logs (shared with Android)
  listTasks(uid: string): Promise<TaskItem[]>;
  getTask(uid: string, taskId: string): Promise<TaskItem | null>;
  addTask(uid: string, task: Omit<TaskItem, "id">, batchId: string, sourceVoice: boolean): Promise<TaskItem>;
  updateTask(
    uid: string,
    before: TaskItem,
    after: TaskItem,
    summary: string,
    batchId: string,
    sourceVoice: boolean
  ): Promise<void>;
  completeTaskWithRecurrence(
    uid: string,
    task: TaskItem,
    timeZone: string,
    batchId: string,
    sourceVoice: boolean
  ): Promise<{ nextTask: TaskItem | null }>;

  listTransactions(uid: string): Promise<FinanceTransaction[]>;
  addExpense(
    uid: string,
    tx: Omit<FinanceTransaction, "id" | "kind">,
    batchId: string,
    sourceVoice: boolean
  ): Promise<FinanceTransaction>;

  listDebts(uid: string): Promise<DebtItem[]>;
  addDebt(uid: string, debt: Omit<DebtItem, "id">, batchId: string, sourceVoice: boolean): Promise<DebtItem>;
  recordDebtPayment(
    uid: string,
    debt: DebtItem,
    paymentAmount: number,
    batchId: string,
    sourceVoice: boolean
  ): Promise<DebtItem>;

  listPeople(uid: string): Promise<PersonItem[]>;
  ensurePerson(uid: string, name: string, batchId: string, sourceVoice: boolean): Promise<PersonItem>;

  listActionLogs(uid: string, limit?: number): Promise<ActionLogItem[]>;
  undoActionLogSafe(uid: string, log: ActionLogItem): Promise<{ status: "undone" | "conflict" | "already_reverted" }>;
  undoBatchSafe(uid: string, batchId: string): Promise<UndoResult>;

  // Persistent scheduled reminders
  upsertReminder(reminder: Omit<ScheduledReminder, "id">, customId?: string): Promise<ScheduledReminder>;
  listPendingRemindersDue(uid: string, nowMillis: number): Promise<ScheduledReminder[]>;
  listTaskReminders(uid: string, taskId: string): Promise<ScheduledReminder[]>;
  markReminderSent(reminderId: string, sentAtMillis: number): Promise<void>;
  cancelTaskReminders(uid: string, taskId: string, kinds?: ReminderKind[]): Promise<void>;
  cancelAllUserReminders(uid: string): Promise<void>;
}

function tsToMillis(val: unknown): number {
  if (!val) return 0;
  if (typeof val === "number") return val;
  if (val instanceof Timestamp) return val.toMillis();
  if (typeof (val as { toMillis?: () => number }).toMillis === "function") {
    return (val as { toMillis: () => number }).toMillis();
  }
  return 0;
}

function genBatchId(prefix = "tg"): string {
  return `${prefix}_${crypto.randomBytes(4).toString("hex")}`;
}

export class FirestoreOvozRepository implements OvozStore {
  constructor(private readonly db: Firestore) {}

  private userDoc(uid: string) {
    return this.db.collection("users").doc(uid);
  }

  async claimUpdateIdempotency(dedupKey: string): Promise<boolean> {
    const ref = this.db.collection("telegram_processed_updates").doc(dedupKey);
    try {
      await ref.create({
        createdAtMillis: Date.now(),
        createdAt: FieldValue.serverTimestamp(),
      });
      return true;
    } catch {
      return false;
    }
  }

  async getSession(telegramUserId: string): Promise<BotSession> {
    const snap = await this.db.collection("telegram_sessions").doc(telegramUserId).get();
    if (!snap.exists) {
      return { telegramUserId, updatedAtMillis: Date.now() };
    }
    const data = snap.data() || {};
    return {
      telegramUserId,
      pendingLinkCodeHash: data.pendingLinkCodeHash,
      pendingLinkUid: data.pendingLinkUid,
      pendingLinkTimezone: data.pendingLinkTimezone,
      pendingDraft: data.pendingDraft ?? null,
      clarificationContext: data.clarificationContext ?? null,
      pendingEdit: data.pendingEdit ?? null,
      pendingTaskEdit: data.pendingTaskEdit ?? null,
      pendingMoveTomorrow: data.pendingMoveTomorrow ?? null,
      rateLimitCount: data.rateLimitCount ?? 0,
      rateLimitWindowStart: data.rateLimitWindowStart ?? 0,
      updatedAtMillis: data.updatedAtMillis ?? Date.now(),
    };
  }

  async saveSession(session: BotSession): Promise<void> {
    const clean: Record<string, unknown> = {
      telegramUserId: session.telegramUserId,
      pendingLinkCodeHash: session.pendingLinkCodeHash ?? null,
      pendingLinkUid: session.pendingLinkUid ?? null,
      pendingLinkTimezone: session.pendingLinkTimezone ?? null,
      pendingDraft: session.pendingDraft ?? null,
      clarificationContext: session.clarificationContext ?? null,
      pendingEdit: session.pendingEdit ?? null,
      pendingTaskEdit: session.pendingTaskEdit ?? null,
      pendingMoveTomorrow: session.pendingMoveTomorrow ?? null,
      rateLimitCount: session.rateLimitCount ?? 0,
      rateLimitWindowStart: session.rateLimitWindowStart ?? 0,
      updatedAtMillis: Date.now(),
    };
    await this.db.collection("telegram_sessions").doc(session.telegramUserId).set(clean, { merge: true });
  }

  async createLinkCode(uid: string, timezone: string): Promise<{ rawCode: string; expiresAtMillis: number }> {
    const { rawCode, codeHash } = generateOneTimeLinkCode();
    const now = Date.now();
    const expiresAtMillis = now + 10 * 60 * 1000; // 10 minutes TTL
    const doc: LinkCodeDoc = {
      uid,
      timezone: normalizeTimezone(timezone),
      createdAtMillis: now,
      expiresAtMillis,
      used: false,
    };
    await this.db.collection("telegram_link_codes").doc(codeHash).set(doc);
    return { rawCode, expiresAtMillis };
  }

  async peekLinkCode(rawCode: string): Promise<{ codeHash: string; doc: LinkCodeDoc } | null> {
    const codeHash = hashLinkCode(rawCode);
    const snap = await this.db.collection("telegram_link_codes").doc(codeHash).get();
    if (!snap.exists) return null;
    const doc = snap.data() as LinkCodeDoc;
    if (doc.used || doc.expiresAtMillis < Date.now()) return null;
    return { codeHash, doc };
  }

  async consumeLinkCodeAndBind(
    codeHash: string,
    tg: {
      telegramUserId: string;
      telegramChatId: string;
      telegramUsername: string;
      telegramFirstName: string;
    }
  ): Promise<{ uid: string; timezone: string } | null> {
    const codeRef = this.db.collection("telegram_link_codes").doc(codeHash);
    const linkRef = this.db.collection("telegram_links").doc(tg.telegramUserId);

    return this.db.runTransaction(async (tx) => {
      const codeSnap = await tx.get(codeRef);
      if (!codeSnap.exists) return null;
      const doc = codeSnap.data() as LinkCodeDoc;
      if (doc.used || doc.expiresAtMillis < Date.now()) return null;

      const now = Date.now();
      const tz = normalizeTimezone(doc.timezone);
      const userStateRef = this.userDoc(doc.uid).collection("telegram_state").doc("link");
      const existingStateSnap = await tx.get(userStateRef);
      const prevState = existingStateSnap.exists ? (existingStateSnap.data() as Partial<TelegramUserState>) : {};

      // If this Firebase user was linked to another Telegram account before, deactivate old link
      if (prevState.telegramUserId && prevState.telegramUserId !== tg.telegramUserId) {
        tx.delete(this.db.collection("telegram_links").doc(prevState.telegramUserId));
      }

      tx.update(codeRef, { used: true, usedAtMillis: now });
      tx.set(linkRef, {
        telegramUserId: tg.telegramUserId,
        uid: doc.uid,
        telegramChatId: tg.telegramChatId,
        telegramUsername: tg.telegramUsername,
        telegramFirstName: tg.telegramFirstName,
        linkedAtMillis: now,
        active: true,
      });

      const mergedState: Record<string, unknown> = {
        ...DEFAULT_TELEGRAM_USER_STATE,
        ...prevState,
        linked: true,
        telegramUserId: tg.telegramUserId,
        telegramChatId: tg.telegramChatId,
        telegramUsername: tg.telegramUsername,
        telegramFirstName: tg.telegramFirstName,
        linkedAtMillis: now,
        timezone: tz,
        updatedAt: FieldValue.serverTimestamp(),
      };
      tx.set(userStateRef, mergedState, { merge: true });
      return { uid: doc.uid, timezone: tz };
    });
  }

  async getLinkByTelegramUserId(telegramUserId: string): Promise<TelegramLinkRecord | null> {
    const snap = await this.db.collection("telegram_links").doc(telegramUserId).get();
    if (!snap.exists) return null;
    const rec = snap.data() as TelegramLinkRecord;
    if (!rec.active || !rec.uid) return null;
    // Double-check per-user state so client-side instant revoke in Android stops bot immediately!
    const state = await this.getTelegramUserState(rec.uid);
    if (!state || !state.linked || state.telegramUserId !== telegramUserId) {
      return null;
    }
    return rec;
  }

  async getTelegramUserState(uid: string): Promise<TelegramUserState | null> {
    const snap = await this.userDoc(uid).collection("telegram_state").doc("link").get();
    if (!snap.exists) return null;
    const d = snap.data() || {};
    return {
      linked: Boolean(d.linked),
      telegramUserId: String(d.telegramUserId || ""),
      telegramChatId: String(d.telegramChatId || ""),
      telegramUsername: String(d.telegramUsername || ""),
      telegramFirstName: String(d.telegramFirstName || ""),
      linkedAtMillis: Number(d.linkedAtMillis || 0),
      timezone: normalizeTimezone(d.timezone),
      remindersEnabled: d.remindersEnabled !== false,
      hourlyIntervalMinutes: Number(d.hourlyIntervalMinutes || 60),
      activeStartHour: Number(d.activeStartHour ?? 8),
      activeEndHour: Number(d.activeEndHour ?? 22),
      smartRemindersEnabled: d.smartRemindersEnabled !== false,
      weeklyReportEnabled: d.weeklyReportEnabled !== false,
      weeklyReportDay: Number(d.weeklyReportDay ?? 0),
      weeklyReportHour: Number(d.weeklyReportHour ?? 20),
      replyMode: d.replyMode === "voice" || d.replyMode === "both" ? d.replyMode : "text",
      voiceLanguage: d.voiceLanguage === "ru" || d.voiceLanguage === "en" ? d.voiceLanguage : "uz",
      lastHourlySentAtMillis: Number(d.lastHourlySentAtMillis || 0),
      lastDailyReviewDateKey: String(d.lastDailyReviewDateKey || ""),
      lastWeeklyReviewWeekKey: String(d.lastWeeklyReviewWeekKey || ""),
    };
  }

  async updateTelegramUserState(uid: string, patch: Partial<TelegramUserState>): Promise<void> {
    await this.userDoc(uid)
      .collection("telegram_state")
      .doc("link")
      .set(
        {
          ...patch,
          updatedAt: FieldValue.serverTimestamp(),
        },
        { merge: true }
      );
  }

  async unlinkAccount(uid: string, telegramUserId?: string): Promise<void> {
    const state = await this.getTelegramUserState(uid);
    const tgId = telegramUserId || state?.telegramUserId || "";
    if (tgId) {
      await this.db.collection("telegram_links").doc(tgId).delete().catch(() => undefined);
      await this.db.collection("telegram_sessions").doc(tgId).delete().catch(() => undefined);
    }
    await this.userDoc(uid)
      .collection("telegram_state")
      .doc("link")
      .set(
        {
          linked: false,
          updatedAt: FieldValue.serverTimestamp(),
        },
        { merge: true }
      );
    await this.cancelAllUserReminders(uid);
  }

  async listActiveLinks(): Promise<TelegramLinkRecord[]> {
    const snaps = await this.db.collection("telegram_links").where("active", "==", true).get();
    return snaps.docs.map((d) => d.data() as TelegramLinkRecord);
  }

  async getUserProfile(uid: string): Promise<UserProfile> {
    const snap = await this.userDoc(uid).get();
    const d = snap.data() || {};
    return {
      id: snap.id,
      userId: String(d.userId || uid),
      displayName: String(d.displayName || "Foydalanuvchi"),
      onboardingDone: Boolean(d.onboardingDone),
      language: d.language === "ru" || d.language === "en" ? d.language : "uz",
      aiResponseLang:
        d.aiResponseLang === "uz" || d.aiResponseLang === "ru" || d.aiResponseLang === "en"
          ? d.aiResponseLang
          : "auto",
      primaryCurrency: (["UZS", "USD", "EUR", "RUB"].includes(d.primaryCurrency)
        ? d.primaryCurrency
        : "UZS") as CurrencyCode,
      notifyAll: d.notifyAll !== false,
      notifyTasks: d.notifyTasks !== false,
      notifyDebts: d.notifyDebts !== false,
      notifyEvening: d.notifyEvening !== false,
      eveningReviewHour: Number(d.eveningReviewHour ?? 21),
      eveningReviewMinute: Number(d.eveningReviewMinute ?? 0),
      notifyReports: d.notifyReports !== false,
      autoSaveVoice: Boolean(d.autoSaveVoice),
    };
  }

  async updateUserProfile(uid: string, patch: Record<string, unknown>): Promise<void> {
    await this.userDoc(uid).set(
      {
        ...patch,
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
  }

  private async recordActionLog(
    uid: string,
    payload: Omit<ActionLogItem, "id" | "createdAtMillis">
  ): Promise<void> {
    await this.userDoc(uid)
      .collection("action_logs")
      .doc()
      .set({
        batchId: payload.batchId.slice(0, 80),
        actionType: payload.actionType,
        entityCollection: payload.entityCollection,
        entityId: payload.entityId.slice(0, 128),
        summaryText: payload.summaryText.slice(0, 300),
        beforeSummary: payload.beforeSummary.slice(0, 300),
        afterSummary: payload.afterSummary.slice(0, 300),
        beforeData: payload.beforeData,
        afterData: payload.afterData,
        sourceVoice: payload.sourceVoice,
        reverted: false,
        createdAt: FieldValue.serverTimestamp(),
      });
  }

  private mapTask(id: string, d: Record<string, unknown>): TaskItem {
    return {
      id,
      title: String(d.title || ""),
      description: String(d.description || ""),
      dueDateMillis: Number(d.dueDateMillis || 0),
      hasDueTime: Boolean(d.hasDueTime),
      priority: d.priority === "high" || d.priority === "low" ? d.priority : "medium",
      category: String(d.category || "Shaxsiy"),
      recurrence:
        d.recurrence === "daily" || d.recurrence === "weekly" || d.recurrence === "monthly"
          ? d.recurrence
          : "none",
      completed: Boolean(d.completed),
      completedAtMillis: Number(d.completedAtMillis || 0),
      personId: String(d.personId || ""),
      personName: String(d.personName || ""),
      goalId: String(d.goalId || ""),
      noteText: String(d.noteText || ""),
      reminderEnabled: Boolean(d.reminderEnabled),
      updatedAtMillis: tsToMillis(d.updatedAt),
    };
  }

  private taskSnapshot(t: Omit<TaskItem, "id">): Record<string, unknown> {
    return {
      title: t.title.trim().slice(0, 200) || "Vazifa",
      description: (t.description || "").slice(0, 1000),
      dueDateMillis: Math.max(0, Math.round(t.dueDateMillis || 0)),
      hasDueTime: Boolean(t.hasDueTime),
      priority: t.priority,
      category: (t.category || "Shaxsiy").trim().slice(0, 40) || "Shaxsiy",
      recurrence: t.recurrence,
      completed: Boolean(t.completed),
      completedAtMillis: Math.max(0, Math.round(t.completedAtMillis || 0)),
      personId: (t.personId || "").slice(0, 128),
      personName: (t.personName || "").slice(0, 80),
      goalId: (t.goalId || "").slice(0, 128),
      noteText: (t.noteText || "").slice(0, 1000),
      reminderEnabled: Boolean(t.reminderEnabled),
    };
  }

  async listTasks(uid: string): Promise<TaskItem[]> {
    const snaps = await this.userDoc(uid).collection("tasks").get();
    return snaps.docs.map((d) => this.mapTask(d.id, d.data()));
  }

  async getTask(uid: string, taskId: string): Promise<TaskItem | null> {
    const snap = await this.userDoc(uid).collection("tasks").doc(taskId).get();
    if (!snap.exists) return null;
    return this.mapTask(snap.id, snap.data() || {});
  }

  async addTask(
    uid: string,
    task: Omit<TaskItem, "id">,
    batchId: string = genBatchId("tg"),
    sourceVoice = false
  ): Promise<TaskItem> {
    const docRef = this.userDoc(uid).collection("tasks").doc();
    const snap = this.taskSnapshot(task);
    await docRef.set({
      ...snap,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    });
    const created: TaskItem = { ...(snap as Omit<TaskItem, "id">), id: docRef.id };
    await this.recordActionLog(uid, {
      batchId,
      actionType: "create",
      entityCollection: "tasks",
      entityId: docRef.id,
      summaryText: `Vazifa qo‘shildi: ${created.title}`,
      beforeSummary: "",
      afterSummary: created.title,
      beforeData: {},
      afterData: snap,
      sourceVoice,
      reverted: false,
    }).catch(() => undefined);
    return created;
  }

  async updateTask(
    uid: string,
    before: TaskItem,
    after: TaskItem,
    summary = `Vazifa yangilandi: ${after.title}`,
    batchId: string = genBatchId("tg"),
    sourceVoice = false
  ): Promise<void> {
    const beforeSnap = this.taskSnapshot(before);
    const afterSnap = this.taskSnapshot(after);
    await this.userDoc(uid)
      .collection("tasks")
      .doc(before.id)
      .update({
        ...afterSnap,
        updatedAt: FieldValue.serverTimestamp(),
      });

    // If task was completed or due date changed, cancel stale reminders
    if (after.completed || after.dueDateMillis !== before.dueDateMillis || after.hasDueTime !== before.hasDueTime) {
      await this.cancelTaskReminders(uid, before.id);
    }

    await this.recordActionLog(uid, {
      batchId,
      actionType: "update",
      entityCollection: "tasks",
      entityId: before.id,
      summaryText: summary,
      beforeSummary: before.completed ? `${before.title} (bajarilgan)` : before.title,
      afterSummary: after.completed ? `${after.title} (bajarilgan)` : after.title,
      beforeData: beforeSnap,
      afterData: afterSnap,
      sourceVoice,
      reverted: false,
    }).catch(() => undefined);
  }

  /**
   * Matches Android OvozViewModel.toggleTaskCompleted recurrence logic exactly
   * (daily +1d, weekly +7d, monthly +30d) while preventing duplicate next occurrences.
   */
  async completeTaskWithRecurrence(
    uid: string,
    task: TaskItem,
    timeZone: string,
    batchId: string = genBatchId("chk"),
    sourceVoice = false
  ): Promise<{ nextTask: TaskItem | null }> {
    if (task.completed) return { nextTask: null };
    const after: TaskItem = {
      ...task,
      completed: true,
      completedAtMillis: Date.now(),
    };
    await this.updateTask(uid, task, after, `Vazifa bajarildi: ${task.title}`, batchId, sourceVoice);

    let nextTask: TaskItem | null = null;
    if (task.recurrence !== "none" && task.dueDateMillis > 0) {
      const shiftDays =
        task.recurrence === "daily" ? 1 : task.recurrence === "weekly" ? 7 : task.recurrence === "monthly" ? 30 : 0;
      if (shiftDays > 0) {
        const nextDue = task.dueDateMillis + shiftDays * 86_400_000;
        // Guard: do NOT create next recurring instance twice if Android or another action already created it!
        const allTasks = await this.listTasks(uid);
        const alreadyExists = allTasks.some(
          (t) =>
            !t.completed &&
            t.id !== task.id &&
            t.title.trim().toLowerCase() === task.title.trim().toLowerCase() &&
            isSameDayInZone(t.dueDateMillis, nextDue, timeZone)
        );
        if (!alreadyExists) {
          nextTask = await this.addTask(
            uid,
            {
              ...task,
              completed: false,
              completedAtMillis: 0,
              dueDateMillis: nextDue,
            },
            batchId,
            sourceVoice
          );
        }
      }
    }
    return { nextTask };
  }

  async listTransactions(uid: string): Promise<FinanceTransaction[]> {
    const snaps = await this.userDoc(uid).collection("transactions").get();
    return snaps.docs.map((doc) => {
      const d = doc.data();
      return {
        id: doc.id,
        kind: d.kind || "expense",
        amount: Number(d.amount || 0),
        currency: (d.currency || "UZS") as CurrencyCode,
        category: String(d.category || "Boshqa"),
        title: String(d.title || ""),
        note: String(d.note || ""),
        occurredAtMillis: Number(d.occurredAtMillis || 0),
        personId: String(d.personId || ""),
        personName: String(d.personName || ""),
        goalId: String(d.goalId || ""),
        debtId: String(d.debtId || ""),
        updatedAtMillis: tsToMillis(d.updatedAt),
      };
    });
  }

  async addExpense(
    uid: string,
    tx: Omit<FinanceTransaction, "id" | "kind">,
    batchId: string = genBatchId("exp"),
    sourceVoice = false
  ): Promise<FinanceTransaction> {
    const docRef = this.userDoc(uid).collection("transactions").doc();
    const safeAmount = Math.max(0.01, Number(tx.amount || 0));
    const snap = {
      kind: "expense" as const,
      amount: safeAmount,
      currency: tx.currency,
      category: (tx.category || "Boshqa").trim().slice(0, 50) || "Boshqa",
      title: (tx.title || tx.category || "Xarajat").trim().slice(0, 150),
      note: (tx.note || "").slice(0, 500),
      occurredAtMillis: Math.max(1, Math.round(tx.occurredAtMillis || Date.now())),
      personId: (tx.personId || "").slice(0, 128),
      personName: (tx.personName || "").slice(0, 80),
      goalId: "",
      debtId: "",
    };
    await docRef.set({
      ...snap,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    });
    const created: FinanceTransaction = { ...snap, id: docRef.id };
    await this.recordActionLog(uid, {
      batchId,
      actionType: "create",
      entityCollection: "transactions",
      entityId: docRef.id,
      summaryText: `Xarajat: ${created.title} (${Math.round(created.amount)} ${created.currency})`,
      beforeSummary: "",
      afterSummary: `${created.title} — ${Math.round(created.amount)} ${created.currency}`,
      beforeData: {},
      afterData: snap,
      sourceVoice,
      reverted: false,
    }).catch(() => undefined);
    return created;
  }

  async listDebts(uid: string): Promise<DebtItem[]> {
    const snaps = await this.userDoc(uid).collection("debts").get();
    return snaps.docs.map((doc) => {
      const d = doc.data();
      return {
        id: doc.id,
        direction: d.direction === "lent" ? "lent" : "borrowed",
        personId: String(d.personId || ""),
        personName: String(d.personName || ""),
        originalAmount: Number(d.originalAmount || 0),
        paidAmount: Number(d.paidAmount || 0),
        currency: (d.currency || "UZS") as CurrencyCode,
        note: String(d.note || ""),
        issuedAtMillis: Number(d.issuedAtMillis || 0),
        dueDateMillis: Number(d.dueDateMillis || 0),
        closed: Boolean(d.closed),
        closedAtMillis: Number(d.closedAtMillis || 0),
        updatedAtMillis: tsToMillis(d.updatedAt),
      };
    });
  }

  async addDebt(
    uid: string,
    debt: Omit<DebtItem, "id">,
    batchId: string = genBatchId("debt"),
    sourceVoice = false
  ): Promise<DebtItem> {
    const docRef = this.userDoc(uid).collection("debts").doc();
    const safeOrig = Math.max(0.01, Number(debt.originalAmount || 0));
    const safePaid = Math.min(safeOrig, Math.max(0, Number(debt.paidAmount || 0)));
    const snap = {
      direction: debt.direction === "lent" ? ("lent" as const) : ("borrowed" as const),
      personId: (debt.personId || "").slice(0, 128),
      personName: (debt.personName || "Noma’lum").trim().slice(0, 80),
      originalAmount: safeOrig,
      paidAmount: safePaid,
      currency: debt.currency,
      note: (debt.note || "").slice(0, 500),
      issuedAtMillis: Math.max(1, Math.round(debt.issuedAtMillis || Date.now())),
      dueDateMillis: Math.max(0, Math.round(debt.dueDateMillis || 0)),
      closed: Boolean(debt.closed || safePaid >= safeOrig),
      closedAtMillis: Math.max(0, Math.round(debt.closedAtMillis || 0)),
    };
    await docRef.set({
      ...snap,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    });
    const created: DebtItem = { ...snap, id: docRef.id };
    const dirLabel = created.direction === "lent" ? "qarz berildi" : "qarz olindi";
    await this.recordActionLog(uid, {
      batchId,
      actionType: "create",
      entityCollection: "debts",
      entityId: docRef.id,
      summaryText: `${created.personName}: ${Math.round(created.originalAmount)} ${created.currency} ${dirLabel}`,
      beforeSummary: "",
      afterSummary: `${created.personName} — ${Math.round(created.originalAmount)} ${created.currency}`,
      beforeData: {},
      afterData: snap,
      sourceVoice,
      reverted: false,
    }).catch(() => undefined);
    return created;
  }

  async recordDebtPayment(
    uid: string,
    debt: DebtItem,
    paymentAmount: number,
    batchId: string = genBatchId("dpay"),
    sourceVoice = false
  ): Promise<DebtItem> {
    const remaining = Math.max(0, debt.originalAmount - debt.paidAmount);
    const safePay = Math.min(remaining, Math.max(0.01, paymentAmount));
    const newPaid = Math.min(debt.originalAmount, debt.paidAmount + safePay);
    const isNowClosed = newPaid >= debt.originalAmount - 0.001;
    const closedAtMillis = isNowClosed ? Date.now() : 0;

    // Debt payments stay strictly inside `debts` and are NEVER inserted into `transactions`!
    await this.userDoc(uid)
      .collection("debts")
      .doc(debt.id)
      .update({
        paidAmount: newPaid,
        closed: isNowClosed,
        closedAtMillis,
        updatedAt: FieldValue.serverTimestamp(),
      });

    const after: DebtItem = {
      ...debt,
      paidAmount: newPaid,
      closed: isNowClosed,
      closedAtMillis,
    };
    const { id: _bId, updatedAtMillis: _bUp, ...beforeData } = debt;
    const { id: _aId, updatedAtMillis: _aUp, ...afterData } = after;

    await this.recordActionLog(uid, {
      batchId,
      actionType: "update",
      entityCollection: "debts",
      entityId: debt.id,
      summaryText: isNowClosed
        ? `${debt.personName} qarzi to‘liq yopildi`
        : `${debt.personName} qarzidan ${Math.round(safePay)} ${debt.currency} qaytarildi`,
      beforeSummary: `Qoldiq: ${Math.round(remaining)} ${debt.currency}`,
      afterSummary: `Qoldiq: ${Math.round(Math.max(0, after.originalAmount - after.paidAmount))} ${debt.currency}`,
      beforeData,
      afterData,
      sourceVoice,
      reverted: false,
    }).catch(() => undefined);
    return after;
  }

  async listPeople(uid: string): Promise<PersonItem[]> {
    const snaps = await this.userDoc(uid).collection("people").get();
    return snaps.docs.map((doc) => {
      const d = doc.data();
      return {
        id: doc.id,
        name: String(d.name || ""),
        phone: String(d.phone || ""),
        note: String(d.note || ""),
        avatarColor: String(d.avatarColor || "emerald"),
      };
    });
  }

  async ensurePerson(
    uid: string,
    name: string,
    batchId: string = genBatchId("tg"),
    sourceVoice = false
  ): Promise<PersonItem> {
    const clean = name.trim().slice(0, 80);
    const existing = (await this.listPeople(uid)).find(
      (p) => p.name.toLowerCase() === clean.toLowerCase()
    );
    if (existing) return existing;

    const colors = ["emerald", "ocean", "amber", "violet", "coral"];
    const color = colors[clean.length % colors.length];
    const docRef = this.userDoc(uid).collection("people").doc();
    const snap = { name: clean || "Inson", phone: "", note: "", avatarColor: color };
    await docRef.set({
      ...snap,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    });
    const created: PersonItem = { ...snap, id: docRef.id };
    await this.recordActionLog(uid, {
      batchId,
      actionType: "create",
      entityCollection: "people",
      entityId: docRef.id,
      summaryText: `Inson qo‘shildi: ${created.name}`,
      beforeSummary: "",
      afterSummary: created.name,
      beforeData: {},
      afterData: snap,
      sourceVoice,
      reverted: false,
    }).catch(() => undefined);
    return created;
  }

  async listActionLogs(uid: string, limit = 30): Promise<ActionLogItem[]> {
    const snaps = await this.userDoc(uid).collection("action_logs").get();
    return snaps.docs
      .map((doc) => {
        const d = doc.data();
        return {
          id: doc.id,
          batchId: String(d.batchId || ""),
          actionType: (d.actionType || "create") as ActionLogItem["actionType"],
          entityCollection: (d.entityCollection || "tasks") as ActionLogItem["entityCollection"],
          entityId: String(d.entityId || ""),
          summaryText: String(d.summaryText || ""),
          beforeSummary: String(d.beforeSummary || ""),
          afterSummary: String(d.afterSummary || ""),
          beforeData: (d.beforeData || {}) as Record<string, unknown>,
          afterData: (d.afterData || {}) as Record<string, unknown>,
          sourceVoice: Boolean(d.sourceVoice),
          reverted: Boolean(d.reverted),
          createdAtMillis: tsToMillis(d.createdAt),
        };
      })
      .sort((a, b) => b.createdAtMillis - a.createdAtMillis)
      .slice(0, limit);
  }

  /**
   * Safe undo (Requirement 15):
   * Verifies that the target document has NOT been subsequently modified on another device
   * before reverting or deleting it!
   */
  async undoActionLogSafe(
    uid: string,
    log: ActionLogItem
  ): Promise<{ status: "undone" | "conflict" | "already_reverted" }> {
    if (log.reverted) return { status: "already_reverted" };
    const targetRef = this.userDoc(uid).collection(log.entityCollection).doc(log.entityId);
    const snap = await targetRef.get();

    if (log.actionType === "create") {
      if (snap.exists) {
        const docUpdatedMs = tsToMillis(snap.data()?.updatedAt);
        // If modified more than 10 seconds after log creation, another device edited it -> refuse silent overwrite!
        if (log.createdAtMillis > 0 && docUpdatedMs > log.createdAtMillis + 10_000) {
          return { status: "conflict" };
        }
        await targetRef.delete();
        if (log.entityCollection === "tasks") {
          await this.cancelTaskReminders(uid, log.entityId);
        }
      }
    } else if (log.actionType === "update") {
      if (!snap.exists) return { status: "conflict" };
      const docUpdatedMs = tsToMillis(snap.data()?.updatedAt);
      if (log.createdAtMillis > 0 && docUpdatedMs > log.createdAtMillis + 10_000) {
        return { status: "conflict" };
      }
      if (Object.keys(log.beforeData).length > 0) {
        await targetRef.update({
          ...log.beforeData,
          updatedAt: FieldValue.serverTimestamp(),
        });
      }
    } else if (log.actionType === "delete") {
      if (snap.exists) return { status: "conflict" };
      if (Object.keys(log.beforeData).length > 0) {
        await targetRef.set({
          ...log.beforeData,
          createdAt: FieldValue.serverTimestamp(),
          updatedAt: FieldValue.serverTimestamp(),
        });
      }
    }

    await this.userDoc(uid).collection("action_logs").doc(log.id).update({ reverted: true });
    return { status: "undone" };
  }

  async undoBatchSafe(uid: string, batchId: string): Promise<UndoResult> {
    const logs = (await this.listActionLogs(uid, 50)).filter(
      (l) => l.batchId === batchId && !l.reverted
    );
    let undoneCount = 0;
    let skippedConflictCount = 0;
    const summaries: string[] = [];
    for (const log of logs) {
      const res = await this.undoActionLogSafe(uid, log);
      if (res.status === "undone") {
        undoneCount++;
        summaries.push(log.summaryText);
      } else if (res.status === "conflict") {
        skippedConflictCount++;
      }
    }
    return { undoneCount, skippedConflictCount, summaries };
  }

  async upsertReminder(
    reminder: Omit<ScheduledReminder, "id">,
    customId?: string
  ): Promise<ScheduledReminder> {
    const ref = customId
      ? this.db.collection("telegram_reminders").doc(customId)
      : this.db.collection("telegram_reminders").doc();
    await ref.set(reminder, { merge: true });
    return { ...reminder, id: ref.id };
  }

  async listPendingRemindersDue(uid: string, nowMillis: number): Promise<ScheduledReminder[]> {
    const snaps = await this.db
      .collection("telegram_reminders")
      .where("uid", "==", uid)
      .where("status", "==", "pending")
      .get();
    return snaps.docs
      .map((d) => ({ ...(d.data() as Omit<ScheduledReminder, "id">), id: d.id }))
      .filter((r) => r.triggerAtMillis <= nowMillis);
  }

  async listTaskReminders(uid: string, taskId: string): Promise<ScheduledReminder[]> {
    const snaps = await this.db
      .collection("telegram_reminders")
      .where("uid", "==", uid)
      .where("taskId", "==", taskId)
      .get();
    return snaps.docs.map((d) => ({ ...(d.data() as Omit<ScheduledReminder, "id">), id: d.id }));
  }

  async markReminderSent(reminderId: string, sentAtMillis: number): Promise<void> {
    await this.db.collection("telegram_reminders").doc(reminderId).update({
      status: "sent",
      sentAtMillis,
    });
  }

  async cancelTaskReminders(uid: string, taskId: string, kinds?: ReminderKind[]): Promise<void> {
    const list = await this.listTaskReminders(uid, taskId);
    const batch = this.db.batch();
    let count = 0;
    for (const r of list) {
      if (r.status === "pending" && (!kinds || kinds.includes(r.kind))) {
        batch.update(this.db.collection("telegram_reminders").doc(r.id), { status: "cancelled" });
        count++;
      }
    }
    if (count > 0) await batch.commit();
  }

  async cancelAllUserReminders(uid: string): Promise<void> {
    const snaps = await this.db
      .collection("telegram_reminders")
      .where("uid", "==", uid)
      .where("status", "==", "pending")
      .get();
    if (snaps.empty) return;
    const batch = this.db.batch();
    for (const d of snaps.docs) {
      batch.update(d.ref, { status: "cancelled" });
    }
    await batch.commit();
  }
}

import { OvozStore } from "./repository";
import { TelegramClient } from "./telegramApi";
import { GeminiClient } from "./geminiService";
import { computeDailyReportMetrics, computeWeeklyReportMetrics } from "./analytics";
import { escapeHtml } from "./security";
import {
  dateKeyInZone,
  formatMoneyUz,
  formatTime24InZone,
  formatUzDateShort,
  getZonedParts,
  isHourWithinWindow,
  isTodayInZone,
  weekKeyInZone,
} from "./time";
import { ReminderKind, TaskItem, TelegramUserState } from "./types";

const SMART_OFFSETS: Array<{ kind: ReminderKind; minutesBefore: number; label: string }> = [
  { kind: "smart_60", minutesBefore: 60, label: "1 soat qoldi" },
  { kind: "smart_30", minutesBefore: 30, label: "30 daqiqa qoldi" },
  { kind: "smart_10", minutesBefore: 10, label: "10 daqiqa qoldi" },
];

export interface SchedulerTickSummary {
  usersChecked: number;
  smartRemindersSent: number;
  snoozeRemindersSent: number;
  hourlyRemindersSent: number;
  dailyReviewsSent: number;
  weeklyReportsSent: number;
}

/**
 * Reconciles smart reminders (60m, 30m, 10m before due time) in persistent Firestore storage
 * for every active timed task so reminders survive server restarts and automatically cancel
 * whenever a task is completed, deleted, or rescheduled.
 */
export async function syncSmartRemindersForTask(
  store: OvozStore,
  uid: string,
  telegramChatId: string,
  task: TaskItem,
  nowMillis = Date.now()
): Promise<void> {
  // Date-only tasks (hasDueTime == false) NEVER get fabricated timed smart reminders!
  if (task.completed || !task.hasDueTime || task.dueDateMillis <= nowMillis) {
    await store.cancelTaskReminders(uid, task.id, ["smart_60", "smart_30", "smart_10"]);
    return;
  }

  const existing = await store.listTaskReminders(uid, task.id);
  for (const offset of SMART_OFFSETS) {
    const triggerAt = task.dueDateMillis - offset.minutesBefore * 60_000;
    const deterministicId = `${uid}_${task.id}_${offset.kind}`;
    const prev = existing.find((r) => r.id === deterministicId);

    // If task due time hasn't changed and this reminder was already sent, skip!
    if (prev && prev.status === "sent" && prev.taskDueDateMillis === task.dueDateMillis) {
      continue;
    }

    // Only schedule if trigger window is upcoming (or within the last 5 minutes grace window)
    if (triggerAt >= nowMillis - 5 * 60_000) {
      await store.upsertReminder(
        {
          uid,
          telegramChatId,
          taskId: task.id,
          kind: offset.kind,
          triggerAtMillis: triggerAt,
          taskDueDateMillis: task.dueDateMillis,
          status: "pending",
          createdAtMillis: nowMillis,
          sentAtMillis: 0,
        },
        deterministicId
      );
    } else if (prev && prev.status === "pending") {
      await store.cancelTaskReminders(uid, task.id, [offset.kind]);
    }
  }
}

export function buildHourlyReminderMessage(
  tasks: TaskItem[],
  timeZone: string,
  nowMillis: number
): {
  text: string;
  inline_keyboard: Array<Array<{ text: string; callback_data: string }>>;
} {
  const timeLabel = formatTime24InZone(nowMillis, timeZone);
  const lines = [`<b>${timeLabel} — Qolgan vazifalar</b>`, ""];
  const buttons: Array<Array<{ text: string; callback_data: string }>> = [];

  tasks.slice(0, 8).forEach((t, idx) => {
    const dueStr = t.hasDueTime ? ` · ${formatTime24InZone(t.dueDateMillis, timeZone)}` : "";
    lines.push(`☐ ${escapeHtml(t.title)}${dueStr}`);
    const shortTitle = t.title.length > 18 ? `${t.title.slice(0, 17)}…` : t.title;
    buttons.push([
      { text: `✓ ${idx + 1}. ${shortTitle}`, callback_data: `tdone:${t.id}` },
      { text: "Keyinroq", callback_data: `tsnzmenu:${t.id}` },
      { text: "Tahrir", callback_data: `tedit:${t.id}` },
    ]);
  });

  if (tasks.length > 8) {
    lines.push("", `<i>+ yana ${tasks.length - 8} ta vazifa</i>`);
  }

  return { text: lines.join("\n"), inline_keyboard: buttons };
}

export function buildDailyReviewMessage(
  metrics: ReturnType<typeof computeDailyReportMetrics>,
  aiSummary: string,
  timeZone: string,
  nowMillis: number
): {
  text: string;
  inline_keyboard: Array<Array<{ text: string; callback_data: string }>>;
} {
  const totalToday = metrics.completedTodayCount + metrics.remainingTodayTasks.length;
  const dateLabel = formatUzDateShort(nowMillis, timeZone);
  const expenseLines = Object.entries(metrics.expensesByCurrency).map(([cur, amt]) =>
    formatMoneyUz(amt, cur)
  );
  const expenseText =
    expenseLines.length > 0
      ? expenseLines.join(", ")
      : formatMoneyUz(0, metrics.primaryCurrency);

  const lines = [
    `<b>Kun yakuni · ${escapeHtml(dateLabel)}</b>`,
    "",
    `Vazifalar: <b>${metrics.completedTodayCount}/${totalToday}</b> bajarildi`,
    `Qolgan vazifalar: <b>${metrics.remainingTodayTasks.length} ta</b>`,
    `Bugungi xarajatlar: <b>${escapeHtml(expenseText)}</b>`,
  ];
  if (metrics.topExpenseCategory) {
    lines.push(`Eng katta xarajat: <b>${escapeHtml(metrics.topExpenseCategory.toLowerCase())}</b>`);
  }
  lines.push(`Ertangi vazifalar: <b>${metrics.tomorrowTasks.length} ta</b>`);
  if (aiSummary.trim()) {
    lines.push("", `<i>${escapeHtml(aiSummary.trim())}</i>`);
  }

  const keyboard: Array<Array<{ text: string; callback_data: string }>> = [
    [
      { text: "Qolgan vazifalar", callback_data: "rev:remaining" },
      { text: "Ertangi reja", callback_data: "rev:tomorrow" },
    ],
  ];
  if (metrics.remainingTodayTasks.length > 0) {
    keyboard.unshift([{ text: "Ertaga ko‘chirish", callback_data: "rev:move_ask" }]);
  }

  return { text: lines.join("\n"), inline_keyboard: keyboard };
}

export function buildWeeklyReportMessage(
  metrics: ReturnType<typeof computeWeeklyReportMetrics>,
  aiSummary: string
): string {
  const expenseParts = Object.entries(metrics.expensesByCurrency).map(([cur, amt]) =>
    formatMoneyUz(amt, cur)
  );
  const expenseText =
    expenseParts.length > 0 ? expenseParts.join(", ") : formatMoneyUz(0, metrics.primaryCurrency);

  const lines = [
    "<b>Haftalik hisobot</b>",
    "",
    `✓ ${metrics.completedCount} ta vazifa bajarildi`,
    `○ ${metrics.incompleteCount} ta vazifa bajarilmay qoldi`,
  ];
  if (metrics.overdueCount > 0) {
    lines.push(`! ${metrics.overdueCount} ta vazifa kechikmoqda`);
  }
  lines.push("", `Xarajatlar: <b>${escapeHtml(expenseText)}</b>`);

  if (metrics.topCategory) {
    lines.push(
      `Eng ko‘p sarf: <b>${escapeHtml(metrics.topCategory)}</b> (${formatMoneyUz(
        metrics.topCategoryAmount,
        metrics.primaryCurrency
      )})`
    );
  }
  if (metrics.primaryChangePercent !== null) {
    const dir = metrics.primaryChangePercent >= 0 ? "oshgan" : "kamaygan";
    lines.push(
      `O‘tgan haftaga nisbatan: <b>${Math.abs(metrics.primaryChangePercent)}% ${dir}</b>`
    );
  }

  if (metrics.activeDebtCount > 0) {
    const borrowed = Object.entries(metrics.activeBorrowedByCurrency)
      .map(([c, a]) => formatMoneyUz(a, c))
      .join(", ");
    const lent = Object.entries(metrics.activeLentByCurrency)
      .map(([c, a]) => formatMoneyUz(a, c))
      .join(", ");
    lines.push("", `Faol qarzlar: <b>${metrics.activeDebtCount} ta</b>`);
    if (borrowed) lines.push(`• Men qaytarishim kerak: ${escapeHtml(borrowed)}`);
    if (lent) lines.push(`• Menga qaytarishlari kerak: ${escapeHtml(lent)}`);
  }

  if (aiSummary.trim()) {
    lines.push("", `<i>${escapeHtml(aiSummary.trim())}</i>`);
  }
  return lines.join("\n");
}

/**
 * Single shared 1-minute server tick handling ALL linked users:
 * 1) Smart timed task reminders (60m / 30m / 10m) & Snooze reminders
 * 2) Hourly daily task reminders (deduplicated against smart reminders)
 * 3) Daily evening review ("Kun yakuni", synced with Android eveningReviewHour/notifyEvening)
 * 4) Weekly report ("Haftalik hisobot", default Sunday 20:00)
 */
export async function runSchedulerTick(
  store: OvozStore,
  telegram: TelegramClient,
  gemini: GeminiClient,
  nowMillis = Date.now()
): Promise<SchedulerTickSummary> {
  const summary: SchedulerTickSummary = {
    usersChecked: 0,
    smartRemindersSent: 0,
    snoozeRemindersSent: 0,
    hourlyRemindersSent: 0,
    dailyReviewsSent: 0,
    weeklyReportsSent: 0,
  };

  const links = await store.listActiveLinks();
  for (const link of links) {
    const state = await store.getTelegramUserState(link.uid);
    // If unlinked from Android or Telegram, skip immediately & stop reminders!
    if (!state || !state.linked || state.telegramUserId !== link.telegramUserId) {
      continue;
    }
    summary.usersChecked++;

    const profile = await store.getUserProfile(link.uid);
    const tasks = await store.listTasks(link.uid);
    const taskMap = new Map(tasks.map((t) => [t.id, t]));
    const tz = state.timezone;
    const zonedNow = getZonedParts(nowMillis, tz);
    const recentlyNotifiedTaskIds = new Set<string>();

    // 1. Sync & dispatch smart reminders (60m, 30m, 10m) and snoozed reminders
    if (state.remindersEnabled && profile.notifyAll && profile.notifyTasks) {
      if (state.smartRemindersEnabled) {
        const timedOpenTasks = tasks.filter(
          (t) => !t.completed && t.hasDueTime && t.dueDateMillis > nowMillis && t.dueDateMillis <= nowMillis + 24 * 3_600_000
        );
        for (const t of timedOpenTasks) {
          await syncSmartRemindersForTask(store, link.uid, state.telegramChatId, t, nowMillis);
        }
      }

      const dueReminders = await store.listPendingRemindersDue(link.uid, nowMillis);
      for (const rem of dueReminders) {
        const latestTask = taskMap.get(rem.taskId);
        // Verify live Firestore state before sending: deleted, completed, or rescheduled? Cancel!
        if (!latestTask || latestTask.completed) {
          await store.cancelTaskReminders(link.uid, rem.taskId, [rem.kind]);
          continue;
        }
        if (
          rem.kind !== "snooze" &&
          (!latestTask.hasDueTime || latestTask.dueDateMillis !== rem.taskDueDateMillis)
        ) {
          await store.cancelTaskReminders(link.uid, rem.taskId, [rem.kind]);
          continue;
        }
        if (rem.kind !== "snooze" && !state.smartRemindersEnabled) {
          continue;
        }

        const header =
          rem.kind === "smart_60"
            ? "1 soat qoldi"
            : rem.kind === "smart_30"
              ? "30 daqiqa qoldi"
              : rem.kind === "smart_10"
                ? "10 daqiqa qoldi"
                : "Eslatma";
        const dueTime = latestTask.hasDueTime
          ? ` — ${formatTime24InZone(latestTask.dueDateMillis, tz)}`
          : "";
        const text = `<b>${header}</b>\n\n${escapeHtml(latestTask.title)}${dueTime}`;

        const sent = await telegram.sendMessage(state.telegramChatId, text, {
          reply_markup: {
            inline_keyboard: [
              [
                { text: "✓ Bajarildi", callback_data: `tdone:${latestTask.id}` },
                { text: "Keyinroq", callback_data: `tsnzmenu:${latestTask.id}` },
              ],
              [{ text: "Muddatni o‘zgartirish", callback_data: `tresch:${latestTask.id}` }],
            ],
          },
        });

        if (sent) {
          await store.markReminderSent(rem.id, nowMillis);
          recentlyNotifiedTaskIds.add(latestTask.id);
          if (rem.kind === "snooze") summary.snoozeRemindersSent++;
          else summary.smartRemindersSent++;
        }
      }

      // 2. Hourly reminders for incomplete TODAY tasks within active window (default 08:00-22:00)
      const inWindow = isHourWithinWindow(zonedNow.hour, state.activeStartHour, state.activeEndHour);
      const intervalMs = Math.max(15, state.hourlyIntervalMinutes || 60) * 60_000;
      const elapsedSinceLast = nowMillis - (state.lastHourlySentAtMillis || 0);
      const isTopOfSchedule =
        state.lastHourlySentAtMillis === 0
          ? zonedNow.minute === 0
          : elapsedSinceLast >= intervalMs - 30_000;

      if (inWindow && isTopOfSchedule) {
        // Only incomplete tasks belonging to TODAY, excluding ones that JUST got a smart reminder right now
        const todayIncomplete = tasks
          .filter(
            (t) =>
              !t.completed &&
              isTodayInZone(t.dueDateMillis, tz, nowMillis) &&
              !recentlyNotifiedTaskIds.has(t.id)
          )
          .sort((a, b) => a.dueDateMillis - b.dueDateMillis);

        if (todayIncomplete.length > 0) {
          const msg = buildHourlyReminderMessage(todayIncomplete, tz, nowMillis);
          const sent = await telegram.sendMessage(state.telegramChatId, msg.text, {
            reply_markup: { inline_keyboard: msg.inline_keyboard },
          });
          if (sent) {
            await store.updateTelegramUserState(link.uid, { lastHourlySentAtMillis: nowMillis });
            summary.hourlyRemindersSent++;
          }
        }
      }
    }

    // 3. Kun yakuni (Daily Evening Review — strictly synced with Android profile settings!)
    const todayKey = dateKeyInZone(nowMillis, tz);
    if (
      profile.notifyAll &&
      profile.notifyEvening &&
      state.lastDailyReviewDateKey !== todayKey &&
      zonedNow.hour === profile.eveningReviewHour &&
      zonedNow.minute >= profile.eveningReviewMinute &&
      zonedNow.minute < profile.eveningReviewMinute + 15
    ) {
      const transactions = await store.listTransactions(link.uid);
      const metrics = computeDailyReportMetrics(tasks, transactions, profile.primaryCurrency, tz, nowMillis);
      const aiSummary = await gemini.summarizeDailyReport(metrics, tz);
      const reviewMsg = buildDailyReviewMessage(metrics, aiSummary, tz, nowMillis);
      const sent = await telegram.sendMessage(state.telegramChatId, reviewMsg.text, {
        reply_markup: { inline_keyboard: reviewMsg.inline_keyboard },
      });
      if (sent) {
        await store.updateTelegramUserState(link.uid, { lastDailyReviewDateKey: todayKey });
        summary.dailyReviewsSent++;
      }
    }

    // 4. Haftalik hisobot (Weekly Report — default Sunday 20:00)
    const currentWeekKey = weekKeyInZone(nowMillis, tz);
    if (
      profile.notifyAll &&
      profile.notifyReports &&
      state.weeklyReportEnabled &&
      state.lastWeeklyReviewWeekKey !== currentWeekKey &&
      zonedNow.dayOfWeek === state.weeklyReportDay &&
      zonedNow.hour === state.weeklyReportHour &&
      zonedNow.minute < 15
    ) {
      const [transactions, debts] = await Promise.all([
        store.listTransactions(link.uid),
        store.listDebts(link.uid),
      ]);
      const metrics = computeWeeklyReportMetrics(
        tasks,
        transactions,
        debts,
        profile.primaryCurrency,
        tz,
        nowMillis
      );
      const aiSummary = await gemini.summarizeWeeklyReport(metrics);
      const reportText = buildWeeklyReportMessage(metrics, aiSummary);
      const sent = await telegram.sendMessage(state.telegramChatId, reportText);
      if (sent) {
        await store.updateTelegramUserState(link.uid, { lastWeeklyReviewWeekKey: currentWeekKey });
        summary.weeklyReportsSent++;
      }
    }
  }

  return summary;
}

export function shouldSendSmartReminders(state: TelegramUserState): boolean {
  return state.linked && state.remindersEnabled && state.smartRemindersEnabled;
}

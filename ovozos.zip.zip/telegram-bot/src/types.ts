// 1:1 TypeScript models matching Android OvozModels.kt & Firestore schema

export type CurrencyCode = "UZS" | "USD" | "EUR" | "RUB";
export type TaskPriority = "low" | "medium" | "high";
export type TaskRecurrence = "none" | "daily" | "weekly" | "monthly";
export type ReplyMode = "text" | "voice" | "both";
export type VoiceLang = "uz" | "ru" | "en";

export interface UserProfile {
  id: string;
  userId: string;
  displayName: string;
  onboardingDone: boolean;
  language: "uz" | "ru" | "en";
  aiResponseLang: "auto" | "uz" | "ru" | "en";
  primaryCurrency: CurrencyCode;
  notifyAll: boolean;
  notifyTasks: boolean;
  notifyDebts: boolean;
  notifyEvening: boolean;
  eveningReviewHour: number;
  eveningReviewMinute: number;
  notifyReports: boolean;
  autoSaveVoice: boolean;
}

export interface TaskItem {
  id: string;
  title: string;
  description: string;
  dueDateMillis: number;
  hasDueTime: boolean;
  priority: TaskPriority;
  category: string;
  recurrence: TaskRecurrence;
  completed: boolean;
  completedAtMillis: number;
  personId: string;
  personName: string;
  goalId: string;
  noteText: string;
  reminderEnabled: boolean;
  updatedAtMillis?: number;
}

export interface FinanceTransaction {
  id: string;
  kind: "expense" | "income" | "goal_saving" | "debt_payment";
  amount: number;
  currency: CurrencyCode;
  category: string;
  title: string;
  note: string;
  occurredAtMillis: number;
  personId: string;
  personName: string;
  goalId: string;
  debtId: string;
  updatedAtMillis?: number;
}

export interface DebtItem {
  id: string;
  direction: "borrowed" | "lent";
  personId: string;
  personName: string;
  originalAmount: number;
  paidAmount: number;
  currency: CurrencyCode;
  note: string;
  issuedAtMillis: number;
  dueDateMillis: number;
  closed: boolean;
  closedAtMillis: number;
  updatedAtMillis?: number;
}

export interface PersonItem {
  id: string;
  name: string;
  phone: string;
  note: string;
  avatarColor: string;
}

export interface ActionLogItem {
  id: string;
  batchId: string;
  actionType: "create" | "update" | "delete";
  entityCollection: "tasks" | "notes" | "transactions" | "debts" | "people" | "goals";
  entityId: string;
  summaryText: string;
  beforeSummary: string;
  afterSummary: string;
  beforeData: Record<string, unknown>;
  afterData: Record<string, unknown>;
  sourceVoice: boolean;
  reverted: boolean;
  createdAtMillis: number;
}

export interface TelegramLinkRecord {
  telegramUserId: string;
  uid: string;
  telegramChatId: string;
  telegramUsername: string;
  telegramFirstName: string;
  linkedAtMillis: number;
  active: boolean;
}

export interface TelegramUserState {
  linked: boolean;
  telegramUserId: string;
  telegramChatId: string;
  telegramUsername: string;
  telegramFirstName: string;
  linkedAtMillis: number;
  timezone: string;
  remindersEnabled: boolean;
  hourlyIntervalMinutes: number;
  activeStartHour: number;
  activeEndHour: number;
  smartRemindersEnabled: boolean;
  weeklyReportEnabled: boolean;
  weeklyReportDay: number; // 0 = Sunday .. 6 = Saturday
  weeklyReportHour: number;
  replyMode: ReplyMode;
  voiceLanguage: VoiceLang;
  lastHourlySentAtMillis: number;
  lastDailyReviewDateKey: string;
  lastWeeklyReviewWeekKey: string;
}

export const DEFAULT_TELEGRAM_USER_STATE: Omit<
  TelegramUserState,
  "telegramUserId" | "telegramChatId" | "telegramUsername" | "telegramFirstName" | "linkedAtMillis"
> = {
  linked: true,
  timezone: "Asia/Tashkent",
  remindersEnabled: true,
  hourlyIntervalMinutes: 60,
  activeStartHour: 8,
  activeEndHour: 22,
  smartRemindersEnabled: true,
  weeklyReportEnabled: true,
  weeklyReportDay: 0, // Yakshanba
  weeklyReportHour: 20,
  replyMode: "text",
  voiceLanguage: "uz",
  lastHourlySentAtMillis: 0,
  lastDailyReviewDateKey: "",
  lastWeeklyReviewWeekKey: "",
};

export type ReminderKind = "smart_60" | "smart_30" | "smart_10" | "snooze";

export interface ScheduledReminder {
  id: string;
  uid: string;
  telegramChatId: string;
  taskId: string;
  kind: ReminderKind;
  triggerAtMillis: number;
  taskDueDateMillis: number;
  status: "pending" | "sent" | "cancelled";
  createdAtMillis: number;
  sentAtMillis: number;
}

export type ParsedActionType =
  | "CREATE_TASK"
  | "COMPLETE_TASK"
  | "CREATE_EXPENSE"
  | "CREATE_DEBT_BORROWED"
  | "CREATE_DEBT_LENT"
  | "PAY_DEBT"
  | "UNDO_LAST_ACTION"
  | "ANSWER_QUESTION";

export interface ParsedAction {
  localId: string;
  type: ParsedActionType;
  title: string;
  subtitle: string;
  amount: number;
  currency: CurrencyCode;
  category: string;
  personName: string;
  dueDateIso: string;
  dueDateMillis: number;
  hasDueTime: boolean;
  priority: TaskPriority;
  recurrence: TaskRecurrence;
  matchedEntityId: string;
  duplicateTaskId?: string;
  duplicateTaskTitle?: string;
  duplicateResolution?: "create_new" | "update_existing" | "skip";
  selected: boolean;
}

export interface VoiceAnalysisResult {
  transcript: string;
  isQuestionOnly: boolean;
  clarificationQuestion: string;
  assistantReply: string;
  actions: ParsedAction[];
}

export interface PendingDraft {
  id: string;
  rawText: string;
  sourceVoice: boolean;
  isForwarded: boolean;
  actions: ParsedAction[];
  createdAtMillis: number;
  messageId?: number;
}

export interface ClarificationContext {
  originalText: string;
  assistantQuestion: string;
  sourceVoice: boolean;
  isForwarded: boolean;
  originalMessageDateMillis?: number;
  turnCount: number;
  updatedAtMillis: number;
}

export interface BotSession {
  telegramUserId: string;
  pendingLinkCodeHash?: string;
  pendingLinkUid?: string;
  pendingLinkTimezone?: string;
  pendingDraft?: PendingDraft | null;
  clarificationContext?: ClarificationContext | null;
  pendingEdit?: {
    draftId: string;
    actionIndex: number;
    field: "title" | "amount" | "due";
  } | null;
  pendingTaskEdit?: {
    taskId: string;
    field: "title" | "due";
  } | null;
  pendingMoveTomorrow?: {
    taskIds: string[];
    dateKey: string;
  } | null;
  rateLimitCount?: number;
  rateLimitWindowStart?: number;
  updatedAtMillis: number;
}

export interface TelegramUpdate {
  update_id: number;
  message?: TelegramMessage;
  callback_query?: TelegramCallbackQuery;
}

export interface TelegramUser {
  id: number;
  is_bot?: boolean;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
}

export interface TelegramChat {
  id: number;
  type: "private" | "group" | "supergroup" | "channel";
  title?: string;
  username?: string;
  first_name?: string;
}

export interface TelegramMessage {
  message_id: number;
  from?: TelegramUser;
  chat: TelegramChat;
  date: number;
  text?: string;
  caption?: string;
  voice?: {
    file_id: string;
    file_unique_id: string;
    duration: number;
    mime_type?: string;
    file_size?: number;
  };
  audio?: {
    file_id: string;
    duration: number;
    mime_type?: string;
    file_size?: number;
  };
  forward_origin?: {
    type: string;
    date: number;
    sender_user?: TelegramUser;
    sender_user_name?: string;
    chat?: TelegramChat;
  };
  forward_date?: number;
  forward_from?: TelegramUser;
  forward_sender_name?: string;
  forward_from_chat?: TelegramChat;
}

export interface TelegramCallbackQuery {
  id: string;
  from: TelegramUser;
  message?: TelegramMessage;
  data?: string;
}

export const EXPENSE_CATEGORIES_UZ = [
  "Oziq-ovqat",
  "Transport",
  "Ta’lim",
  "Kiyim-kechak",
  "Ko‘ngilochar",
  "Obunalar",
  "Sog‘liq",
  "Xaridlar",
  "Uy-joy",
  "Aloqa",
  "Boshqa",
] as const;

export const SUPPORTED_CURRENCIES: CurrencyCode[] = ["UZS", "USD", "EUR", "RUB"];

import crypto from "crypto";
import type { Request } from "express";
import type * as admin from "firebase-admin";

/**
 * Constant-time comparison for Telegram webhook secret header (`X-Telegram-Bot-Api-Secret-Token`)
 * or Cloud Scheduler cron secret (`X-Cron-Secret`).
 */
export function verifySecretHeader(
  provided: string | undefined,
  expected: string
): boolean {
  if (!expected || !provided) return false;
  const a = Buffer.from(provided.trim(), "utf8");
  const b = Buffer.from(expected.trim(), "utf8");
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

/**
 * Generates a high-entropy URL-safe one-time linking code (usable in `t.me/<bot>?start=<code>`)
 * and returns both the raw code (given once to Android) and its SHA-256 hash (stored in Firestore).
 */
export function generateOneTimeLinkCode(): { rawCode: string; codeHash: string } {
  const rawCode = "ovz_" + crypto.randomBytes(24).toString("base64url");
  const codeHash = hashLinkCode(rawCode);
  return { rawCode, codeHash };
}

export function hashLinkCode(rawCode: string): string {
  return crypto.createHash("sha256").update(rawCode.trim(), "utf8").digest("hex");
}

/**
 * Verifies a Firebase Auth ID token from `Authorization: Bearer <token>` on Android API calls.
 */
export async function verifyFirebaseBearerToken(
  req: Request,
  auth: admin.auth.Auth
): Promise<{ uid: string; email?: string } | null> {
  const header = req.header("authorization") || req.header("Authorization") || "";
  if (!header.startsWith("Bearer ")) return null;
  const idToken = header.slice("Bearer ".length).trim();
  if (!idToken || idToken.length > 8192) return null;
  try {
    const decoded = await auth.verifyIdToken(idToken, true);
    if (!decoded.uid) return null;
    return { uid: decoded.uid, email: decoded.email };
  } catch {
    return null;
  }
}

/**
 * Sanitizes untrusted user / forwarded message text before passing to Gemini:
 * strips control characters and caps length to avoid token abuse / prompt injection payloads.
 */
export function sanitizeUntrustedText(raw: string, maxLen = 2000): string {
  return (raw || "")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, maxLen);
}

/**
 * Escapes text for Telegram HTML parse_mode so untrusted titles/notes never break markup or inject tags.
 */
export function escapeHtml(input: string): string {
  return (input || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/**
 * Simple sliding-window rate limiter helper backed by BotSession fields.
 */
export function checkRateLimit(
  currentCount: number | undefined,
  windowStart: number | undefined,
  maxPerMinute: number,
  nowMillis = Date.now()
): { allowed: boolean; nextCount: number; nextWindowStart: number } {
  const windowMs = 60_000;
  if (!windowStart || nowMillis - windowStart >= windowMs) {
    return { allowed: true, nextCount: 1, nextWindowStart: nowMillis };
  }
  const nextCount = (currentCount || 0) + 1;
  return {
    allowed: nextCount <= maxPerMinute,
    nextCount,
    nextWindowStart: windowStart,
  };
}

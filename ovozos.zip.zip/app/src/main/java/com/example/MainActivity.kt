package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ai.GeminiVoiceEngine
import com.example.ai.SpeechController
import com.example.core.NotificationHelper
import com.example.core.configureAppCheck
import com.example.core.signOutUser
import com.example.core.stringsFor
import com.example.data.model.UserProfile
import com.example.data.model.VoiceStage
import com.example.data.repo.OvozRepository
import com.example.ui.components.OvozFloatingBottomBar
import com.example.ui.components.OvozNavigationRail
import com.example.ui.components.OvozUndoSnackbar
import com.example.ui.components.PinLockOverlay
import com.example.ui.screens.ActionHistoryScreen
import com.example.ui.screens.AssistantChatScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.EveningReviewScreen
import com.example.ui.screens.FinanceScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MoreHubScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PeopleScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SmartSearchScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.screens.VoiceAssistantOverlay
import com.example.ui.theme.OvozOSTheme
import com.example.ui.viewmodel.LoadState
import com.example.ui.viewmodel.OvozViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Initialize Firebase App Check FIRST before any UI, ViewModel, or Firebase SDK calls
        configureAppCheck(this, intent)
        enableEdgeToEdge()
        NotificationHelper.ensureChannel(this)

        val initialRoute = intent?.getStringExtra("ovozos_target_route")

        setContent {
            OvozOSRoot(initialRoute = initialRoute)
        }
    }
}

@Composable
private fun OvozOSRoot(initialRoute: String?) {
    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    val user = currentUser
    if (user == null) {
        OvozOSTheme {
            AuthScreen(
                onAuthSuccess = {
                    currentUser = Firebase.auth.currentUser
                }
            )
        }
    } else {
        key(user.uid) {
            AuthenticatedOvozApp(
                uid = user.uid,
                firebaseDisplayName = user.displayName.orEmpty(),
                initialRoute = initialRoute
            )
        }
    }
}

@Composable
private fun AuthenticatedOvozApp(
    uid: String,
    firebaseDisplayName: String,
    initialRoute: String?
) {
    val context = LocalContext.current
    val appContext = context.applicationContext
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val vm: OvozViewModel = viewModel(
        key = uid,
        factory = viewModelFactory {
            initializer {
                val dbId = appContext.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(dbId)
                OvozViewModel(
                    repository = OvozRepository(db),
                    geminiEngine = GeminiVoiceEngine(),
                    currentUserId = uid
                )
            }
        }
    )

    val profileState by vm.profileState.collectAsStateWithLifecycle()
    val pinUnlocked by vm.pinUnlocked.collectAsStateWithLifecycle()
    val toastMessage by vm.toastMessage.collectAsStateWithLifecycle()

    LaunchedEffect(toastMessage) {
        val msg = toastMessage
        if (!msg.isNullOrBlank()) {
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            vm.clearToast()
        }
    }

    val activeProfile: UserProfile = (profileState as? LoadState.Ready)?.data ?: UserProfile(userId = uid)

    OvozOSTheme(
        themeMode = activeProfile.themeMode,
        accentPreset = activeProfile.accentPreset,
        textScale = activeProfile.textScale,
        density = activeProfile.density
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            when (val state = profileState) {
                is LoadState.Loading -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(40.dp),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(14.dp))
                        Text(
                            text = "Yuklanmoqda...",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }

                is LoadState.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "Ma’lumotlarni yuklab bo‘lmadi",
                            style = MaterialTheme.typography.headlineSmall,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = state.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(20.dp))
                        TextButton(
                            onClick = { signOutUser(credentialManager, scope) }
                        ) {
                            Text("Hisobdan chiqish")
                        }
                    }
                }

                is LoadState.Ready -> {
                    val profile = state.data
                    if (profile == null || !profile.onboardingDone) {
                        OnboardingScreen(
                            initialName = firebaseDisplayName,
                            onFinish = { name, lang, currency, themeMode ->
                                vm.completeOnboarding(name, lang, currency, themeMode)
                            }
                        )
                    } else if (profile.pinLockEnabled && !pinUnlocked && !profile.pinHash.isNullOrBlank()) {
                        PinLockOverlay(
                            expectedHash = profile.pinHash,
                            onUnlocked = { vm.unlockPin() }
                        )
                    } else {
                        OvozAppShell(
                            vm = vm,
                            profile = profile,
                            initialRoute = initialRoute,
                            onSignOut = { signOutUser(credentialManager, scope) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun OvozAppShell(
    vm: OvozViewModel,
    profile: UserProfile,
    initialRoute: String?,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val strings = remember(profile.language) { stringsFor(profile.language) }

    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val expenses by vm.expenses.collectAsStateWithLifecycle()
    val debts by vm.debts.collectAsStateWithLifecycle()
    val people by vm.people.collectAsStateWithLifecycle()
    val actionLogs by vm.actionLogs.collectAsStateWithLifecycle()
    val dailyReviews by vm.dailyReviews.collectAsStateWithLifecycle()
    val chatMessages by vm.chatMessages.collectAsStateWithLifecycle()
    val voiceState by vm.voiceState.collectAsStateWithLifecycle()
    val undoBanner by vm.undoBanner.collectAsStateWithLifecycle()
    val searchState by vm.searchState.collectAsStateWithLifecycle()
    val assistantStreamingText by vm.assistantStreamingText.collectAsStateWithLifecycle()
    val assistantLoading by vm.assistantLoading.collectAsStateWithLifecycle()
    val assistantError by vm.assistantError.collectAsStateWithLifecycle()
    val reportState by vm.reportState.collectAsStateWithLifecycle()
    val financeInsightState by vm.financeInsightState.collectAsStateWithLifecycle()
    val eveningGenerating by vm.eveningGenerating.collectAsStateWithLifecycle()
    val geminiStatus by vm.geminiStatus.collectAsStateWithLifecycle()

    val speechController = remember(context) { SpeechController(context) }
    DisposableEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            speechController.warmUp()
        }
        onDispose { speechController.release() }
    }

    fun startSpeechCapture(localeTag: String = vm.voiceState.value.speechLocale) {
        vm.onVoiceListeningStarted()
        if (speechController.startAudioCapture(
                onRms = { vm.onVoiceRmsChanged(it) },
                onAudio = { vm.onVoiceAudioResult(it) },
                onError = { vm.onVoiceError(it) }
            )) return
        speechController.startListening(
            localeTag = localeTag,
            onReady = {},
            onRmsChanged = { rms -> vm.onVoiceRmsChanged(rms) },
            onPartialText = { partial -> vm.onVoicePartialResult(partial) },
            onFinalText = { finalText -> vm.onVoiceFinalResult(finalText) },
            onError = { err -> vm.onVoiceError(err) }
        )
    }

    val recordAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!vm.voiceState.value.isOpen) {
            vm.openVoiceModal()
        }
        if (granted) {
            startSpeechCapture()
        } else {
            vm.onVoiceError("Mikrofon ruxsati berilmadi. Matn orqali ham kiritishingiz mumkin.")
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            NotificationHelper.ensureChannel(context)
            Toast.makeText(context, "Bildirishnomalar yoqildi", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Bildirishnoma ruxsati berilmadi", Toast.LENGTH_SHORT).show()
        }
    }

    fun openVoiceAndListen() {
        vm.openVoiceModal()
        val hasAudioPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (hasAudioPermission) {
            startSpeechCapture()
        } else {
            recordAudioLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    fun requestNotificationsPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            NotificationHelper.ensureChannel(context)
            Toast.makeText(context, "Bildirishnomalar faol", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(voiceState.stage, voiceState.assistantReply) {
        if (profile.voiceSpokenReply &&
            voiceState.stage == VoiceStage.ANSWERING &&
            voiceState.assistantReply.isNotBlank()
        ) {
            speechController.speak(voiceState.assistantReply, profile.language)
        }
    }

    LaunchedEffect(undoBanner?.batchId) {
        if (undoBanner != null) {
            delay(6000L)
            vm.dismissUndoBanner()
        }
    }

    val validRoutes = remember {
        setOf(
            "home", "tasks", "finance", "finance/expenses", "finance/debts", "finance/analytics",
            "more", "people", "calendar", "evening_review", "reports",
            "search", "assistant", "history", "settings"
        )
    }

    fun normalizeRoute(raw: String): String = when (raw) {
        "debts" -> "finance/debts"
        "analytics" -> "finance/analytics"
        "finance" -> "finance/expenses"
        else -> raw
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentPattern = navBackStackEntry?.destination?.route ?: "home"
    val currentTopTab = when {
        currentPattern.startsWith("finance") -> "finance"
        currentPattern in setOf("home", "tasks", "more") -> currentPattern
        else -> ""
    }
    val showTopNav = currentTopTab.isNotEmpty()

    fun navigateTo(rawRoute: String) {
        val route = normalizeRoute(rawRoute)
        if (route !in validRoutes) return
        val isTopDest = route == "home" || route == "tasks" || route == "more" || route.startsWith("finance/")
        if (isTopDest) {
            navController.navigate(route) {
                popUpTo("home") { saveState = true }
                launchSingleTop = true
                restoreState = !route.startsWith("finance/")
            }
        } else {
            navController.navigate(route) {
                launchSingleTop = true
            }
        }
    }

    LaunchedEffect(initialRoute) {
        if (!initialRoute.isNullOrBlank()) {
            val target = normalizeRoute(initialRoute)
            if (target in validRoutes && target != "home") {
                navigateTo(target)
            }
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        val isWide = maxWidth >= 600.dp
        val bottomPad = if (isWide) 28.dp else 116.dp

        Row(modifier = Modifier.fillMaxSize()) {
            if (isWide && showTopNav && !voiceState.isOpen) {
                OvozNavigationRail(
                    currentTab = currentTopTab,
                    strings = strings,
                    onSelectTab = { tab -> navigateTo(tab) },
                    onMicClick = { openVoiceAndListen() }
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize(),
                contentAlignment = Alignment.TopCenter
            ) {
                NavHost(
                    navController = navController,
                    startDestination = "home",
                    modifier = Modifier
                        .fillMaxSize()
                        .then(if (isWide) Modifier.widthIn(max = 860.dp) else Modifier)
                        .windowInsetsPadding(WindowInsets.statusBars)
                ) {
                    composable("home") {
                        HomeScreen(
                            profile = profile,
                            strings = strings,
                            tasks = tasks,
                            expenses = expenses,
                            debts = debts,
                            bottomBarPadding = bottomPad,
                            onOpenSearch = { navigateTo("search") },
                            onNavigate = { route -> navigateTo(route) },
                            onToggleTask = { vm.toggleTaskCompleted(it) }
                        )
                    }

                    composable("tasks") {
                        TasksScreen(
                            strings = strings,
                            tasks = tasks,
                            people = people,
                            bottomBarPadding = bottomPad,
                            onAddTask = { vm.addTask(it) },
                            onUpdateTask = { before, after -> vm.updateTask(before, after) },
                            onToggleCompleted = { vm.toggleTaskCompleted(it) },
                            onDeleteTask = { vm.deleteTask(it) }
                        )
                    }

                    composable(
                        route = "finance/{tab}",
                        arguments = listOf(navArgument("tab") { type = NavType.StringType; defaultValue = "expenses" })
                    ) { entry ->
                        val tabArg = entry.arguments?.getString("tab") ?: "expenses"
                        FinanceScreen(
                            profile = profile,
                            strings = strings,
                            expenses = expenses,
                            debts = debts,
                            people = people,
                            insightState = financeInsightState,
                            initialTab = tabArg,
                            bottomBarPadding = bottomPad,
                            onToggleHideAmounts = {
                                vm.updateProfile(mapOf("hideBalances" to !profile.hideBalances))
                            },
                            onAddExpense = { vm.addExpense(it) },
                            onUpdateExpense = { before, after -> vm.updateExpense(before, after) },
                            onDeleteExpense = { vm.deleteExpense(it) },
                            onAddDebt = { vm.addDebt(it) },
                            onPayDebt = { debt, amount -> vm.payDebt(debt, amount) },
                            onDeleteDebt = { vm.deleteDebt(it) },
                            onGenerateInsight = { period, currency -> vm.generateFinanceInsight(period, currency) }
                        )
                    }

                    composable("more") {
                        MoreHubScreen(
                            strings = strings,
                            bottomBarPadding = bottomPad,
                            onNavigate = { route -> navigateTo(route) }
                        )
                    }

                    composable("people") {
                        PeopleScreen(
                            profile = profile,
                            people = people,
                            debts = debts,
                            tasks = tasks,
                            expenses = expenses,
                            onBack = { navController.popBackStack() },
                            onAddPerson = { name, phone, note -> vm.addPerson(name, phone, note) },
                            onDeletePerson = { vm.deletePerson(it) }
                        )
                    }

                    composable("calendar") {
                        CalendarScreen(
                            profile = profile,
                            tasks = tasks,
                            debts = debts,
                            people = people,
                            onBack = { navController.popBackStack() },
                            onAddTask = { vm.addTask(it) },
                            onToggleTask = { vm.toggleTaskCompleted(it) },
                            onRescheduleTomorrow = { vm.rescheduleTaskToTomorrow(it) }
                        )
                    }

                    composable("evening_review") {
                        EveningReviewScreen(
                            profile = profile,
                            tasks = tasks,
                            expenses = expenses,
                            debts = debts,
                            reviews = dailyReviews,
                            isGenerating = eveningGenerating,
                            onGenerateToday = { vm.generateTodayReview() },
                            onMoveTaskToTomorrow = { vm.rescheduleTaskToTomorrow(it) },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("reports") {
                        ReportsScreen(
                            profile = profile,
                            tasks = tasks,
                            expenses = expenses,
                            debts = debts,
                            reportState = reportState,
                            onGenerateReport = { period -> vm.generatePeriodReport(period) },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("search") {
                        SmartSearchScreen(
                            state = searchState,
                            profile = profile,
                            tasks = tasks,
                            expenses = expenses,
                            debts = debts,
                            people = people,
                            onQueryChange = { vm.updateSearchQuery(it) },
                            onFilterType = { vm.setSearchFilterType(it) },
                            onRunAiSearch = { vm.runSemanticSearch(it) },
                            onNavigateToSection = { route -> navigateTo(route) },
                            onOpenVoice = { openVoiceAndListen() },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("assistant") {
                        AssistantChatScreen(
                            profile = profile,
                            messages = chatMessages,
                            streamingText = assistantStreamingText,
                            isLoading = assistantLoading,
                            error = assistantError,
                            tasks = tasks,
                            debts = debts,
                            onSend = { text -> vm.sendAssistantQuestion(text) },
                            onSpeakText = { text -> speechController.speak(text, profile.language) },
                            onClearChat = { vm.clearAssistantChat() },
                            onOpenVoice = { openVoiceAndListen() },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("history") {
                        ActionHistoryScreen(
                            profile = profile,
                            logs = actionLogs,
                            onUndoSingle = { vm.undoSingleAction(it) },
                            onUndoBatch = { vm.undoBatchById(it) },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("settings") {
                        SettingsScreen(
                            profile = profile,
                            geminiStatus = geminiStatus,
                            onUpdateProfile = { updates, toast -> vm.updateProfile(updates, toast) },
                            onCheckGemini = { vm.checkGeminiHealth() },
                            onBuildBackupJson = { vm.buildBackupJson() },
                            onRestoreBackupJson = { vm.restoreBackupJson(it) },
                            onWipeAllData = { vm.wipeAllData() },
                            onRequestNotificationPermission = { requestNotificationsPermission() },
                            onSignOut = onSignOut,
                            onBack = { navController.popBackStack() }
                        )
                    }
                }

                // Undo Banner floating above bottom bar (or bottom edge on wide/secondary screens)
                androidx.compose.animation.AnimatedVisibility(
                    visible = undoBanner != null && !voiceState.isOpen,
                    enter = fadeIn() + slideInVertically { it / 2 },
                    exit = fadeOut() + slideOutVertically { it / 2 },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(bottom = if (!isWide && showTopNav) 96.dp else 18.dp)
                        .fillMaxWidth()
                        .then(if (isWide) Modifier.widthIn(max = 600.dp) else Modifier)
                ) {
                    undoBanner?.let { banner ->
                        OvozUndoSnackbar(
                            message = banner.message,
                            undoLabel = strings.undo,
                            onUndo = { vm.undoBannerBatch() },
                            onDismiss = { vm.dismissUndoBanner() }
                        )
                    }
                }

                // Floating Bottom Navigation Bar on phones
                androidx.compose.animation.AnimatedVisibility(
                    visible = !isWide && showTopNav && !voiceState.isOpen,
                    enter = fadeIn() + slideInVertically { it },
                    exit = fadeOut() + slideOutVertically { it },
                    modifier = Modifier.align(Alignment.BottomCenter)
                ) {
                    OvozFloatingBottomBar(
                        currentTab = currentTopTab,
                        strings = strings,
                        onSelectTab = { tab -> navigateTo(tab) },
                        onMicClick = { openVoiceAndListen() }
                    )
                }
            }
        }

        // Full-Screen Real-Time Voice Assistant Modal Overlay
        AnimatedVisibility(
            visible = voiceState.isOpen,
            enter = fadeIn() + slideInVertically { it / 6 },
            exit = fadeOut() + slideOutVertically { it / 6 },
            modifier = Modifier.fillMaxSize()
        ) {
            BackHandler(enabled = voiceState.isOpen) {
                speechController.stopListening()
                vm.closeVoiceModal()
            }
            VoiceAssistantOverlay(
                state = voiceState,
                waveformFlow = vm.voiceWaveform,
                strings = strings,
                onClose = {
                    speechController.stopListening()
                    vm.closeVoiceModal()
                },
                onStartRecording = {
                    val hasAudioPermission = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED
                    if (hasAudioPermission) {
                        startSpeechCapture(voiceState.speechLocale)
                    } else {
                        recordAudioLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                onStopRecording = {
                    if (!speechController.finishAudioCapture()) {
                        speechController.stopListening()
                        val transcript = vm.voiceState.value.transcript.trim()
                        if (transcript.isNotEmpty()) vm.analyzeTranscript(transcript)
                        else vm.onVoiceError("Ovoz aniqlanmadi. Qaytadan gapiring yoki matn kiriting.")
                    }
                },
                onLocaleChange = { loc -> vm.setSpeechLocale(loc) },
                onManualTextChange = { txt -> vm.updateManualVoiceTranscript(txt) },
                onAnalyzeText = { txt ->
                    speechController.stopListening()
                    vm.analyzeTranscript(txt)
                },
                onToggleAction = { id -> vm.toggleParsedAction(id) },
                onRemoveAction = { id -> vm.removeParsedAction(id) },
                onUpdateAction = { updated -> vm.updateParsedAction(updated) },
                onSaveAll = { vm.saveConfirmedVoiceActions() }
            )
        }
    }
}

package com.example.ai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import java.io.File
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

private const val TAG = "SpeechController"
private const val EXTRA_UNSTABLE_TEXT = "android.speech.extra.UNSTABLE_TEXT"

class SpeechController(
    private val context: Context
) {
    private val handler = Handler(Looper.getMainLooper())
    private var audioRecorder: MediaRecorder? = null
    private var audioFile: File? = null
    private var audioCallback: ((ByteArray) -> Unit)? = null
    private var audioError: ((String) -> Unit)? = null
    private var audioMeter: Runnable? = null

    fun startAudioCapture(onRms: (Float) -> Unit, onAudio: (ByteArray) -> Unit, onError: (String) -> Unit): Boolean {
        stopListening()
        return try {
            val file = File.createTempFile("ovoz-", ".m4a", context.cacheDir)
            audioFile = file
            @Suppress("DEPRECATION")
            val recorder = MediaRecorder()
            audioRecorder = recorder
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setAudioSamplingRate(16000)
            recorder.setAudioEncodingBitRate(32000)
            recorder.setAudioChannels(1)
            recorder.setOutputFile(file.absolutePath)
            recorder.setMaxDuration(60000)
            audioCallback = onAudio
            audioError = onError
            recorder.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) finishAudioCapture()
            }
            recorder.prepare()
            recorder.start()
            val meter = object : Runnable {
                override fun run() {
                    val r = audioRecorder ?: return
                    val amp = runCatching { r.maxAmplitude }.getOrDefault(0)
                    onRms((amp / 2000f).coerceIn(0f, 10f))
                    handler.postDelayed(this, 80L)
                }
            }
            audioMeter = meter
            handler.post(meter)
            true
        } catch (_: Exception) {
            cancelAudioCapture()
            false
        }
    }

    fun finishAudioCapture(): Boolean {
        val recorder = audioRecorder ?: return false
        val file = audioFile
        val callback = audioCallback
        val error = audioError
        audioRecorder = null
        audioFile = null
        audioCallback = null
        audioError = null
        audioMeter?.let { handler.removeCallbacks(it) }
        audioMeter = null
        val stopped = runCatching { recorder.stop() }.isSuccess
        runCatching { recorder.release() }
        val bytes = try { if (stopped) file?.readBytes() else null } catch (_: Exception) { null } finally { file?.delete() }
        if (bytes != null && bytes.isNotEmpty()) callback?.invoke(bytes)
        else error?.invoke("Ovoz yozilmadi. Qayta urinib ko‘ring.")
        return true
    }

    private fun cancelAudioCapture() {
        audioMeter?.let { handler.removeCallbacks(it) }
        audioMeter = null
        audioRecorder?.let { r -> runCatching { r.stop() }; runCatching { r.release() } }
        audioRecorder = null
        audioFile?.delete()
        audioFile = null
        audioCallback = null
        audioError = null
    }

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var lastPartialText: String = ""
    private var isListeningActive: Boolean = false

    fun isSpeechAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    /** Pre-creates the SpeechRecognizer service binding so tapping the mic starts immediately. */
    fun warmUp() {
        if (recognizer == null && SpeechRecognizer.isRecognitionAvailable(context)) {
            try {
                recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            } catch (e: Exception) {
                Log.w(TAG, "SpeechRecognizer warmUp skipped", e)
            }
        }
    }

    fun startListening(
        localeTag: String,
        onReady: () -> Unit,
        onRmsChanged: (Float) -> Unit,
        onPartialText: (String) -> Unit,
        onFinalText: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Qurilmada ovozni tanish xizmati mavjud emas. Matn maydoniga yozishingiz mumkin.")
            return
        }

        lastPartialText = ""

        try {
            // Reuse bound SpeechRecognizer instead of destroying/recreating every time (saves 400-800ms)
            val sr = recognizer?.also {
                if (isListeningActive) {
                    runCatching { it.cancel() }
                }
            } ?: SpeechRecognizer.createSpeechRecognizer(context).also { recognizer = it }

            isListeningActive = true
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    onReady()
                }

                override fun onBeginningOfSpeech() {}

                override fun onRmsChanged(rmsdB: Float) {
                    onRmsChanged(rmsdB)
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {}

                override fun onError(error: Int) {
                    isListeningActive = false
                    // If Android already streamed partial words and then fired timeout/no-match,
                    // finalize immediately with what we already captured!
                    if (lastPartialText.isNotBlank() &&
                        (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                    ) {
                        val recovered = lastPartialText
                        lastPartialText = ""
                        onFinalText(recovered)
                        return
                    }
                    // Recreate recognizer only on client/busy errors
                    if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) {
                        resetRecognizer()
                    }
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_AUDIO -> "Audio yozishda xatolik."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            "Ovozni tanish uchun internet aloqasi zarur."
                        SpeechRecognizer.ERROR_NO_MATCH -> "Ovoz aniqlanmadi. Qaytadan aniqroq gapiring."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Ovoz eshitilmadi. Tugmani bosib qayta urining."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mikrofon ruxsati berilmagan."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Mikrofon band. Qaytadan bosib ko‘ring."
                        else -> "Ovozni tanib bo‘lmadi. Matn orqali ham kiritishingiz mumkin."
                    }
                    onError(msg)
                }

                override fun onResults(results: Bundle?) {
                    isListeningActive = false
                    val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = list?.firstOrNull().orEmpty().trim().ifEmpty { lastPartialText }
                    lastPartialText = ""
                    if (text.isNotEmpty()) {
                        onFinalText(text)
                    } else {
                        onError("Ovoz aniqlanmadi. Qaytadan urinib ko‘ring.")
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    if (partialResults == null) return
                    val stable = partialResults
                        .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                        .trim()
                    // UNSTABLE_TEXT streams words instantaneously as the user speaks (before clause finalization!)
                    val unstable = partialResults
                        .getStringArrayList(EXTRA_UNSTABLE_TEXT)
                        ?.firstOrNull()
                        .orEmpty()
                        .trim()
                    val combined = when {
                        stable.isNotEmpty() && unstable.isNotEmpty() -> "$stable $unstable"
                        stable.isNotEmpty() -> stable
                        else -> unstable
                    }.trim()
                    if (combined.isNotEmpty() && combined != lastPartialText) {
                        lastPartialText = combined
                        onPartialText(combined)
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                // Snappier end-of-speech detection (avoid 3-4 second dead pause after speaking)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1100L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 850L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1200L)
                val targetLang = when (localeTag) {
                    "ru-RU" -> "ru-RU"
                    "en-US" -> "en-US"
                    "uz-UZ" -> "uz-UZ"
                    else -> "uz-UZ"
                }
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, targetLang)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, targetLang)
            }
            sr.startListening(intent)
        } catch (e: Exception) {
            isListeningActive = false
            resetRecognizer()
            Log.e(TAG, "Failed to start SpeechRecognizer", e)
            onError("Mikrofonni ishga tushirib bo‘lmadi: ${e.localizedMessage ?: "xatolik"}")
        }
    }

    fun stopListening() {
        cancelAudioCapture()
        isListeningActive = false
        try {
            recognizer?.stopListening()
            recognizer?.cancel()
        } catch (_: Exception) {
            resetRecognizer()
        }
    }

    private fun resetRecognizer() {
        isListeningActive = false
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (_: Exception) {
            // ignore
        } finally {
            recognizer = null
        }
    }

    fun speak(text: String, lang: String) {
        if (text.isBlank()) return
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    ttsReady = true
                    speakNow(text, lang)
                }
            }
        } else if (ttsReady) {
            speakNow(text, lang)
        }
    }

    private fun speakNow(text: String, lang: String) {
        val locale = when (lang) {
            "ru" -> Locale("ru", "RU")
            "en" -> Locale.US
            else -> Locale("uz", "UZ")
        }
        tts?.language = locale
        tts?.speak(text.take(450), TextToSpeech.QUEUE_FLUSH, null, "ovoz_reply")
    }

    fun release() {
        cancelAudioCapture()
        resetRecognizer()
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
            // ignore
        }
        tts = null
        ttsReady = false
    }
}

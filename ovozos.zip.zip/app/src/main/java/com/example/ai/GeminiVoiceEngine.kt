package com.example.ai

import android.util.Log
import com.example.core.Formatters
import com.example.data.model.DebtItem
import com.example.data.model.FinanceTransaction
import com.example.data.model.LiveEntityCue
import com.example.data.model.LiveEntityType
import com.example.data.model.ParsedAction
import com.example.data.model.ParsedActionType
import com.example.data.model.PersonItem
import com.example.data.model.TaskItem
import com.example.data.model.VoiceAnalysisResult
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private const val TAG = "GeminiVoiceEngine"

class GeminiVoiceEngine {

    // Strict schema: ONLY Tasks, Expenses, Debts, Undo, and Q&A (NO income, goals, or notes!)
    private val voiceParseSchema = Schema.obj(
        properties = mapOf(
            "transcript" to Schema.string(description = "Faithful transcript of actual audio or input text, no invented words"),
            "isQuestionOnly" to Schema.boolean(description = "True only if user asks a question without creating/updating data"),
            "clarificationQuestion" to Schema.string(description = "Ask only if critical info is genuinely ambiguous"),
            "assistantReply" to Schema.string(description = "Short grounded answer if isQuestionOnly is true"),
            "actions" to Schema.array(
                description = "Concrete actions extracted from speech",
                items = Schema.obj(
                    properties = mapOf(
                        "type" to Schema.enumeration(
                            values = listOf(
                                "CREATE_TASK",
                                "COMPLETE_TASK",
                                "CREATE_EXPENSE",
                                "CREATE_DEBT_BORROWED",
                                "CREATE_DEBT_LENT",
                                "PAY_DEBT",
                                "UNDO_LAST_ACTION",
                                "ANSWER_QUESTION"
                            )
                        ),
                        "title" to Schema.string(description = "Short clear title in Uzbek Latin"),
                        "subtitle" to Schema.string(description = "Optional brief detail"),
                        "amount" to Schema.double(description = "Numeric value if expense or debt"),
                        "currency" to Schema.enumeration(values = listOf("UZS", "USD", "EUR", "RUB")),
                        "category" to Schema.string(description = "Category name"),
                        "personName" to Schema.string(description = "Person name if mentioned"),
                        "dueDateIso" to Schema.string(description = "Local YYYY-MM-DD or YYYY-MM-DDTHH:mm"),
                        "hasDueTime" to Schema.boolean(description = "True if specific clock time mentioned"),
                        "priority" to Schema.enumeration(values = listOf("low", "medium", "high")),
                        "matchedEntityId" to Schema.string(description = "Existing record ID if updating")
                    ),
                    optionalProperties = listOf(
                        "subtitle", "amount", "currency", "category", "personName",
                        "dueDateIso", "hasDueTime", "priority", "matchedEntityId"
                    )
                )
            )
        ),
        optionalProperties = listOf("transcript", "isQuestionOnly", "clarificationQuestion", "assistantReply")
    )

    private val smartSearchSchema = Schema.obj(
        properties = mapOf(
            "taskIds" to Schema.array(items = Schema.string()),
            "transactionIds" to Schema.array(items = Schema.string()),
            "debtIds" to Schema.array(items = Schema.string()),
            "personIds" to Schema.array(items = Schema.string()),
            "summary" to Schema.string(description = "Short 1-sentence summary in Uzbek")
        ),
        optionalProperties = listOf("taskIds", "transactionIds", "debtIds", "personIds")
    )

    private val reviewSchema = Schema.obj(
        properties = mapOf(
            "summary" to Schema.string(description = "Concise personal reflection based strictly on real numbers"),
            "advice" to Schema.string(description = "Practical advice for tomorrow or next period")
        )
    )

    private val voiceParserConfig by lazy {
        generationConfig {
            responseMimeType = "application/json"
            responseSchema = voiceParseSchema
            temperature = 0.1f
            maxOutputTokens = 768
        }
    }

    private val voiceParserFastModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite",
            generationConfig = voiceParserConfig
        )
    }

    private val voiceParserFallbackModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = voiceParserConfig
        )
    }

    private val smartSearchConfig by lazy {
        generationConfig {
            responseMimeType = "application/json"
            responseSchema = smartSearchSchema
            temperature = 0.1f
            maxOutputTokens = 512
        }
    }

    private val smartSearchFastModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite",
            generationConfig = smartSearchConfig
        )
    }

    private val smartSearchFallbackModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = smartSearchConfig
        )
    }

    private val reviewConfig by lazy {
        generationConfig {
            responseMimeType = "application/json"
            responseSchema = reviewSchema
            temperature = 0.35f
            maxOutputTokens = 512
        }
    }

    private val reviewFastModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite",
            generationConfig = reviewConfig
        )
    }

    private val reviewFallbackModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = reviewConfig
        )
    }

    private val assistantChatFastModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite"
        )
    }

    private val assistantChatFallbackModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash"
        )
    }

    fun warmUp() {
        try {
            voiceParserFastModel
            voiceParserFallbackModel
        } catch (_: Exception) {
            // Safe no-op
        }
    }

    private fun isTransientDemandError(e: Throwable): Boolean {
        if (e is TimeoutCancellationException) return true
        val msg = generateSequence(e) { it.cause }
            .mapNotNull { it.message }
            .joinToString(" ")
            .lowercase(Locale.ROOT)
        return msg.contains("high demand") ||
            msg.contains("overloaded") ||
            msg.contains("unavailable") ||
            msg.contains("503") ||
            msg.contains("429") ||
            msg.contains("504") ||
            msg.contains("deadline") ||
            msg.contains("timeout") ||
            msg.contains("resource_exhausted") ||
            msg.contains("resource exhausted") ||
            msg.contains("temporarily") ||
            msg.contains("try again later")
    }

    private fun toUserFacingUzError(e: Throwable): IllegalStateException {
        return when {
            e is TimeoutCancellationException -> IllegalStateException(
                "Server javobi kechikdi. Internet tezligini tekshirib, «Qayta urinish» tugmasini bosing."
            )
            isTransientDemandError(e) -> IllegalStateException(
                "Sun’iy intellekt serveri vaqtincha band. Bir necha soniyadan so‘ng «Qayta urinish» tugmasini bosing."
            )
            e.message?.lowercase(Locale.ROOT)?.let {
                it.contains("unable to resolve host") || it.contains("network") || it.contains("failed to connect")
            } == true -> IllegalStateException(
                "Internet aloqasi topilmadi. Aloqani tekshirib, qayta urinib ko‘ring."
            )
            else -> IllegalStateException(
                e.localizedMessage ?: "Sun’iy intellekt bilan bog‘lanishda xatolik yuz berdi."
            )
        }
    }

    private suspend fun <T> runWithFastFailover(
        primary: GenerativeModel,
        fallback: GenerativeModel,
        totalTimeoutMs: Long = 45_000L,
        block: suspend (GenerativeModel) -> T
    ): T {
        val attempts: List<Triple<GenerativeModel, Long, Long>> = if (totalTimeoutMs <= 20_000L) listOf(
            Triple(primary, 11_000L, 0L),
            Triple(fallback, 8_000L, 0L)
        ) else listOf(
            Triple(primary, 13_000L, 0L),
            Triple(fallback, 16_000L, 0L),
            Triple(primary, 13_000L, 350L)
        )
        var lastError: Throwable? = null
        return withTimeout(totalTimeoutMs) {
            for ((index, attempt) in attempts.withIndex()) {
                val (model, perAttemptTimeoutMs, delayMs) = attempt
                if (delayMs > 0L) delay(delayMs)
                try {
                    return@withTimeout withTimeout(perAttemptTimeoutMs) {
                        block(model)
                    }
                } catch (e: TimeoutCancellationException) {
                    lastError = e
                    Log.w(TAG, "Gemini attempt ${index + 1}/${attempts.size} timed out after ${perAttemptTimeoutMs}ms")
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    lastError = e
                    val transient = isTransientDemandError(e)
                    Log.w(TAG, "Gemini attempt ${index + 1}/${attempts.size} failed (transient=$transient): ${e.message}")
                    if (!transient) {
                        throw toUserFacingUzError(e)
                    }
                }
            }
            throw toUserFacingUzError(lastError ?: IllegalStateException("Sun’iy intellekt javob bermadi."))
        }
    }

    private val amountRegex = Regex(
        """(\d[\d\s.,]*\s*(million|mln|ming|минг|млн|тыс|so['‘`]?m|сум|dollar|usd|\$|€|rub|руб|k)\b|\$\s*\d[\d.,]*)""",
        RegexOption.IGNORE_CASE
    )
    private val dateRegex1 = Regex(
        """\b(bugun|ertaga|indinga|kecha|kelasi\s+\w+|keyingi\s+\w+|shu\s+hafta|ikki\s+haftadan\s+keyin)\b""",
        RegexOption.IGNORE_CASE
    )
    private val dateRegex2 = Regex(
        """\b(dushanba|seshanba|chorshanba|payshanba|juma|shanba|yakshanba|завтра|сегодня|пятниц\w*|tomorrow|today|friday|monday)\b""",
        RegexOption.IGNORE_CASE
    )
    private val timeRegex = Regex(
        """(soat\s+\d{1,2}(:\d{2})?|kechqurun\s+soat\s+\d{1,2}|\d{1,2}:\d{2})""",
        RegexOption.IGNORE_CASE
    )
    private val capPersonRegex = Regex("""(?<!^)\b([A-Z][a-z'‘]{2,15})(dan|ga|ning|bilan|ni)?\b""")
    private val uzNameStemRegex = Regex(
        """\b([a-zA-Z'‘]{2,12}(?:jon|bek|xon|ali|mir|oy|gul))(dan|ga|ning|bilan|ni)?\b""",
        RegexOption.IGNORE_CASE
    )
    private val personStopWords = setOf(
        "Bugun", "Ertaga", "Juma", "Dushanba", "Seshanba", "Chorshanba", "Payshanba",
        "Shanba", "Yakshanba", "Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun",
        "Iyul", "Avgust", "Sentyabr", "Oktyabr", "Noyabr", "Dekabr", "OvozOS"
    )

    fun detectLiveEntities(text: String): List<LiveEntityCue> {
        if (text.isBlank()) return emptyList()
        val cues = mutableListOf<LiveEntityCue>()
        val lower = text.lowercase(Locale.ROOT)

        amountRegex.findAll(text).take(4).forEach { match ->
            val v = match.value.trim()
            cues.add(LiveEntityCue(type = LiveEntityType.AMOUNT, label = v, rawText = v))
        }

        listOf(dateRegex1, dateRegex2, timeRegex).forEach { regex ->
            regex.findAll(text).take(2).forEach { match ->
                val v = match.value.trim()
                if (cues.none { it.rawText.equals(v, ignoreCase = true) }) {
                    cues.add(LiveEntityCue(type = LiveEntityType.DATE_TIME, label = v, rawText = v))
                }
            }
        }

        if (lower.contains("qarz") || lower.contains("долг") || lower.contains("debt") ||
            lower.contains("qaytard") || lower.contains("olishim kerak") || lower.contains("berishim kerak")
        ) {
            cues.add(LiveEntityCue(type = LiveEntityType.DEBT, label = "Oldi-berdi", rawText = "qarz"))
        }

        if (lower.contains("kerak") || lower.contains("tugatdim") || lower.contains("bajardim") ||
            lower.contains("topshirish") || lower.contains("vazifa") || lower.contains("нужно") || lower.contains("task")
        ) {
            cues.add(LiveEntityCue(type = LiveEntityType.TASK, label = "Vazifa", rawText = "vazifa"))
        }

        uzNameStemRegex.findAll(text).take(2).forEach { match ->
            val root = match.groupValues[1].replaceFirstChar { it.uppercaseChar() }
            if (root !in personStopWords && cues.none { it.type == LiveEntityType.PERSON && it.label.equals(root, true) }) {
                cues.add(LiveEntityCue(type = LiveEntityType.PERSON, label = root, rawText = match.value))
            }
        }

        capPersonRegex.findAll(text).take(2).forEach { match ->
            val root = match.groupValues[1]
            if (root !in personStopWords && cues.none { it.type == LiveEntityType.PERSON && it.label.equals(root, true) }) {
                cues.add(LiveEntityCue(type = LiveEntityType.PERSON, label = root, rawText = match.value))
            }
        }

        return cues.take(8)
    }

    suspend fun parseVoiceCommand(
        transcript: String,
        primaryCurrency: String,
        responseLang: String,
        tasks: List<TaskItem>,
        debts: List<DebtItem>,
        people: List<PersonItem>,
        recentExpenses: List<FinanceTransaction>,
        audioBytes: ByteArray? = null
    ): VoiceAnalysisResult {
        val localTz = TimeZone.getDefault()
        val nowIso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).apply { timeZone = localTz }.format(Date())
        val dayOfWeek = SimpleDateFormat("EEEE", Locale.US).apply { timeZone = localTz }.format(Date())
        val tzId = localTz.id

        val contextBlock = buildString {
            val openTasks = tasks.filter { !it.completed }.take(12)
            if (openTasks.isNotEmpty()) {
                appendLine("Tasks: " + openTasks.joinToString("; ") { "${it.id}:${it.title}" })
            }
            val openDebts = debts.filter { !it.closed }.take(12)
            if (openDebts.isNotEmpty()) {
                appendLine("Debts: " + openDebts.joinToString("; ") { "${it.id}:${it.personName}(${it.direction},${it.remainingAmount}${it.currency})" })
            }
            if (people.isNotEmpty()) {
                appendLine("People: " + people.take(15).joinToString(", ") { it.name })
            }
            if (recentExpenses.isNotEmpty()) {
                appendLine("RecentExpenses: " + recentExpenses.take(6).joinToString("; ") { "${it.title}:${it.amount}${it.currency}" })
            }
        }

        val prompt = buildString {
            appendLine("OvozOS intent parser. LocalNow=$nowIso ($dayOfWeek, tz=$tzId). DefaultCurrency=$primaryCurrency. Lang=$responseLang (Uzbek Latin default).")
            if (contextBlock.isNotBlank()) {
                appendLine("USER DATA:")
                append(contextBlock)
            }
            if (audioBytes != null) {
                appendLine("Transcribe the attached audio faithfully into transcript, then extract actions. Uzbek Latin, Russian and English mixed speech are allowed. Audio is the source of truth.")
            } else {
                appendLine("""SPEECH: "$transcript"""")
            }
            appendLine("Vocabulary hints only: lavash, doner, somsa, osh, shashlik, taksi, metro, Uzum, Click, Payme, Humo, Uzcard. Preserve names and products as spoken. Never insert hints not actually spoken. Ask clarification when uncertain about a name, amount or intent. Treat recent expense titles and people names only as vocabulary context.")
            append(
                "Rules: Extract EVERY intent into actions[] using ONLY: CREATE_TASK, COMPLETE_TASK, CREATE_EXPENSE, CREATE_DEBT_BORROWED, CREATE_DEBT_LENT, PAY_DEBT, UNDO_LAST_ACTION, ANSWER_QUESTION. " +
                    "NEVER create goals, notes, or income. If user says a reminder/plan/to-do, create CREATE_TASK. " +
                    "Units: ming=1000, million/mln=1000000. " +
                    "Resolve relative dates (bugun/ertaga/kelasi juma/soat X) in local timezone into dueDateIso as YYYY-MM-DD (if no clock time) or YYYY-MM-DDTHH:mm (if clock time given, set hasDueTime=true). " +
                    "If no date mentioned for a task, leave dueDateIso empty. " +
                    "Match existing IDs in matchedEntityId when completing a task or paying a debt. " +
                    "If 'bekor qil'/'undo' -> UNDO_LAST_ACTION. " +
                    "If only asking a question -> isQuestionOnly=true + short grounded assistantReply + actions=[]. " +
                    "Ask clarificationQuestion ONLY if genuinely ambiguous. " +
                    "Expense categories: Oziq-ovqat, Transport, Ta'lim, Kiyim-kechak, Ko'ngilochar, Obunalar, Sog'liq, Xaridlar, Uy-joy, Aloqa, Boshqa. " +
                    "Task categories: Shaxsiy, Ish, O'qish, Moliya, Sog'liq, Uchrashuv, Xarid. " +
                    "Use clean Uzbek Latin titles."
            )
        }

        return try {
            val response = runWithFastFailover(
                primary = voiceParserFastModel,
                fallback = voiceParserFallbackModel,
                totalTimeoutMs = 20_000L
            ) { model ->
                if (audioBytes != null) model.generateContent(content {
                    inlineData(audioBytes, "audio/mp4")
                    text(prompt)
                }) else model.generateContent(prompt)
            }
            val raw = response.text ?: throw IllegalStateException("Sun’iy intellekt bo‘sh javob qaytardi.")
            val json = JSONObject(raw)
            val isQuestionOnly = json.optBoolean("isQuestionOnly", false)
            val clarification = json.optString("clarificationQuestion", "").trim()
            val reply = json.optString("assistantReply", "").trim()
            val arr = json.optJSONArray("actions")
            val parsed = mutableListOf<ParsedAction>()
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val typeName = o.optString("type", "")
                    val actionType = ParsedActionType.entries.firstOrNull { it.name == typeName }
                        ?: continue
                    // Guard against any unsupported legacy types
                    if (actionType in listOf(
                            ParsedActionType.CREATE_INCOME,
                            ParsedActionType.CREATE_GOAL,
                            ParsedActionType.UPDATE_GOAL_PROGRESS,
                            ParsedActionType.CREATE_NOTE
                        )
                    ) {
                        continue
                    }
                    val iso = o.optString("dueDateIso", "").trim()
                    val hasTime = o.optBoolean("hasDueTime", iso.contains("T") || iso.contains(":"))
                    val parsedMillis = parseIsoToMillis(iso)
                    parsed.add(
                        ParsedAction(
                            type = actionType,
                            title = o.optString("title", "").ifBlank { "Yangi vazifa" },
                            subtitle = o.optString("subtitle", ""),
                            amount = o.optDouble("amount", 0.0).let { if (it.isNaN()) 0.0 else it },
                            currency = o.optString("currency", primaryCurrency).ifBlank { primaryCurrency },
                            category = o.optString("category", "").ifBlank {
                                if (actionType == ParsedActionType.CREATE_EXPENSE) "Boshqa" else "Shaxsiy"
                            },
                            personName = o.optString("personName", "").trim(),
                            dueDateIso = iso,
                            dueDateMillis = parsedMillis,
                            hasDueTime = hasTime && parsedMillis > 0L,
                            priority = o.optString("priority", "medium").ifBlank { "medium" },
                            matchedEntityId = o.optString("matchedEntityId", "").trim()
                        )
                    )
                }
            }
            VoiceAnalysisResult(
                actions = parsed,
                clarificationQuestion = clarification,
                assistantReply = reply,
                recognizedEntities = detectLiveEntities(json.optString("transcript", transcript)),
                isQuestionOnly = isQuestionOnly,
                transcript = json.optString("transcript", transcript).trim()
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Voice analysis timed out", e)
            throw IllegalStateException("Tahlil vaqti tugadi. Internet aloqasini tekshirib, qayta urinib ko‘ring.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Voice analysis failed", e)
            throw e
        }
    }

    fun askAssistantStream(
        question: String,
        responseLang: String,
        responseLength: String,
        primaryCurrency: String,
        tasks: List<TaskItem>,
        expenses: List<FinanceTransaction>,
        debts: List<DebtItem>,
        people: List<PersonItem>
    ): Flow<String> = flow {
        val localTz = TimeZone.getDefault()
        val nowIso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).apply { timeZone = localTz }.format(Date())
        val lengthRule = when (responseLength) {
            "short" -> "Juda qisqa (2-3 gap) javob ber."
            "detailed" -> "Batafsil, aniq raqamlar va tavsiyalar bilan javob ber."
            else -> "Qisqa, aniq va tushunarli javob ber."
        }
        val langRule = when (responseLang) {
            "ru" -> "Отвечай на естественном русском языке."
            "en" -> "Reply in natural English."
            else -> "Tabiiy o‘zbek tilida (lotin yozuvida) javob ber."
        }

        val dataSnapshot = buildString {
            appendLine("Vaqt: $nowIso, valyuta: $primaryCurrency")
            if (tasks.isNotEmpty()) {
                appendLine("VAZIFALAR:")
                tasks.take(30).forEach {
                    val due = if (it.dueDateMillis > 0) Formatters.formatDateTime24(it.dueDateMillis) else "-"
                    appendLine("- ${it.title}|done=${it.completed}|muddat=$due|${it.category}|${it.personName}")
                }
            }
            if (expenses.isNotEmpty()) {
                appendLine("XARAJATLAR:")
                expenses.take(35).forEach {
                    appendLine("- ${Formatters.formatShortDate(it.occurredAtMillis)}|${it.amount}${it.currency}|${it.category}|${it.title}")
                }
            }
            if (debts.isNotEmpty()) {
                appendLine("QARZLAR:")
                debts.take(25).forEach {
                    val dir = if (it.direction == "lent") "menga qaytarishlari kerak" else "men qaytarishim kerak"
                    appendLine("- ${it.personName}|$dir|qoldiq=${it.remainingAmount}${it.currency}|closed=${it.closed}")
                }
            }
            if (people.isNotEmpty()) {
                appendLine("INSONLAR: " + people.take(20).joinToString(", ") { it.name })
            }
        }

        val prompt = """
            Sen OvozOS shaxsiy yordamchisisiz. Faqat berilgan haqiqiy ma’lumotlarga (vazifalar, xarajatlar, qarzlar, insonlar) tayan.
            OvozOS bank ilovasi emas: foydalanuvchining umumiy balansi yoki daromadini taxmin qilma.
            $langRule $lengthRule

            MA’LUMOTLAR:
            $dataSnapshot

            SAVOL: $question
        """.trimIndent()

        val sb = StringBuilder()
        withTimeout(45_000L) {
            try {
                assistantChatFastModel.generateContentStream(prompt).collect { chunk ->
                    val piece = chunk.text.orEmpty()
                    if (piece.isNotEmpty()) {
                        sb.append(piece)
                        emit(sb.toString())
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (sb.isEmpty() && isTransientDemandError(e)) {
                    Log.w(TAG, "Assistant stream fast model busy, switching to gemini-3.8-flash", e)
                    try {
                        assistantChatFallbackModel.generateContentStream(prompt).collect { chunk ->
                            val piece = chunk.text.orEmpty()
                            if (piece.isNotEmpty()) {
                                sb.append(piece)
                                emit(sb.toString())
                            }
                        }
                    } catch (fallbackEx: CancellationException) {
                        throw fallbackEx
                    } catch (fallbackEx: Exception) {
                        throw toUserFacingUzError(fallbackEx)
                    }
                } else {
                    throw toUserFacingUzError(e)
                }
            }
        }
    }

    suspend fun semanticSearch(
        query: String,
        tasks: List<TaskItem>,
        expenses: List<FinanceTransaction>,
        debts: List<DebtItem>,
        people: List<PersonItem>
    ): SemanticSearchResult {
        val nowIso = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getDefault() }.format(Date())
        val corpus = buildString {
            appendLine("Today: $nowIso")
            if (tasks.isNotEmpty()) {
                appendLine("TASKS:")
                tasks.take(35).forEach { appendLine("${it.id}: ${it.title} | ${it.category} | ${it.personName}") }
            }
            if (expenses.isNotEmpty()) {
                appendLine("EXPENSES:")
                expenses.take(40).forEach {
                    appendLine("${it.id}: ${Formatters.formatShortDate(it.occurredAtMillis)} ${it.amount}${it.currency} ${it.category} ${it.title}")
                }
            }
            if (debts.isNotEmpty()) {
                appendLine("DEBTS:")
                debts.take(25).forEach { appendLine("${it.id}: ${it.personName} ${it.direction} ${it.remainingAmount}${it.currency}") }
            }
            if (people.isNotEmpty()) {
                appendLine("PEOPLE:")
                people.take(25).forEach { appendLine("${it.id}: ${it.name}") }
            }
        }

        val prompt = """Find matching IDs for "$query" in OvozOS data (tasks, expenses, debts, people). Return only matching IDs + 1-sentence Uzbek summary.\n$corpus"""

        val response = runWithFastFailover(
            primary = smartSearchFastModel,
            fallback = smartSearchFallbackModel,
            totalTimeoutMs = 40_000L
        ) { model ->
            model.generateContent(prompt)
        }
        val json = JSONObject(response.text ?: "{}")
        fun arr(key: String): Set<String> {
            val a = json.optJSONArray(key) ?: return emptySet()
            return (0 until a.length()).map { a.getString(it) }.toSet()
        }
        return SemanticSearchResult(
            taskIds = arr("taskIds"),
            transactionIds = arr("transactionIds"),
            debtIds = arr("debtIds"),
            personIds = arr("personIds"),
            summary = json.optString("summary", "")
        )
    }

    suspend fun generateDailyOrPeriodInsight(
        periodTitle: String,
        statsSummary: String,
        lang: String
    ): Pair<String, String> {
        val langRule = when (lang) {
            "ru" -> "На русском языке"
            "en" -> "In English"
            else -> "Tabiiy o‘zbek tilida (lotin yozuvida)"
        }
        val prompt = "$langRule. \"$periodTitle\" uchun faqat berilgan raqamlarga (vazifalar, xarajatlar, qarzlar) tayanib qisqa summary va amaliy advice yoz. Balans yoki daromad haqida gapirma:\n$statsSummary"

        val response = runWithFastFailover(
            primary = reviewFastModel,
            fallback = reviewFallbackModel,
            totalTimeoutMs = 40_000L
        ) { model ->
            model.generateContent(prompt)
        }
        val json = JSONObject(response.text ?: "{}")
        return Pair(
            json.optString("summary", ""),
            json.optString("advice", "")
        )
    }

    suspend fun checkGeminiConnection(): Result<String> {
        return try {
            val response = runWithFastFailover(
                primary = assistantChatFastModel,
                fallback = assistantChatFallbackModel,
                totalTimeoutMs = 25_000L
            ) { model ->
                model.generateContent("Faqat 'Ulanish faol' deb 2 so‘zda javob ber.")
            }
            val text = response.text?.trim().orEmpty()
            if (text.isNotEmpty()) Result.success(text)
            else Result.failure(IllegalStateException("Bo‘sh javob"))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini health check failed", e)
            Result.failure(e)
        }
    }

    /**
     * Parses ISO-8601 date/datetime strings reliably in the device's local timezone.
     * Supports YYYY-MM-DD, YYYY-MM-DDTHH:mm, YYYY-MM-DD HH:mm, YYYY-MM-DDTHH:mm:ss, and timezone offsets.
     */
    private fun parseIsoToMillis(rawIso: String): Long {
        val clean = rawIso.trim()
        if (clean.isEmpty()) return 0L
        val localTz = TimeZone.getDefault()

        // Strip trailing timezone offset / Z if model emitted local clock time with Z, or parse cleanly
        val normalized = clean
            .replace(Regex("""\.\d+"""), "") // strip fractional seconds
            .replace(" ", "T")

        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mmXXX",
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd'T'HH:mm'Z'",
            "yyyy-MM-dd'T'HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm",
            "yyyy-MM-dd"
        )
        for (p in patterns) {
            try {
                val fmt = SimpleDateFormat(p, Locale.US).apply {
                    isLenient = false
                    timeZone = if (p.endsWith("'Z'")) TimeZone.getTimeZone("UTC") else localTz
                }
                val date = fmt.parse(normalized)
                if (date != null) {
                    if (p == "yyyy-MM-dd") {
                        val cal = Calendar.getInstance(localTz).apply {
                            time = date
                            set(Calendar.HOUR_OF_DAY, 12)
                            set(Calendar.MINUTE, 0)
                            set(Calendar.SECOND, 0)
                            set(Calendar.MILLISECOND, 0)
                        }
                        return cal.timeInMillis
                    }
                    return date.time
                }
            } catch (_: Exception) {
                // try next pattern
            }
        }
        return 0L
    }
}

data class SemanticSearchResult(
    val taskIds: Set<String> = emptySet(),
    val transactionIds: Set<String> = emptySet(),
    val debtIds: Set<String> = emptySet(),
    val personIds: Set<String> = emptySet(),
    val summary: String = ""
)

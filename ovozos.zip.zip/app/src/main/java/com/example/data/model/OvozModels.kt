package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

val DefaultDashboardCards = listOf(
    "ai_summary",
    "today_tasks",
    "finance_balance",
    "today_cashflow",
    "key_goals",
    "due_debts",
    "upcoming_deadlines",
    "recent_actions",
    "evening_review"
)

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val onboardingDone: Boolean = false,
    val language: String = "uz",
    val aiResponseLang: String = "auto",
    val primaryCurrency: String = "UZS",
    val themeMode: String = "system",
    val textScale: String = "standard",
    val accentPreset: String = "emerald",
    val density: String = "comfortable",
    val dateFormat: String = "dd.MM.yyyy",
    val hideBalances: Boolean = false,
    val initialBalanceUzs: Double = 0.0,
    val initialBalanceUsd: Double = 0.0,
    val initialBalanceEur: Double = 0.0,
    val initialBalanceRub: Double = 0.0,
    val dashboardOrder: List<String> = DefaultDashboardCards,
    val hiddenCards: List<String> = emptyList(),
    val notifyAll: Boolean = true,
    val notifyTasks: Boolean = true,
    val notifyDebts: Boolean = true,
    val notifyGoals: Boolean = true,
    val notifyEvening: Boolean = true,
    val eveningReviewHour: Long = 21L,
    val eveningReviewMinute: Long = 0L,
    val notifyReports: Boolean = true,
    val notifySound: Boolean = true,
    val voiceSpokenReply: Boolean = false,
    val aiResponseLength: String = "standard",
    val autoSaveVoice: Boolean = false,
    val keepVoiceTranscripts: Boolean = true,
    val pinLockEnabled: Boolean = false,
    val pinHash: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun initialBalanceFor(currency: String): Double = when (currency) {
        "USD" -> initialBalanceUsd
        "EUR" -> initialBalanceEur
        "RUB" -> initialBalanceRub
        else -> initialBalanceUzs
    }

    fun toCreateMap(uid: String): Map<String, Any> {
        val raw = mutableMapOf<String, Any?>(
            "userId" to uid,
            "displayName" to displayName.trim().ifEmpty { "Foydalanuvchi" }.take(60),
            "onboardingDone" to onboardingDone,
            "language" to language,
            "aiResponseLang" to aiResponseLang,
            "primaryCurrency" to primaryCurrency,
            "themeMode" to themeMode,
            "textScale" to textScale,
            "accentPreset" to accentPreset,
            "density" to density,
            "dateFormat" to dateFormat,
            "hideBalances" to hideBalances,
            "initialBalanceUzs" to initialBalanceUzs,
            "initialBalanceUsd" to initialBalanceUsd,
            "initialBalanceEur" to initialBalanceEur,
            "initialBalanceRub" to initialBalanceRub,
            "dashboardOrder" to dashboardOrder.take(12),
            "hiddenCards" to hiddenCards.take(12),
            "notifyAll" to notifyAll,
            "notifyTasks" to notifyTasks,
            "notifyDebts" to notifyDebts,
            "notifyGoals" to notifyGoals,
            "notifyEvening" to notifyEvening,
            "eveningReviewHour" to eveningReviewHour.coerceIn(0L, 23L),
            "eveningReviewMinute" to eveningReviewMinute.coerceIn(0L, 59L),
            "notifyReports" to notifyReports,
            "notifySound" to notifySound,
            "voiceSpokenReply" to voiceSpokenReply,
            "aiResponseLength" to aiResponseLength,
            "autoSaveVoice" to autoSaveVoice,
            "keepVoiceTranscripts" to keepVoiceTranscripts,
            "pinLockEnabled" to pinLockEnabled,
            "pinHash" to pinHash,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        @Suppress("UNCHECKED_CAST")
        return raw.filterValues { it != null } as Map<String, Any>
    }
}

@Keep
@IgnoreExtraProperties
data class TaskItem(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    val dueDateMillis: Long = 0L,
    val hasDueTime: Boolean = false,
    val priority: String = "medium", // low, medium, high
    val category: String = "Shaxsiy",
    val recurrence: String = "none", // none, daily, weekly, monthly
    val completed: Boolean = false,
    val completedAtMillis: Long = 0L,
    val personId: String = "",
    val personName: String = "",
    val goalId: String = "",
    val noteText: String = "",
    val reminderEnabled: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "title" to title.trim().ifEmpty { "Vazifa" }.take(200),
        "description" to description.take(1000),
        "dueDateMillis" to dueDateMillis.coerceAtLeast(0L),
        "hasDueTime" to hasDueTime,
        "priority" to if (priority in listOf("low", "medium", "high")) priority else "medium",
        "category" to category.trim().ifEmpty { "Shaxsiy" }.take(40),
        "recurrence" to if (recurrence in listOf("none", "daily", "weekly", "monthly")) recurrence else "none",
        "completed" to completed,
        "completedAtMillis" to completedAtMillis.coerceAtLeast(0L),
        "personId" to personId.take(128),
        "personName" to personName.take(80),
        "goalId" to goalId.take(128),
        "noteText" to noteText.take(1000),
        "reminderEnabled" to reminderEnabled,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )

    fun toSnapshotMap(): Map<String, Any> = mapOf(
        "title" to title,
        "description" to description,
        "dueDateMillis" to dueDateMillis,
        "hasDueTime" to hasDueTime,
        "priority" to priority,
        "category" to category,
        "recurrence" to recurrence,
        "completed" to completed,
        "completedAtMillis" to completedAtMillis,
        "personId" to personId,
        "personName" to personName,
        "goalId" to goalId,
        "noteText" to noteText,
        "reminderEnabled" to reminderEnabled
    )
}

@Keep
@IgnoreExtraProperties
data class NoteItem(
    @DocumentId val id: String = "",
    val title: String = "",
    val content: String = "",
    val category: String = "Fikr",
    val colorTag: String = "emerald",
    val pinned: Boolean = false,
    val archived: Boolean = false,
    val sourceVoice: Boolean = false,
    val linkedPersonId: String = "",
    val linkedPersonName: String = "",
    val linkedTaskId: String = "",
    val linkedGoalId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "title" to title.trim().ifEmpty { "Eslatma" }.take(150),
        "content" to content.take(5000),
        "category" to category.trim().ifEmpty { "Fikr" }.take(40),
        "colorTag" to colorTag.trim().ifEmpty { "emerald" }.take(20),
        "pinned" to pinned,
        "archived" to archived,
        "sourceVoice" to sourceVoice,
        "linkedPersonId" to linkedPersonId.take(128),
        "linkedPersonName" to linkedPersonName.take(80),
        "linkedTaskId" to linkedTaskId.take(128),
        "linkedGoalId" to linkedGoalId.take(128),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )

    fun toSnapshotMap(): Map<String, Any> = mapOf(
        "title" to title,
        "content" to content,
        "category" to category,
        "colorTag" to colorTag,
        "pinned" to pinned,
        "archived" to archived,
        "sourceVoice" to sourceVoice,
        "linkedPersonId" to linkedPersonId,
        "linkedPersonName" to linkedPersonName,
        "linkedTaskId" to linkedTaskId,
        "linkedGoalId" to linkedGoalId
    )
}

@Keep
@IgnoreExtraProperties
data class FinanceTransaction(
    @DocumentId val id: String = "",
    val kind: String = "expense", // income, expense, goal_saving, debt_payment
    val amount: Double = 0.0,
    val currency: String = "UZS",
    val category: String = "Boshqa",
    val title: String = "",
    val note: String = "",
    val occurredAtMillis: Long = System.currentTimeMillis(),
    val personId: String = "",
    val personName: String = "",
    val goalId: String = "",
    val debtId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "kind" to if (kind in listOf("income", "expense", "goal_saving", "debt_payment")) kind else "expense",
        "amount" to amount.coerceAtLeast(0.01),
        "currency" to if (currency in listOf("UZS", "USD", "EUR", "RUB")) currency else "UZS",
        "category" to category.trim().ifEmpty { "Boshqa" }.take(50),
        "title" to title.trim().ifEmpty { category }.take(150),
        "note" to note.take(500),
        "occurredAtMillis" to occurredAtMillis.coerceAtLeast(1L),
        "personId" to personId.take(128),
        "personName" to personName.take(80),
        "goalId" to goalId.take(128),
        "debtId" to debtId.take(128),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )

    fun toSnapshotMap(): Map<String, Any> = mapOf(
        "kind" to kind,
        "amount" to amount,
        "currency" to currency,
        "category" to category,
        "title" to title,
        "note" to note,
        "occurredAtMillis" to occurredAtMillis,
        "personId" to personId,
        "personName" to personName,
        "goalId" to goalId,
        "debtId" to debtId
    )
}

@Keep
@IgnoreExtraProperties
data class DebtItem(
    @DocumentId val id: String = "",
    val direction: String = "borrowed", // borrowed (men olgan), lent (men bergan)
    val personId: String = "",
    val personName: String = "",
    val originalAmount: Double = 0.0,
    val paidAmount: Double = 0.0,
    val currency: String = "UZS",
    val note: String = "",
    val issuedAtMillis: Long = System.currentTimeMillis(),
    val dueDateMillis: Long = 0L,
    val closed: Boolean = false,
    val closedAtMillis: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val remainingAmount: Double
        get() = (originalAmount - paidAmount).coerceAtLeast(0.0)

    fun toCreateMap(): Map<String, Any> {
        val safeOriginal = originalAmount.coerceAtLeast(0.01)
        val safePaid = paidAmount.coerceIn(0.0, safeOriginal)
        return mapOf(
            "direction" to if (direction == "lent") "lent" else "borrowed",
            "personId" to personId.take(128),
            "personName" to personName.trim().ifEmpty { "Noma’lum" }.take(80),
            "originalAmount" to safeOriginal,
            "paidAmount" to safePaid,
            "currency" to if (currency in listOf("UZS", "USD", "EUR", "RUB")) currency else "UZS",
            "note" to note.take(500),
            "issuedAtMillis" to issuedAtMillis.coerceAtLeast(1L),
            "dueDateMillis" to dueDateMillis.coerceAtLeast(0L),
            "closed" to (closed || safePaid >= safeOriginal),
            "closedAtMillis" to closedAtMillis.coerceAtLeast(0L),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
    }

    fun toSnapshotMap(): Map<String, Any> = mapOf(
        "direction" to direction,
        "personId" to personId,
        "personName" to personName,
        "originalAmount" to originalAmount,
        "paidAmount" to paidAmount,
        "currency" to currency,
        "note" to note,
        "issuedAtMillis" to issuedAtMillis,
        "dueDateMillis" to dueDateMillis,
        "closed" to closed,
        "closedAtMillis" to closedAtMillis
    )
}

@Keep
@IgnoreExtraProperties
data class PersonItem(
    @DocumentId val id: String = "",
    val name: String = "",
    val phone: String = "",
    val note: String = "",
    val avatarColor: String = "emerald",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "name" to name.trim().ifEmpty { "Inson" }.take(80),
        "phone" to phone.take(30),
        "note" to note.take(500),
        "avatarColor" to avatarColor.trim().ifEmpty { "emerald" }.take(20),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )

    fun toSnapshotMap(): Map<String, Any> = mapOf(
        "name" to name,
        "phone" to phone,
        "note" to note,
        "avatarColor" to avatarColor
    )
}

@Keep
@IgnoreExtraProperties
data class GoalItem(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    val goalType: String = "financial", // financial, education, personal, health, other
    val targetValue: Double = 1.0,
    val currentValue: Double = 0.0,
    val unit: String = "UZS",
    val currency: String = "UZS",
    val startDateMillis: Long = System.currentTimeMillis(),
    val deadlineMillis: Long = 0L,
    val completed: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val progressFraction: Float
        get() = if (targetValue <= 0.0) 0f else (currentValue / targetValue).toFloat().coerceIn(0f, 1f)

    val progressPercent: Int
        get() = (progressFraction * 100f).toInt().coerceIn(0, 100)

    fun toCreateMap(): Map<String, Any> {
        val safeTarget = targetValue.coerceAtLeast(0.01)
        val safeCurrent = currentValue.coerceAtLeast(0.0)
        return mapOf(
            "title" to title.trim().ifEmpty { "Maqsad" }.take(150),
            "description" to description.take(1000),
            "goalType" to if (goalType in listOf("financial", "education", "personal", "health", "other")) goalType else "personal",
            "targetValue" to safeTarget,
            "currentValue" to safeCurrent,
            "unit" to unit.trim().ifEmpty { "ta" }.take(20),
            "currency" to currency.take(10),
            "startDateMillis" to startDateMillis.coerceAtLeast(1L),
            "deadlineMillis" to deadlineMillis.coerceAtLeast(0L),
            "completed" to (completed || safeCurrent >= safeTarget),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
    }

    fun toSnapshotMap(): Map<String, Any> = mapOf(
        "title" to title,
        "description" to description,
        "goalType" to goalType,
        "targetValue" to targetValue,
        "currentValue" to currentValue,
        "unit" to unit,
        "currency" to currency,
        "startDateMillis" to startDateMillis,
        "deadlineMillis" to deadlineMillis,
        "completed" to completed
    )
}

@Keep
@IgnoreExtraProperties
data class ActionLogItem(
    @DocumentId val id: String = "",
    val batchId: String = "",
    val actionType: String = "create", // create, update, delete
    val entityCollection: String = "tasks",
    val entityId: String = "",
    val summaryText: String = "",
    val beforeSummary: String = "",
    val afterSummary: String = "",
    val beforeData: Map<String, Any> = emptyMap(),
    val afterData: Map<String, Any> = emptyMap(),
    val sourceVoice: Boolean = false,
    val reverted: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "batchId" to batchId.trim().ifEmpty { "manual" }.take(80),
        "actionType" to if (actionType in listOf("create", "update", "delete")) actionType else "create",
        "entityCollection" to if (entityCollection in listOf("tasks", "notes", "transactions", "debts", "people", "goals")) entityCollection else "tasks",
        "entityId" to entityId.trim().ifEmpty { "unknown" }.take(128),
        "summaryText" to summaryText.trim().ifEmpty { "Amal" }.take(300),
        "beforeSummary" to beforeSummary.take(300),
        "afterSummary" to afterSummary.take(300),
        "beforeData" to beforeData,
        "afterData" to afterData,
        "sourceVoice" to sourceVoice,
        "reverted" to reverted,
        "createdAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class DailyReviewItem(
    @DocumentId val id: String = "",
    val dateKey: String = "",
    val completedTasksCount: Long = 0L,
    val pendingTasksCount: Long = 0L,
    val completionPercent: Long = 0L,
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val currency: String = "UZS",
    val topExpenseCategory: String = "",
    val aiSummary: String = "",
    val tomorrowAdvice: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "dateKey" to dateKey.take(16),
        "completedTasksCount" to completedTasksCount.coerceAtLeast(0L),
        "pendingTasksCount" to pendingTasksCount.coerceAtLeast(0L),
        "completionPercent" to completionPercent.coerceIn(0L, 100L),
        "totalIncome" to totalIncome.coerceAtLeast(0.0),
        "totalExpense" to totalExpense.coerceAtLeast(0.0),
        "currency" to if (currency in listOf("UZS", "USD", "EUR", "RUB")) currency else "UZS",
        "topExpenseCategory" to topExpenseCategory.take(60),
        "aiSummary" to aiSummary.take(2000),
        "tomorrowAdvice" to tomorrowAdvice.take(2000),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class AssistantMessage(
    @DocumentId val id: String = "",
    val role: String = "user", // user, assistant
    val text: String = "",
    val voiceInput: Boolean = false,
    val attachmentType: String = "none", // none, tasks, finance_summary, debts, goals
    @ServerTimestamp val createdAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "role" to if (role == "assistant") "assistant" else "user",
        "text" to text.trim().ifEmpty { "..." }.take(5000),
        "voiceInput" to voiceInput,
        "attachmentType" to if (attachmentType in listOf("none", "tasks", "finance_summary", "debts", "goals")) attachmentType else "none",
        "createdAt" to FieldValue.serverTimestamp()
    )
}

package com.example.data.model

import java.util.UUID

enum class VoiceStage {
    IDLE,
    LISTENING,
    TRANSCRIBING,
    ANALYZING,
    REVIEW,
    CLARIFYING,
    ANSWERING,
    ERROR
}

enum class LiveEntityType {
    AMOUNT,
    DATE_TIME,
    PERSON,
    TASK,
    GOAL,
    DEBT
}

data class LiveEntityCue(
    val id: String = UUID.randomUUID().toString(),
    val type: LiveEntityType,
    val label: String,
    val rawText: String
)

enum class ParsedActionType {
    CREATE_TASK,
    COMPLETE_TASK,
    CREATE_EXPENSE,
    CREATE_INCOME,
    CREATE_DEBT_BORROWED,
    CREATE_DEBT_LENT,
    PAY_DEBT,
    CREATE_GOAL,
    UPDATE_GOAL_PROGRESS,
    CREATE_NOTE,
    UNDO_LAST_ACTION,
    ANSWER_QUESTION
}

data class ParsedAction(
    val localId: String = UUID.randomUUID().toString(),
    val type: ParsedActionType,
    val title: String,
    val subtitle: String = "",
    val amount: Double = 0.0,
    val currency: String = "UZS",
    val category: String = "",
    val personName: String = "",
    val dueDateIso: String = "", // YYYY-MM-DD or YYYY-MM-DDTHH:mm
    val dueDateMillis: Long = 0L,
    val hasDueTime: Boolean = false,
    val priority: String = "medium",
    val goalType: String = "financial",
    val goalUnit: String = "UZS",
    val matchedEntityId: String = "",
    val noteContent: String = "",
    val selected: Boolean = true
)

data class VoiceAnalysisResult(
    val actions: List<ParsedAction> = emptyList(),
    val clarificationQuestion: String = "",
    val assistantReply: String = "",
    val recognizedEntities: List<LiveEntityCue> = emptyList(),
    val isQuestionOnly: Boolean = false,
    val transcript: String = ""
)

data class VoiceUiState(
    val isOpen: Boolean = false,
    val stage: VoiceStage = VoiceStage.IDLE,
    val speechLocale: String = "auto", // auto, uz-UZ, ru-RU, en-US
    val transcript: String = "",
    val partialTranscript: String = "",
    val elapsedSeconds: Int = 0,
    val rmsDb: Float = 0f,
    val waveformHistory: List<Float> = List(28) { 0.12f },
    val liveEntityCues: List<LiveEntityCue> = emptyList(),
    val parsedActions: List<ParsedAction> = emptyList(),
    val clarificationQuestion: String = "",
    val assistantReply: String = "",
    val errorMessage: String = "",
    val isSaving: Boolean = false
)

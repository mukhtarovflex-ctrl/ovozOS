package com.example.data.repo

import com.example.core.OperationType
import com.example.core.handleFirestoreError
import com.example.data.model.ActionLogItem
import com.example.data.model.AssistantMessage
import com.example.data.model.DailyReviewItem
import com.example.data.model.DebtItem
import com.example.data.model.DefaultDashboardCards
import com.example.data.model.FinanceTransaction
import com.example.data.model.GoalItem
import com.example.data.model.NoteItem
import com.example.data.model.PersonItem
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class OvozRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private fun requireUserId(expectedUid: String): String {
        val current = auth.currentUser?.uid
            ?: throw IllegalStateException("Foydalanuvchi tizimga kirmagan.")
        check(current == expectedUid) { "Hisob o‘zgardi; yozish rad etildi." }
        return current
    }

    private fun userDoc(uid: String) = db.collection("users").document(uid)

    private inline fun <reified T> observeSubcollection(
        uid: String,
        subcollection: String
    ): Flow<List<T>> = flow {
        val path = "users/$uid/$subcollection"
        emitAll(
            userDoc(uid).collection(subcollection)
                .snapshots()
                .map { snap ->
                    snap.toObjects(T::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsError == null && error is CancellationException) throw error
                    val toLog = fsError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeProfile(uid: String): Flow<UserProfile?> = flow {
        val path = "users/$uid"
        emitAll(
            userDoc(uid).snapshots()
                .map { snap ->
                    if (snap.exists()) {
                        snap.toObject(
                            UserProfile::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else null
                }
                .catch { error ->
                    val fsError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsError == null && error is CancellationException) throw error
                    val toLog = fsError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    fun observeTasks(uid: String): Flow<List<TaskItem>> = observeSubcollection(uid, "tasks")
    fun observeNotes(uid: String): Flow<List<NoteItem>> = observeSubcollection(uid, "notes")
    fun observeTransactions(uid: String): Flow<List<FinanceTransaction>> = observeSubcollection(uid, "transactions")
    fun observeDebts(uid: String): Flow<List<DebtItem>> = observeSubcollection(uid, "debts")
    fun observePeople(uid: String): Flow<List<PersonItem>> = observeSubcollection(uid, "people")
    fun observeGoals(uid: String): Flow<List<GoalItem>> = observeSubcollection(uid, "goals")
    fun observeActionLogs(uid: String): Flow<List<ActionLogItem>> = observeSubcollection(uid, "action_logs")
    fun observeDailyReviews(uid: String): Flow<List<DailyReviewItem>> = observeSubcollection(uid, "daily_reviews")
    fun observeChatMessages(uid: String): Flow<List<AssistantMessage>> = observeSubcollection(uid, "chat_messages")

    // --- Profile & Settings ---
    suspend fun createOrCompleteProfile(uid: String, profile: UserProfile): Result<Unit> {
        val path = "users/$uid"
        return try {
            requireUserId(uid)
            val docRef = userDoc(uid)
            val existing = docRef.get().await()
            if (!existing.exists()) {
                docRef.set(profile.copy(userId = uid).toCreateMap(uid)).await()
            } else {
                val updates = mutableMapOf<String, Any>(
                    "displayName" to profile.displayName.trim().ifEmpty { "Foydalanuvchi" }.take(60),
                    "onboardingDone" to profile.onboardingDone,
                    "language" to profile.language,
                    "primaryCurrency" to profile.primaryCurrency,
                    "themeMode" to profile.themeMode,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun updateProfileFields(uid: String, updates: Map<String, Any>): Result<Unit> {
        val path = "users/$uid"
        return try {
            requireUserId(uid)
            val payload = updates.toMutableMap()
            payload["updatedAt"] = FieldValue.serverTimestamp()
            userDoc(uid).update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- Action Log helper ---
    private suspend fun recordActionLog(
        uid: String,
        batchId: String,
        actionType: String,
        entityCollection: String,
        entityId: String,
        summaryText: String,
        beforeSummary: String,
        afterSummary: String,
        beforeData: Map<String, Any>,
        afterData: Map<String, Any>,
        sourceVoice: Boolean
    ) {
        val logRef = userDoc(uid).collection("action_logs").document()
        val item = ActionLogItem(
            batchId = batchId,
            actionType = actionType,
            entityCollection = entityCollection,
            entityId = entityId,
            summaryText = summaryText,
            beforeSummary = beforeSummary,
            afterSummary = afterSummary,
            beforeData = beforeData,
            afterData = afterData,
            sourceVoice = sourceVoice,
            reverted = false
        )
        logRef.set(item.toCreateMap()).await()
    }

    // --- Tasks ---
    suspend fun addTask(
        uid: String,
        task: TaskItem,
        batchId: String = UUID.randomUUID().toString().take(12),
        sourceVoice: Boolean = false
    ): Result<String> {
        val path = "users/$uid/tasks"
        return try {
            requireUserId(uid)
            val docRef = userDoc(uid).collection("tasks").document()
            docRef.set(task.toCreateMap()).await()
            runCatching {
                recordActionLog(
                    uid = uid,
                    batchId = batchId,
                    actionType = "create",
                    entityCollection = "tasks",
                    entityId = docRef.id,
                    summaryText = "Vazifa qo‘shildi: ${task.title}",
                    beforeSummary = "",
                    afterSummary = task.title,
                    beforeData = emptyMap(),
                    afterData = task.toSnapshotMap(),
                    sourceVoice = sourceVoice
                )
            }
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateTask(
        uid: String,
        before: TaskItem,
        after: TaskItem,
        summary: String = "Vazifa yangilandi: ${after.title}",
        batchId: String = UUID.randomUUID().toString().take(12),
        sourceVoice: Boolean = false
    ): Result<Unit> {
        val path = "users/$uid/tasks/${before.id}"
        return try {
            requireUserId(uid)
            require(before.id.isNotBlank())
            val updates = mapOf(
                "title" to after.title.trim().ifEmpty { "Vazifa" }.take(200),
                "description" to after.description.take(1000),
                "dueDateMillis" to after.dueDateMillis.coerceAtLeast(0L),
                "hasDueTime" to after.hasDueTime,
                "priority" to after.priority,
                "category" to after.category.trim().ifEmpty { "Shaxsiy" }.take(40),
                "recurrence" to after.recurrence,
                "completed" to after.completed,
                "completedAtMillis" to after.completedAtMillis.coerceAtLeast(0L),
                "personId" to after.personId.take(128),
                "personName" to after.personName.take(80),
                "goalId" to after.goalId.take(128),
                "noteText" to after.noteText.take(1000),
                "reminderEnabled" to after.reminderEnabled,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            userDoc(uid).collection("tasks").document(before.id).update(updates).await()
            runCatching {
                recordActionLog(
                    uid = uid,
                    batchId = batchId,
                    actionType = "update",
                    entityCollection = "tasks",
                    entityId = before.id,
                    summaryText = summary,
                    beforeSummary = if (before.completed) "${before.title} (bajarilgan)" else before.title,
                    afterSummary = if (after.completed) "${after.title} (bajarilgan)" else after.title,
                    beforeData = before.toSnapshotMap(),
                    afterData = after.toSnapshotMap(),
                    sourceVoice = sourceVoice
                )
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteTask(
        uid: String,
        task: TaskItem,
        batchId: String = UUID.randomUUID().toString().take(12)
    ): Result<Unit> {
        val path = "users/$uid/tasks/${task.id}"
        return try {
            requireUserId(uid)
            userDoc(uid).collection("tasks").document(task.id).delete().await()
            recordActionLog(
                uid = uid,
                batchId = batchId,
                actionType = "delete",
                entityCollection = "tasks",
                entityId = task.id,
                summaryText = "Vazifa o‘chirildi: ${task.title}",
                beforeSummary = task.title,
                afterSummary = "O‘chirildi",
                beforeData = task.toSnapshotMap(),
                afterData = emptyMap(),
                sourceVoice = false
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- Notes ---
    suspend fun addNote(
        uid: String,
        note: NoteItem,
        batchId: String = UUID.randomUUID().toString().take(12),
        sourceVoice: Boolean = false
    ): Result<String> {
        val path = "users/$uid/notes"
        return try {
            requireUserId(uid)
            val docRef = userDoc(uid).collection("notes").document()
            docRef.set(note.toCreateMap()).await()
            recordActionLog(
                uid = uid,
                batchId = batchId,
                actionType = "create",
                entityCollection = "notes",
                entityId = docRef.id,
                summaryText = "Eslatma saqlandi: ${note.title}",
                beforeSummary = "",
                afterSummary = note.title,
                beforeData = emptyMap(),
                afterData = note.toSnapshotMap(),
                sourceVoice = sourceVoice
            )
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateNote(uid: String, before: NoteItem, after: NoteItem): Result<Unit> {
        val path = "users/$uid/notes/${before.id}"
        return try {
            requireUserId(uid)
            val updates = mapOf(
                "title" to after.title.trim().ifEmpty { "Eslatma" }.take(150),
                "content" to after.content.take(5000),
                "category" to after.category.trim().ifEmpty { "Fikr" }.take(40),
                "colorTag" to after.colorTag.take(20),
                "pinned" to after.pinned,
                "archived" to after.archived,
                "sourceVoice" to after.sourceVoice,
                "linkedPersonId" to after.linkedPersonId.take(128),
                "linkedPersonName" to after.linkedPersonName.take(80),
                "linkedTaskId" to after.linkedTaskId.take(128),
                "linkedGoalId" to after.linkedGoalId.take(128),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            userDoc(uid).collection("notes").document(before.id).update(updates).await()
            recordActionLog(
                uid = uid,
                batchId = UUID.randomUUID().toString().take(12),
                actionType = "update",
                entityCollection = "notes",
                entityId = before.id,
                summaryText = "Eslatma tahrirlandi: ${after.title}",
                beforeSummary = before.title,
                afterSummary = after.title,
                beforeData = before.toSnapshotMap(),
                afterData = after.toSnapshotMap(),
                sourceVoice = false
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteNote(uid: String, note: NoteItem): Result<Unit> {
        val path = "users/$uid/notes/${note.id}"
        return try {
            requireUserId(uid)
            userDoc(uid).collection("notes").document(note.id).delete().await()
            recordActionLog(
                uid = uid,
                batchId = UUID.randomUUID().toString().take(12),
                actionType = "delete",
                entityCollection = "notes",
                entityId = note.id,
                summaryText = "Eslatma o‘chirildi: ${note.title}",
                beforeSummary = note.title,
                afterSummary = "O‘chirildi",
                beforeData = note.toSnapshotMap(),
                afterData = emptyMap(),
                sourceVoice = false
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- Transactions ---
    suspend fun addTransaction(
        uid: String,
        tx: FinanceTransaction,
        batchId: String = UUID.randomUUID().toString().take(12),
        sourceVoice: Boolean = false
    ): Result<String> {
        val path = "users/$uid/transactions"
        return try {
            requireUserId(uid)
            val docRef = userDoc(uid).collection("transactions").document()
            docRef.set(tx.toCreateMap()).await()
            val label = if (tx.kind == "expense") "Xarajat" else "Moliyaviy yozuv"
            runCatching {
                recordActionLog(
                    uid = uid,
                    batchId = batchId,
                    actionType = "create",
                    entityCollection = "transactions",
                    entityId = docRef.id,
                    summaryText = "$label: ${tx.title} (${tx.amount.toLong()} ${tx.currency})",
                    beforeSummary = "",
                    afterSummary = "${tx.title} — ${tx.amount.toLong()} ${tx.currency}",
                    beforeData = emptyMap(),
                    afterData = tx.toSnapshotMap(),
                    sourceVoice = sourceVoice
                )
            }
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateTransaction(
        uid: String,
        before: FinanceTransaction,
        after: FinanceTransaction
    ): Result<Unit> {
        val path = "users/$uid/transactions/${before.id}"
        return try {
            requireUserId(uid)
            val updates = mapOf(
                "kind" to after.kind,
                "amount" to after.amount.coerceAtLeast(0.01),
                "currency" to after.currency,
                "category" to after.category.trim().ifEmpty { "Boshqa" }.take(50),
                "title" to after.title.trim().ifEmpty { after.category }.take(150),
                "note" to after.note.take(500),
                "occurredAtMillis" to after.occurredAtMillis.coerceAtLeast(1L),
                "personId" to after.personId.take(128),
                "personName" to after.personName.take(80),
                "goalId" to after.goalId.take(128),
                "debtId" to after.debtId.take(128),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            userDoc(uid).collection("transactions").document(before.id).update(updates).await()
            recordActionLog(
                uid = uid,
                batchId = UUID.randomUUID().toString().take(12),
                actionType = "update",
                entityCollection = "transactions",
                entityId = before.id,
                summaryText = "Moliyaviy yozuv tahrirlandi: ${after.title}",
                beforeSummary = "${before.title} (${before.amount.toLong()} ${before.currency})",
                afterSummary = "${after.title} (${after.amount.toLong()} ${after.currency})",
                beforeData = before.toSnapshotMap(),
                afterData = after.toSnapshotMap(),
                sourceVoice = false
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteTransaction(uid: String, tx: FinanceTransaction): Result<Unit> {
        val path = "users/$uid/transactions/${tx.id}"
        return try {
            requireUserId(uid)
            userDoc(uid).collection("transactions").document(tx.id).delete().await()
            recordActionLog(
                uid = uid,
                batchId = UUID.randomUUID().toString().take(12),
                actionType = "delete",
                entityCollection = "transactions",
                entityId = tx.id,
                summaryText = "Moliyaviy yozuv o‘chirildi: ${tx.title}",
                beforeSummary = "${tx.title} (${tx.amount.toLong()} ${tx.currency})",
                afterSummary = "O‘chirildi",
                beforeData = tx.toSnapshotMap(),
                afterData = emptyMap(),
                sourceVoice = false
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- People ---
    suspend fun ensurePerson(
        uid: String,
        name: String,
        existingPeople: List<PersonItem>,
        phone: String = "",
        note: String = "",
        batchId: String = UUID.randomUUID().toString().take(12),
        sourceVoice: Boolean = false
    ): Result<PersonItem> {
        val clean = name.trim()
        if (clean.isEmpty()) return Result.failure(IllegalArgumentException("Ism bo‘sh"))
        val existing = existingPeople.firstOrNull { it.name.equals(clean, ignoreCase = true) }
        if (existing != null) return Result.success(existing)

        val colors = listOf("emerald", "ocean", "amber", "violet", "coral")
        val person = PersonItem(
            name = clean,
            phone = phone,
            note = note,
            avatarColor = colors[kotlin.math.abs(clean.hashCode()) % colors.size]
        )
        val path = "users/$uid/people"
        return try {
            requireUserId(uid)
            val docRef = userDoc(uid).collection("people").document()
            docRef.set(person.toCreateMap()).await()
            val created = person.copy(id = docRef.id)
            runCatching {
                recordActionLog(
                    uid = uid,
                    batchId = batchId,
                    actionType = "create",
                    entityCollection = "people",
                    entityId = docRef.id,
                    summaryText = "Inson qo‘shildi: $clean",
                    beforeSummary = "",
                    afterSummary = clean,
                    beforeData = emptyMap(),
                    afterData = created.toSnapshotMap(),
                    sourceVoice = sourceVoice
                )
            }
            Result.success(created)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updatePerson(uid: String, before: PersonItem, after: PersonItem): Result<Unit> {
        val path = "users/$uid/people/${before.id}"
        return try {
            requireUserId(uid)
            userDoc(uid).collection("people").document(before.id).update(
                mapOf(
                    "name" to after.name.trim().ifEmpty { "Inson" }.take(80),
                    "phone" to after.phone.take(30),
                    "note" to after.note.take(500),
                    "avatarColor" to after.avatarColor.take(20),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deletePerson(uid: String, person: PersonItem): Result<Unit> {
        val path = "users/$uid/people/${person.id}"
        return try {
            requireUserId(uid)
            userDoc(uid).collection("people").document(person.id).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- Debts ---
    suspend fun addDebt(
        uid: String,
        debt: DebtItem,
        batchId: String = UUID.randomUUID().toString().take(12),
        sourceVoice: Boolean = false
    ): Result<String> {
        val path = "users/$uid/debts"
        return try {
            requireUserId(uid)
            val docRef = userDoc(uid).collection("debts").document()
            docRef.set(debt.toCreateMap()).await()
            val dirText = if (debt.direction == "lent") "qarz berildi" else "qarz olindi"
            runCatching {
                recordActionLog(
                    uid = uid,
                    batchId = batchId,
                    actionType = "create",
                    entityCollection = "debts",
                    entityId = docRef.id,
                    summaryText = "${debt.personName}: ${debt.originalAmount.toLong()} ${debt.currency} $dirText",
                    beforeSummary = "",
                    afterSummary = "${debt.personName} — ${debt.originalAmount.toLong()} ${debt.currency}",
                    beforeData = emptyMap(),
                    afterData = debt.toSnapshotMap(),
                    sourceVoice = sourceVoice
                )
            }
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun recordDebtPayment(
        uid: String,
        debt: DebtItem,
        paymentAmount: Double,
        batchId: String = UUID.randomUUID().toString().take(12),
        sourceVoice: Boolean = false
    ): Result<Unit> {
        val path = "users/$uid/debts/${debt.id}"
        return try {
            requireUserId(uid)
            val safePay = paymentAmount.coerceIn(0.01, debt.remainingAmount.coerceAtLeast(0.01))
            val newPaid = (debt.paidAmount + safePay).coerceAtMost(debt.originalAmount)
            val isNowClosed = newPaid >= debt.originalAmount - 0.001
            val closedMillis = if (isNowClosed) System.currentTimeMillis() else 0L
            val after = debt.copy(
                paidAmount = newPaid,
                closed = isNowClosed,
                closedAtMillis = closedMillis
            )
            userDoc(uid).collection("debts").document(debt.id).update(
                mapOf(
                    "paidAmount" to newPaid,
                    "closed" to isNowClosed,
                    "closedAtMillis" to closedMillis,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            // Debt payments stay strictly inside Debts and are NOT mixed into Expenses/Transactions.
            runCatching {
                recordActionLog(
                    uid = uid,
                    batchId = batchId,
                    actionType = "update",
                    entityCollection = "debts",
                    entityId = debt.id,
                    summaryText = if (isNowClosed) {
                        "${debt.personName} qarzi to‘liq yopildi"
                    } else {
                        "${debt.personName} qarzidan ${safePay.toLong()} ${debt.currency} qaytarildi"
                    },
                    beforeSummary = "Qoldiq: ${debt.remainingAmount.toLong()} ${debt.currency}",
                    afterSummary = "Qoldiq: ${after.remainingAmount.toLong()} ${debt.currency}",
                    beforeData = debt.toSnapshotMap(),
                    afterData = after.toSnapshotMap(),
                    sourceVoice = sourceVoice
                )
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteDebt(uid: String, debt: DebtItem): Result<Unit> {
        val path = "users/$uid/debts/${debt.id}"
        return try {
            requireUserId(uid)
            userDoc(uid).collection("debts").document(debt.id).delete().await()
            recordActionLog(
                uid = uid,
                batchId = UUID.randomUUID().toString().take(12),
                actionType = "delete",
                entityCollection = "debts",
                entityId = debt.id,
                summaryText = "Qarz o‘chirildi: ${debt.personName}",
                beforeSummary = "${debt.personName} — ${debt.originalAmount.toLong()} ${debt.currency}",
                afterSummary = "O‘chirildi",
                beforeData = debt.toSnapshotMap(),
                afterData = emptyMap(),
                sourceVoice = false
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- Goals ---
    suspend fun addGoal(
        uid: String,
        goal: GoalItem,
        batchId: String = UUID.randomUUID().toString().take(12),
        sourceVoice: Boolean = false
    ): Result<String> {
        val path = "users/$uid/goals"
        return try {
            requireUserId(uid)
            val docRef = userDoc(uid).collection("goals").document()
            docRef.set(goal.toCreateMap()).await()
            recordActionLog(
                uid = uid,
                batchId = batchId,
                actionType = "create",
                entityCollection = "goals",
                entityId = docRef.id,
                summaryText = "Maqsad yaratildi: ${goal.title}",
                beforeSummary = "",
                afterSummary = "${goal.title} (${goal.targetValue.toLong()} ${goal.unit})",
                beforeData = emptyMap(),
                afterData = goal.toSnapshotMap(),
                sourceVoice = sourceVoice
            )
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateGoalProgress(
        uid: String,
        goal: GoalItem,
        delta: Double,
        recordSavingTransaction: Boolean = true,
        batchId: String = UUID.randomUUID().toString().take(12),
        sourceVoice: Boolean = false
    ): Result<Unit> {
        val path = "users/$uid/goals/${goal.id}"
        return try {
            requireUserId(uid)
            val newVal = (goal.currentValue + delta).coerceAtLeast(0.0)
            val nowDone = newVal >= goal.targetValue
            val after = goal.copy(currentValue = newVal, completed = nowDone)
            userDoc(uid).collection("goals").document(goal.id).update(
                mapOf(
                    "currentValue" to newVal,
                    "completed" to nowDone,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            if (recordSavingTransaction && goal.goalType == "financial" && delta > 0.0 && goal.currency.isNotBlank()) {
                val tx = FinanceTransaction(
                    kind = "goal_saving",
                    amount = delta,
                    currency = goal.currency,
                    category = "Jamg‘arma",
                    title = "${goal.title} uchun jamg‘arma",
                    note = "",
                    occurredAtMillis = System.currentTimeMillis(),
                    goalId = goal.id
                )
                userDoc(uid).collection("transactions").document().set(tx.toCreateMap()).await()
            }

            recordActionLog(
                uid = uid,
                batchId = batchId,
                actionType = "update",
                entityCollection = "goals",
                entityId = goal.id,
                summaryText = "Maqsad yangilandi: ${goal.title}",
                beforeSummary = "${goal.currentValue.toLong()} / ${goal.targetValue.toLong()} ${goal.unit}",
                afterSummary = "${newVal.toLong()} / ${goal.targetValue.toLong()} ${goal.unit}",
                beforeData = goal.toSnapshotMap(),
                afterData = after.toSnapshotMap(),
                sourceVoice = sourceVoice
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteGoal(uid: String, goal: GoalItem): Result<Unit> {
        val path = "users/$uid/goals/${goal.id}"
        return try {
            requireUserId(uid)
            userDoc(uid).collection("goals").document(goal.id).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- Undo Single Action or Entire Voice Batch ---
    suspend fun undoActionLog(uid: String, log: ActionLogItem): Result<Unit> {
        if (log.reverted) return Result.success(Unit)
        val path = "users/$uid/${log.entityCollection}/${log.entityId}"
        return try {
            requireUserId(uid)
            val targetRef = userDoc(uid).collection(log.entityCollection).document(log.entityId)
            when (log.actionType) {
                "create" -> {
                    targetRef.delete().await()
                }
                "update" -> {
                    if (log.beforeData.isNotEmpty()) {
                        val restore = log.beforeData.toMutableMap()
                        restore["updatedAt"] = FieldValue.serverTimestamp()
                        targetRef.update(restore).await()
                    }
                }
                "delete" -> {
                    if (log.beforeData.isNotEmpty()) {
                        val restore = log.beforeData.toMutableMap()
                        restore["createdAt"] = FieldValue.serverTimestamp()
                        restore["updatedAt"] = FieldValue.serverTimestamp()
                        targetRef.set(restore).await()
                    }
                }
            }
            userDoc(uid).collection("action_logs").document(log.id)
                .update(mapOf("reverted" to true)).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun undoBatch(uid: String, logs: List<ActionLogItem>): Result<Int> {
        var count = 0
        for (log in logs.sortedByDescending { it.createdAt?.seconds ?: 0L }) {
            if (!log.reverted) {
                val res = undoActionLog(uid, log)
                if (res.isSuccess) count++
            }
        }
        return Result.success(count)
    }

    // --- Daily Reviews ---
    suspend fun saveDailyReview(uid: String, review: DailyReviewItem): Result<Unit> {
        val path = "users/$uid/daily_reviews/${review.dateKey}"
        return try {
            requireUserId(uid)
            val docRef = userDoc(uid).collection("daily_reviews").document(review.dateKey)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                docRef.set(review.toCreateMap()).await()
            } else {
                docRef.update(
                    mapOf(
                        "completedTasksCount" to review.completedTasksCount,
                        "pendingTasksCount" to review.pendingTasksCount,
                        "completionPercent" to review.completionPercent,
                        "totalIncome" to review.totalIncome,
                        "totalExpense" to review.totalExpense,
                        "currency" to review.currency,
                        "topExpenseCategory" to review.topExpenseCategory,
                        "aiSummary" to review.aiSummary,
                        "tomorrowAdvice" to review.tomorrowAdvice,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    // --- Chat Messages ---
    suspend fun addChatMessage(uid: String, message: AssistantMessage): Result<String> {
        val path = "users/$uid/chat_messages"
        return try {
            requireUserId(uid)
            val docRef = userDoc(uid).collection("chat_messages").document()
            docRef.set(message.toCreateMap()).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun clearChatHistory(uid: String): Result<Unit> {
        val path = "users/$uid/chat_messages"
        return try {
            requireUserId(uid)
            val snaps = userDoc(uid).collection("chat_messages").get().await()
            for (doc in snaps.documents) {
                doc.reference.delete().await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- Export & Restore Backup JSON ---
    fun buildBackupJson(
        profile: UserProfile?,
        tasks: List<TaskItem>,
        notes: List<NoteItem>,
        transactions: List<FinanceTransaction>,
        debts: List<DebtItem>,
        people: List<PersonItem>,
        goals: List<GoalItem>
    ): String {
        val root = JSONObject()
        root.put("app", "OvozOS")
        root.put("exportedAtMillis", System.currentTimeMillis())
        profile?.let {
            root.put(
                "profile",
                JSONObject().apply {
                    put("displayName", it.displayName)
                    put("language", it.language)
                    put("primaryCurrency", it.primaryCurrency)
                    put("initialBalanceUzs", it.initialBalanceUzs)
                    put("initialBalanceUsd", it.initialBalanceUsd)
                    put("initialBalanceEur", it.initialBalanceEur)
                    put("initialBalanceRub", it.initialBalanceRub)
                }
            )
        }
        root.put("tasks", JSONArray(tasks.map { JSONObject(it.toSnapshotMap()) }))
        root.put("notes", JSONArray(notes.map { JSONObject(it.toSnapshotMap()) }))
        root.put("transactions", JSONArray(transactions.map { JSONObject(it.toSnapshotMap()) }))
        root.put("debts", JSONArray(debts.map { JSONObject(it.toSnapshotMap()) }))
        root.put("people", JSONArray(people.map { JSONObject(it.toSnapshotMap()) }))
        root.put("goals", JSONArray(goals.map { JSONObject(it.toSnapshotMap()) }))
        return root.toString(2)
    }

    suspend fun restoreFromBackupJson(uid: String, rawJson: String): Result<Int> {
        return try {
            requireUserId(uid)
            val root = JSONObject(rawJson)
            var restored = 0

            val tasksArr = root.optJSONArray("tasks")
            if (tasksArr != null) {
                for (i in 0 until tasksArr.length()) {
                    val o = tasksArr.getJSONObject(i)
                    val item = TaskItem(
                        title = o.optString("title", "Vazifa"),
                        description = o.optString("description", ""),
                        dueDateMillis = o.optLong("dueDateMillis", 0L),
                        hasDueTime = o.optBoolean("hasDueTime", false),
                        priority = o.optString("priority", "medium"),
                        category = o.optString("category", "Shaxsiy"),
                        recurrence = o.optString("recurrence", "none"),
                        completed = o.optBoolean("completed", false),
                        completedAtMillis = o.optLong("completedAtMillis", 0L),
                        personName = o.optString("personName", ""),
                        noteText = o.optString("noteText", ""),
                        reminderEnabled = o.optBoolean("reminderEnabled", false)
                    )
                    userDoc(uid).collection("tasks").document().set(item.toCreateMap()).await()
                    restored++
                }
            }

            val notesArr = root.optJSONArray("notes")
            if (notesArr != null) {
                for (i in 0 until notesArr.length()) {
                    val o = notesArr.getJSONObject(i)
                    val item = NoteItem(
                        title = o.optString("title", "Eslatma"),
                        content = o.optString("content", ""),
                        category = o.optString("category", "Fikr"),
                        colorTag = o.optString("colorTag", "emerald"),
                        pinned = o.optBoolean("pinned", false),
                        archived = o.optBoolean("archived", false),
                        sourceVoice = o.optBoolean("sourceVoice", false)
                    )
                    userDoc(uid).collection("notes").document().set(item.toCreateMap()).await()
                    restored++
                }
            }

            val txArr = root.optJSONArray("transactions")
            if (txArr != null) {
                for (i in 0 until txArr.length()) {
                    val o = txArr.getJSONObject(i)
                    val amt = o.optDouble("amount", 0.0)
                    if (amt > 0.0) {
                        val item = FinanceTransaction(
                            kind = o.optString("kind", "expense"),
                            amount = amt,
                            currency = o.optString("currency", "UZS"),
                            category = o.optString("category", "Boshqa"),
                            title = o.optString("title", "Yozuv"),
                            note = o.optString("note", ""),
                            occurredAtMillis = o.optLong("occurredAtMillis", System.currentTimeMillis()),
                            personName = o.optString("personName", "")
                        )
                        userDoc(uid).collection("transactions").document().set(item.toCreateMap()).await()
                        restored++
                    }
                }
            }

            val debtsArr = root.optJSONArray("debts")
            if (debtsArr != null) {
                for (i in 0 until debtsArr.length()) {
                    val o = debtsArr.getJSONObject(i)
                    val orig = o.optDouble("originalAmount", 0.0)
                    if (orig > 0.0) {
                        val item = DebtItem(
                            direction = o.optString("direction", "borrowed"),
                            personName = o.optString("personName", "Noma’lum"),
                            originalAmount = orig,
                            paidAmount = o.optDouble("paidAmount", 0.0),
                            currency = o.optString("currency", "UZS"),
                            note = o.optString("note", ""),
                            issuedAtMillis = o.optLong("issuedAtMillis", System.currentTimeMillis()),
                            dueDateMillis = o.optLong("dueDateMillis", 0L),
                            closed = o.optBoolean("closed", false),
                            closedAtMillis = o.optLong("closedAtMillis", 0L)
                        )
                        userDoc(uid).collection("debts").document().set(item.toCreateMap()).await()
                        restored++
                    }
                }
            }

            val peopleArr = root.optJSONArray("people")
            if (peopleArr != null) {
                for (i in 0 until peopleArr.length()) {
                    val o = peopleArr.getJSONObject(i)
                    val item = PersonItem(
                        name = o.optString("name", "Inson"),
                        phone = o.optString("phone", ""),
                        note = o.optString("note", ""),
                        avatarColor = o.optString("avatarColor", "emerald")
                    )
                    userDoc(uid).collection("people").document().set(item.toCreateMap()).await()
                    restored++
                }
            }

            val goalsArr = root.optJSONArray("goals")
            if (goalsArr != null) {
                for (i in 0 until goalsArr.length()) {
                    val o = goalsArr.getJSONObject(i)
                    val target = o.optDouble("targetValue", 1.0)
                    val item = GoalItem(
                        title = o.optString("title", "Maqsad"),
                        description = o.optString("description", ""),
                        goalType = o.optString("goalType", "personal"),
                        targetValue = target.coerceAtLeast(1.0),
                        currentValue = o.optDouble("currentValue", 0.0),
                        unit = o.optString("unit", "UZS"),
                        currency = o.optString("currency", "UZS"),
                        startDateMillis = o.optLong("startDateMillis", System.currentTimeMillis()),
                        deadlineMillis = o.optLong("deadlineMillis", 0L),
                        completed = o.optBoolean("completed", false)
                    )
                    userDoc(uid).collection("goals").document().set(item.toCreateMap()).await()
                    restored++
                }
            }

            Result.success(restored)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "users/$uid/restore")
            Result.failure(e)
        }
    }

    suspend fun wipeAllUserData(uid: String): Result<Unit> {
        val collections = listOf(
            "tasks", "notes", "transactions", "debts",
            "people", "goals", "action_logs", "daily_reviews", "chat_messages"
        )
        return try {
            requireUserId(uid)
            for (col in collections) {
                val snaps = userDoc(uid).collection(col).get().await()
                for (doc in snaps.documents) {
                    doc.reference.delete().await()
                }
            }
            userDoc(uid).update(
                mapOf(
                    "initialBalanceUzs" to 0.0,
                    "initialBalanceUsd" to 0.0,
                    "initialBalanceEur" to 0.0,
                    "initialBalanceRub" to 0.0,
                    "dashboardOrder" to DefaultDashboardCards,
                    "hiddenCards" to emptyList<String>(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "users/$uid")
            Result.failure(e)
        }
    }
}

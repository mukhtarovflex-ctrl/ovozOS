package com.example.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.core.AppStrings
import com.example.core.Formatters
import com.example.core.TaskCategoriesUz
import com.example.data.model.PersonItem
import com.example.data.model.TaskItem
import com.example.ui.components.OvozPrimaryButton
import com.example.ui.theme.LocalOvozTokens
import java.util.Calendar

@Composable
fun TasksScreen(
    strings: AppStrings,
    tasks: List<TaskItem>,
    people: List<PersonItem>,
    bottomBarPadding: Dp = 116.dp,
    onAddTask: (TaskItem) -> Unit,
    onUpdateTask: (TaskItem, TaskItem) -> Unit,
    onToggleCompleted: (TaskItem) -> Unit,
    onDeleteTask: (TaskItem) -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    // Default is "all" (Barchasi) so every voice-created or manual task is immediately visible
    var selectedFilter by remember { mutableStateOf("all") }
    var extraFilterMenuOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var editingTask by remember { mutableStateOf<TaskItem?>(null) }
    var showCreateSheet by remember { mutableStateOf(false) }

    val primaryFilters = listOf(
        "all" to strings.all,
        "today" to strings.today,
        "tomorrow" to strings.tomorrow,
        "upcoming" to strings.upcoming,
        "completed" to strings.completed
    )
    val extraFilters = listOf(
        "week" to strings.thisWeek,
        "overdue" to strings.overdue,
        "high" to "Yuqori muhimlik"
    )
    val activeExtraLabel = extraFilters.firstOrNull { it.first == selectedFilter }?.second

    val filtered = remember(tasks, selectedFilter, query) {
        val base = when (selectedFilter) {
            "today" -> tasks.filter { !it.completed && Formatters.isToday(it.dueDateMillis) }
            "tomorrow" -> tasks.filter { !it.completed && Formatters.isTomorrow(it.dueDateMillis) }
            "week" -> tasks.filter { !it.completed && Formatters.isThisWeek(it.dueDateMillis) }
            "upcoming" -> tasks.filter {
                !it.completed && it.dueDateMillis > Formatters.endOfDay()
            }
            "overdue" -> tasks.filter { Formatters.isOverdue(it.dueDateMillis, it.completed) }
            "high" -> tasks.filter { !it.completed && it.priority == "high" }
            "completed" -> tasks.filter { it.completed }
            else -> tasks // "all": shows every active & completed task including undated ones
        }
        val searched = if (query.isBlank()) base else base.filter {
            it.title.contains(query, ignoreCase = true) ||
                it.description.contains(query, ignoreCase = true) ||
                it.category.contains(query, ignoreCase = true) ||
                it.personName.contains(query, ignoreCase = true)
        }
        searched.sortedWith(
            compareBy<TaskItem> { it.completed }
                .thenBy { if (it.dueDateMillis > 0L) it.dueDateMillis else Long.MAX_VALUE }
                .thenByDescending { it.priority == "high" }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("tasks_screen")
    ) {
        // Minimal Header: Title + single "+ Yangi" button (no redundant subtitle)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = strings.tasksTitle,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Button(
                onClick = { showCreateSheet = true },
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("tasks_add_button")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Yangi", style = MaterialTheme.typography.labelLarge)
            }
        }

        // Compact search bar (only when user has tasks)
        if (tasks.isNotEmpty()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Qidirish...", color = tokens.mutedText) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = tokens.mutedText) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Tozalash")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            )
            Spacer(Modifier.height(10.dp))
        }

        // Compact Filter Chips + Dropdown for extra filters
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(primaryFilters) { (key, label) ->
                val selected = selectedFilter == key
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (selected) primary else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, if (selected) primary else tokens.cardBorder),
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { selectedFilter = key }
                        .testTag("task_filter_$key")
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp)
                    )
                }
            }

            item {
                Box {
                    val isExtraActive = activeExtraLabel != null
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isExtraActive) primary else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, if (isExtraActive) primary else tokens.cardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { extraFilterMenuOpen = true }
                            .testTag("task_filter_more")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 11.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Rounded.FilterList,
                                contentDescription = "Boshqa filtrlar",
                                tint = if (isExtraActive) MaterialTheme.colorScheme.onPrimary else tokens.mutedText,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = activeExtraLabel ?: "Filtr",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (isExtraActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                fontWeight = if (isExtraActive) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = extraFilterMenuOpen,
                        onDismissRequest = { extraFilterMenuOpen = false }
                    ) {
                        extraFilters.forEach { (key, label) ->
                            DropdownMenuItem(
                                text = { Text(label) },
                                onClick = {
                                    selectedFilter = key
                                    extraFilterMenuOpen = false
                                }
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        if (filtered.isEmpty()) {
            val emptyMessage = when (selectedFilter) {
                "today" -> "Bugun vazifalar yo‘q"
                "tomorrow" -> "Ertaga vazifalar yo‘q"
                "upcoming" -> "Kelgusi vazifalar yo‘q"
                "completed" -> "Bajarilgan vazifalar yo‘q"
                "overdue" -> "Kechikkan vazifalar yo‘q"
                "high" -> "Yuqori muhimlikdagi vazifalar yo‘q"
                else -> "Vazifalar yo‘q"
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(bottom = bottomBarPadding),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = emptyMessage,
                    style = MaterialTheme.typography.bodyLarge,
                    color = tokens.mutedText
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = bottomBarPadding)
            ) {
                itemsIndexed(filtered, key = { _, item -> item.id }) { idx, task ->
                    FlatTaskRow(
                        task = task,
                        onToggle = { onToggleCompleted(task) },
                        onClick = { editingTask = task }
                    )
                    if (idx < filtered.lastIndex) {
                        HorizontalDivider(color = tokens.cardBorder.copy(alpha = 0.7f))
                    }
                }
            }
        }
    }

    if (showCreateSheet) {
        TaskEditorSheet(
            initial = null,
            people = people,
            onDismiss = { showCreateSheet = false },
            onSave = { created ->
                onAddTask(created)
                showCreateSheet = false
            }
        )
    }

    editingTask?.let { t ->
        TaskEditorSheet(
            initial = t,
            people = people,
            onDismiss = { editingTask = null },
            onSave = { updated ->
                onUpdateTask(t, updated)
                editingTask = null
            },
            onDelete = {
                onDeleteTask(t)
                editingTask = null
            }
        )
    }
}

@Composable
private fun FlatTaskRow(
    task: TaskItem,
    onToggle: () -> Unit,
    onClick: () -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    val isOverdue = Formatters.isOverdue(task.dueDateMillis, task.completed)
    val checkBg by animateColorAsState(
        targetValue = if (task.completed) primary else Color.Transparent,
        animationSpec = tween(180),
        label = "flat_task_check"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp)
            .testTag("task_item_${task.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .clickable(onClick = onToggle)
                .testTag("task_check_${task.id}"),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(checkBg)
                    .border(
                        width = 1.6.dp,
                        color = if (task.completed) primary else if (isOverdue) tokens.expense else tokens.mutedText.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(7.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (task.completed) {
                    Icon(
                        Icons.Rounded.Check,
                        contentDescription = "Bajarildi",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
        }

        Spacer(Modifier.width(4.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = if (task.completed) FontWeight.Normal else FontWeight.Medium,
                    textDecoration = if (task.completed) TextDecoration.LineThrough else TextDecoration.None,
                    color = if (task.completed) tokens.mutedText else MaterialTheme.colorScheme.onBackground,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (!task.completed && task.priority == "high") {
                    Spacer(Modifier.width(7.dp))
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(tokens.expense)
                    )
                }
            }

            val metaParts = buildList {
                if (task.dueDateMillis > 0L) {
                    val dateLabel = when {
                        Formatters.isToday(task.dueDateMillis) ->
                            if (task.hasDueTime) "Bugun, ${Formatters.formatTime24(task.dueDateMillis)}" else "Bugun"
                        Formatters.isTomorrow(task.dueDateMillis) ->
                            if (task.hasDueTime) "Ertaga, ${Formatters.formatTime24(task.dueDateMillis)}" else "Ertaga"
                        else ->
                            if (task.hasDueTime) Formatters.formatDateTime24(task.dueDateMillis) else Formatters.formatShortDate(task.dueDateMillis)
                    }
                    add(dateLabel)
                }
                if (task.personName.isNotBlank()) add(task.personName)
                if (task.category.isNotBlank() && task.category != "Shaxsiy") add(task.category)
            }
            if (metaParts.isNotEmpty()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    text = metaParts.joinToString(" · "),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isOverdue) tokens.expense else tokens.mutedText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskEditorSheet(
    initial: TaskItem?,
    people: List<PersonItem>,
    onDismiss: () -> Unit,
    onSave: (TaskItem) -> Unit,
    onDelete: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    var title by remember { mutableStateOf(initial?.title.orEmpty()) }
    var description by remember { mutableStateOf(initial?.description.orEmpty()) }
    var dueDateMillis by remember { mutableLongStateOf(initial?.dueDateMillis ?: 0L) }
    var hasDueTime by remember { mutableStateOf(initial?.hasDueTime ?: false) }
    var priority by remember { mutableStateOf(initial?.priority ?: "medium") }
    var category by remember { mutableStateOf(initial?.category ?: "Shaxsiy") }
    var recurrence by remember { mutableStateOf(initial?.recurrence ?: "none") }
    var personName by remember { mutableStateOf(initial?.personName.orEmpty()) }
    var reminderEnabled by remember { mutableStateOf(initial?.reminderEnabled ?: true) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (initial == null) "Yangi vazifa" else "Vazifani tahrirlash",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                if (onDelete != null) {
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Rounded.DeleteOutline, contentDescription = "O‘chirish", tint = tokens.expense)
                    }
                }
            }

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Vazifa nomi") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("task_title_input")
            )

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Izoh (ixtiyoriy)") },
                minLines = 2,
                maxLines = 3,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            // Quick Date presets + Date/Time Pickers
            Text("Muddat", style = MaterialTheme.typography.labelMedium, color = tokens.mutedText)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    QuickDateChip("Bugun", dueDateMillis > 0 && Formatters.isToday(dueDateMillis)) {
                        dueDateMillis = Formatters.startOfDay() + 18L * 3_600_000L
                    }
                }
                item {
                    QuickDateChip("Ertaga", dueDateMillis > 0 && Formatters.isTomorrow(dueDateMillis)) {
                        dueDateMillis = Formatters.startOfDay() + 86_400_000L + 12L * 3_600_000L
                    }
                }
                item {
                    QuickDateChip("Sanasiz", dueDateMillis == 0L) {
                        dueDateMillis = 0L
                        hasDueTime = false
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = {
                        val cal = Calendar.getInstance().apply {
                            if (dueDateMillis > 0L) timeInMillis = dueDateMillis
                        }
                        DatePickerDialog(
                            context,
                            { _, y, m, d ->
                                val picked = Calendar.getInstance().apply {
                                    if (dueDateMillis > 0L) timeInMillis = dueDateMillis
                                    set(y, m, d)
                                    if (!hasDueTime) {
                                        set(Calendar.HOUR_OF_DAY, 12)
                                        set(Calendar.MINUTE, 0)
                                    }
                                }
                                dueDateMillis = picked.timeInMillis
                            },
                            cal.get(Calendar.YEAR),
                            cal.get(Calendar.MONTH),
                            cal.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (dueDateMillis > 0L) Formatters.formatShortDate(dueDateMillis) else "Sana")
                }

                OutlinedButton(
                    onClick = {
                        val cal = Calendar.getInstance().apply {
                            if (dueDateMillis > 0L) timeInMillis = dueDateMillis
                        }
                        TimePickerDialog(
                            context,
                            { _, h, min ->
                                val picked = Calendar.getInstance().apply {
                                    if (dueDateMillis > 0L) timeInMillis = dueDateMillis
                                    set(Calendar.HOUR_OF_DAY, h)
                                    set(Calendar.MINUTE, min)
                                    set(Calendar.SECOND, 0)
                                }
                                dueDateMillis = picked.timeInMillis
                                hasDueTime = true
                            },
                            cal.get(Calendar.HOUR_OF_DAY),
                            cal.get(Calendar.MINUTE),
                            true
                        ).show()
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.Schedule, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (hasDueTime && dueDateMillis > 0L) Formatters.formatTime24(dueDateMillis) else "Vaqt")
                }
            }

            // Priority
            Text("Muhimlik", style = MaterialTheme.typography.labelMedium, color = tokens.mutedText)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("low" to "Past", "medium" to "O‘rta", "high" to "Yuqori").forEach { (k, lbl) ->
                    val sel = priority == k
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (sel) primary else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, if (sel) primary else tokens.cardBorder),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { priority = k }
                    ) {
                        Box(modifier = Modifier.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                            Text(
                                lbl,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Category
            Text("Turkum", style = MaterialTheme.typography.labelMedium, color = tokens.mutedText)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(TaskCategoriesUz) { cat ->
                    val sel = category == cat
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, if (sel) primary else tokens.cardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { category = cat }
                    ) {
                        Text(
                            cat,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (sel) primary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }
                }
            }

            // Recurrence
            Text("Takrorlanish", style = MaterialTheme.typography.labelMedium, color = tokens.mutedText)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("none" to "Yo‘q", "daily" to "Har kuni", "weekly" to "Har hafta", "monthly" to "Har oy")) { (k, lbl) ->
                    val sel = recurrence == k
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, if (sel) primary else tokens.cardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { recurrence = k }
                    ) {
                        Text(
                            lbl,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (sel) primary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }
                }
            }

            OutlinedTextField(
                value = personName,
                onValueChange = { personName = it },
                label = { Text("Bog‘langan inson (ixtiyoriy)") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            if (people.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(people.take(8)) { p ->
                        TextButton(onClick = { personName = p.name }) {
                            Text(p.name, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Eslatma bildirishnomasi", style = MaterialTheme.typography.bodyMedium)
                Switch(checked = reminderEnabled, onCheckedChange = { reminderEnabled = it })
            }

            OvozPrimaryButton(
                text = "Saqlash",
                enabled = title.isNotBlank(),
                onClick = {
                    val matchedPerson = people.firstOrNull { it.name.equals(personName.trim(), ignoreCase = true) }
                    onSave(
                        (initial ?: TaskItem()).copy(
                            title = title.trim(),
                            description = description.trim(),
                            dueDateMillis = dueDateMillis,
                            hasDueTime = hasDueTime,
                            priority = priority,
                            category = category,
                            recurrence = recurrence,
                            personId = matchedPerson?.id.orEmpty(),
                            personName = personName.trim(),
                            goalId = "",
                            reminderEnabled = reminderEnabled
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("task_save_button")
            )
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun QuickDateChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val tokens = LocalOvozTokens.current
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, if (selected) primary else tokens.cardBorder),
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) primary else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
        )
    }
}

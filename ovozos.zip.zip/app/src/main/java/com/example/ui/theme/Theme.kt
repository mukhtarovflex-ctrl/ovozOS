package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Immutable
data class OvozTokens(
    val isDark: Boolean,
    val income: Color,
    val incomeBg: Color,
    val expense: Color,
    val expenseBg: Color,
    val warning: Color,
    val warningBg: Color,
    val info: Color,
    val infoBg: Color,
    val debt: Color,
    val debtBg: Color,
    val cardBorder: Color,
    val mutedText: Color,
    val cardPadding: Dp,
    val sectionSpacing: Dp,
    val itemSpacing: Dp
)

val LocalOvozTokens = staticCompositionLocalOf {
    OvozTokens(
        isDark = false,
        income = IncomeGreenLight,
        incomeBg = IncomeBgLight,
        expense = ExpenseCoralLight,
        expenseBg = ExpenseBgLight,
        warning = WarningAmberLight,
        warningBg = WarningBgLight,
        info = InfoBlueLight,
        infoBg = InfoBgLight,
        debt = DebtPurpleLight,
        debtBg = DebtBgLight,
        cardBorder = LightOutline,
        mutedText = LightMutedGray,
        cardPadding = 16.dp,
        sectionSpacing = 16.dp,
        itemSpacing = 10.dp
    )
}

val OvozShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun OvozOSTheme(
    themeMode: String = "system",
    accentPreset: String = "emerald",
    textScale: String = "standard",
    density: String = "comfortable",
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val useDark = when (themeMode) {
        "dark" -> true
        "light" -> false
        else -> systemDark
    }

    val (lightPrimary, lightContainer, darkPrimary, darkContainer) = when (accentPreset) {
        "ocean" -> Quadruple(OceanPrimaryLight, OceanContainerLight, OceanPrimaryDark, OceanContainerDark)
        "amber" -> Quadruple(AmberPrimaryLight, AmberContainerLight, AmberPrimaryDark, AmberContainerDark)
        "violet" -> Quadruple(VioletPrimaryLight, VioletContainerLight, VioletPrimaryDark, VioletContainerDark)
        else -> Quadruple(LightPrimaryEmerald, LightPrimaryContainerEmerald, DarkPrimaryEmerald, DarkPrimaryContainerEmerald)
    }

    val colorScheme = if (useDark) {
        darkColorScheme(
            primary = darkPrimary,
            onPrimary = DarkBackground,
            primaryContainer = darkContainer,
            onPrimaryContainer = DarkOnBackground,
            secondary = DarkPrimaryEmerald,
            onSecondary = DarkBackground,
            secondaryContainer = DarkSurfaceVariant,
            onSecondaryContainer = DarkOnSurface,
            tertiary = InfoBlueDark,
            background = DarkBackground,
            onBackground = DarkOnBackground,
            surface = DarkSurface,
            onSurface = DarkOnSurface,
            surfaceVariant = DarkSurfaceVariant,
            onSurfaceVariant = DarkSecondaryText,
            outline = DarkOutline,
            outlineVariant = DarkSurfaceVariant,
            error = ExpenseCoralDark,
            onError = DarkBackground,
            errorContainer = ExpenseBgDark,
            onErrorContainer = ExpenseCoralDark
        )
    } else {
        lightColorScheme(
            primary = lightPrimary,
            onPrimary = Color.White,
            primaryContainer = lightContainer,
            onPrimaryContainer = LightOnBackground,
            secondary = LightPrimaryEmerald,
            onSecondary = Color.White,
            secondaryContainer = LightSurfaceVariant,
            onSecondaryContainer = LightOnSurface,
            tertiary = InfoBlueLight,
            background = LightBackground,
            onBackground = LightOnBackground,
            surface = LightSurface,
            onSurface = LightOnSurface,
            surfaceVariant = LightSurfaceVariant,
            onSurfaceVariant = LightSecondaryText,
            outline = LightOutline,
            outlineVariant = LightSurfaceVariant,
            error = ExpenseCoralLight,
            onError = Color.White,
            errorContainer = ExpenseBgLight,
            onErrorContainer = ExpenseCoralLight
        )
    }

    val scaleMultiplier = when (textScale) {
        "small" -> 0.90f
        "large" -> 1.12f
        "xlarge" -> 1.24f
        else -> 1.0f
    }

    val isCompact = density == "compact"
    val tokens = OvozTokens(
        isDark = useDark,
        income = if (useDark) IncomeGreenDark else IncomeGreenLight,
        incomeBg = if (useDark) IncomeBgDark else IncomeBgLight,
        expense = if (useDark) ExpenseCoralDark else ExpenseCoralLight,
        expenseBg = if (useDark) ExpenseBgDark else ExpenseBgLight,
        warning = if (useDark) WarningAmberDark else WarningAmberLight,
        warningBg = if (useDark) WarningBgDark else WarningBgLight,
        info = if (useDark) InfoBlueDark else InfoBlueLight,
        infoBg = if (useDark) InfoBgDark else InfoBgLight,
        debt = if (useDark) DebtPurpleDark else DebtPurpleLight,
        debtBg = if (useDark) DebtBgDark else DebtBgLight,
        cardBorder = if (useDark) DarkOutline else LightOutline,
        mutedText = if (useDark) DarkSecondaryText else LightMutedGray,
        cardPadding = if (isCompact) 12.dp else 16.dp,
        sectionSpacing = if (isCompact) 12.dp else 18.dp,
        itemSpacing = if (isCompact) 8.dp else 12.dp
    )

    CompositionLocalProvider(LocalOvozTokens provides tokens) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = buildOvozTypography(scaleMultiplier),
            shapes = OvozShapes,
            content = content
        )
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

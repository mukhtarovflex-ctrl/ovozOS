package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.core.AppStrings
import com.example.core.Formatters
import com.example.data.model.DebtItem
import com.example.data.model.FinanceTransaction
import com.example.data.model.PersonItem
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.example.ui.components.OvozCard
import com.example.ui.components.PersonInitialBadge
import com.example.ui.theme.LocalOvozTokens

@Composable
fun MoreHubScreen(
    strings: AppStrings,
    bottomBarPadding: Dp = 116.dp,
    onNavigate: (String) -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary

    data class MoreRowItem(
        val route: String,
        val title: String,
        val icon: ImageVector
    )

    val rows = listOf(
        MoreRowItem("people", strings.peopleTitle, Icons.Rounded.Group),
        MoreRowItem("calendar", strings.calendarTitle, Icons.Rounded.CalendarMonth),
        MoreRowItem("assistant", strings.assistantTitle, Icons.Rounded.AutoAwesome),
        MoreRowItem("reports", strings.reportsTitle, Icons.Rounded.Assessment),
        MoreRowItem("evening_review", strings.eveningReviewTitle, Icons.Rounded.DarkMode),
        MoreRowItem("history", strings.actionHistoryTitle, Icons.Rounded.History),
        MoreRowItem("settings", strings.settingsTitle, Icons.Rounded.Settings)
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("more_hub_screen"),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 14.dp, bottom = bottomBarPadding),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = strings.navMore,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, tokens.cardBorder)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    rows.forEachIndexed { idx, row ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .clickable { onNavigate(row.route) }
                                .padding(horizontal = 16.dp, vertical = 14.dp)
                                .testTag("hub_${row.route}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = row.icon,
                                contentDescription = null,
                                tint = primary,
                                modifier = Modifier.size(21.dp)
                            )
                            Spacer(Modifier.width(14.dp))
                            Text(
                                text = row.title,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Icon(
                                imageVector = Icons.Rounded.ChevronRight,
                                contentDescription = null,
                                tint = tokens.mutedText,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        if (idx < rows.lastIndex) {
                            HorizontalDivider(
                                color = tokens.cardBorder.copy(alpha = 0.7f),
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PeopleScreen(
    profile: UserProfile,
    people: List<PersonItem>,
    debts: List<DebtItem>,
    tasks: List<TaskItem>,
    expenses: List<FinanceTransaction>,
    onBack: () -> Unit,
    onAddPerson: (String, String, String) -> Unit,
    onDeletePerson: (PersonItem) -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    val hidden = profile.hideBalances

    var selectedPerson by remember { mutableStateOf<PersonItem?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("people_screen")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Orqaga")
                }
                Text("Insonlar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = { showAddDialog = true },
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 9.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier.padding(end = 8.dp)
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Qo‘shish", style = MaterialTheme.typography.labelLarge)
            }
        }

        if (people.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Insonlar yo‘q",
                    style = MaterialTheme.typography.bodyLarge,
                    color = tokens.mutedText
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 36.dp)
            ) {
                itemsIndexed(people, key = { _, p -> p.id }) { idx, person ->
                    val pDebts = debts.filter { it.personId == person.id || it.personName.equals(person.name, true) }
                    val pTasks = tasks.filter { it.personId == person.id || it.personName.equals(person.name, true) }
                    val activeLent = pDebts.filter { !it.closed && it.direction == "lent" }.sumOf { it.remainingAmount }
                    val activeBorrowed = pDebts.filter { !it.closed && it.direction == "borrowed" }.sumOf { it.remainingAmount }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedPerson = person }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PersonInitialBadge(name = person.name, colorKey = person.avatarColor, size = 42.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(person.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                            val meta = buildList {
                                if (person.phone.isNotBlank()) add(person.phone)
                                if (pDebts.isNotEmpty()) add("${pDebts.size} qarz")
                                if (pTasks.isNotEmpty()) add("${pTasks.size} vazifa")
                            }.joinToString(" · ")
                            if (meta.isNotEmpty()) {
                                Text(
                                    meta,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = tokens.mutedText,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            if (activeLent > 0) {
                                Text(
                                    if (hidden) "•••" else "+${Formatters.formatNumber(activeLent)}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = tokens.income,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            if (activeBorrowed > 0) {
                                Text(
                                    if (hidden) "•••" else "-${Formatters.formatNumber(activeBorrowed)}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = tokens.expense,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                    if (idx < people.lastIndex) {
                        HorizontalDivider(color = tokens.cardBorder.copy(alpha = 0.65f))
                    }
                }
            }
        }
    }

    selectedPerson?.let { person ->
        val pDebts = debts.filter { it.personId == person.id || it.personName.equals(person.name, true) }
        val pTasks = tasks.filter { it.personId == person.id || it.personName.equals(person.name, true) }
        val pExp = expenses.filter { it.personId == person.id || it.personName.equals(person.name, true) }

        ModalBottomSheet(onDismissRequest = { selectedPerson = null }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PersonInitialBadge(name = person.name, colorKey = person.avatarColor, size = 48.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(person.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        if (person.phone.isNotBlank()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Phone, contentDescription = null, modifier = Modifier.size(14.dp), tint = tokens.mutedText)
                                Spacer(Modifier.width(4.dp))
                                Text(person.phone, style = MaterialTheme.typography.bodySmall, color = tokens.mutedText)
                            }
                        }
                    }
                    IconButton(onClick = {
                        onDeletePerson(person)
                        selectedPerson = null
                    }) {
                        Icon(Icons.Rounded.DeleteOutline, contentDescription = "O‘chirish", tint = tokens.expense)
                    }
                }

                if (pDebts.isNotEmpty()) {
                    Text("Oldi-berdi (${pDebts.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    pDebts.forEach { d ->
                        OvozCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(if (d.direction == "lent") "Men bergan" else "Men olgan", style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        if (d.closed) "Yopilgan" else "Qoldiq: ${Formatters.formatMoney(d.remainingAmount, d.currency, hidden)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = tokens.mutedText
                                    )
                                }
                                Text(Formatters.formatMoney(d.originalAmount, d.currency, hidden), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                if (pTasks.isNotEmpty()) {
                    Text("Vazifalar (${pTasks.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    pTasks.forEach { t ->
                        Text("• ${t.title} ${if (t.completed) "✓" else ""}", style = MaterialTheme.typography.bodyMedium)
                    }
                }

                if (pExp.isNotEmpty()) {
                    Text("Xarajatlar (${pExp.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    pExp.take(6).forEach { tx ->
                        Text(
                            "• ${tx.title} — ${Formatters.formatMoney(tx.amount, tx.currency, hidden)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                if (pDebts.isEmpty() && pTasks.isEmpty() && pExp.isEmpty()) {
                    Text("Bog‘langan yozuvlar yo‘q.", style = MaterialTheme.typography.bodyMedium, color = tokens.mutedText)
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showAddDialog) {
        var name by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Yangi inson") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Ismi") }, singleLine = true)
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Telefon (ixtiyoriy)") }, singleLine = true)
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Izoh") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(
                    enabled = name.trim().isNotEmpty(),
                    onClick = {
                        onAddPerson(name.trim(), phone.trim(), note.trim())
                        showAddDialog = false
                    }
                ) { Text("Saqlash", fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("Bekor qilish") } }
        )
    }
}

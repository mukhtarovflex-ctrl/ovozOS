package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Handshake
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.AppStrings
import com.example.core.Formatters
import com.example.data.model.LiveEntityCue
import com.example.data.model.LiveEntityType
import com.example.data.model.ParsedAction
import com.example.data.model.ParsedActionType
import com.example.data.model.VoiceStage
import com.example.data.model.VoiceUiState
import com.example.ui.components.OvozCard
import com.example.ui.components.OvozPrimaryButton
import com.example.ui.theme.LocalOvozTokens
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.PI
import kotlin.math.sin

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceAssistantOverlay(
    state: VoiceUiState,
    waveformFlow: StateFlow<List<Float>>,
    strings: AppStrings,
    onClose: () -> Unit,
    onStartRecording: () -> Unit,
    onStopRecording: () -> Unit,
    onLocaleChange: (String) -> Unit,
    onManualTextChange: (String) -> Unit,
    onAnalyzeText: (String) -> Unit,
    onToggleAction: (String) -> Unit,
    onRemoveAction: (String) -> Unit,
    onUpdateAction: (ParsedAction) -> Unit,
    onSaveAll: () -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    var editingAction by remember { mutableStateOf<ParsedAction?>(null) }
    var clarifyReply by remember { mutableStateOf("") }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .testTag("voice_assistant_overlay"),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .imePadding()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Top bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Rounded.GraphicEq,
                            contentDescription = null,
                            tint = primary,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "OvozOS Yordamchi",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = formatDuration(state.elapsedSeconds),
                            style = MaterialTheme.typography.labelSmall,
                            color = if (state.stage == VoiceStage.LISTENING || state.stage == VoiceStage.TRANSCRIBING) {
                                primary
                            } else tokens.mutedText
                        )
                    }
                }

                // Language quick toggle
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("auto" to "Avto", "uz-UZ" to "UZ", "ru-RU" to "RU", "en-US" to "EN").forEach { (code, lbl) ->
                        val active = state.speechLocale == code
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (active) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onLocaleChange(code) }
                        ) {
                            Text(
                                text = lbl,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (active) primary else tokens.mutedText,
                                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }
                    }
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.testTag("voice_close_button")
                    ) {
                        Icon(Icons.Rounded.Close, contentDescription = "Yopish")
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // REAL-TIME 4-STAGE AI PIPELINE PROGRESS INDICATOR
            VoicePipelineStepper(stage = state.stage, strings = strings)

            Spacer(Modifier.height(12.dp))

            // Main scrollable body
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // REAL-TIME ANIMATED SOUNDWAVE VISUALIZER (isolated recomposition scope)
                LiveVoiceWaveformStage(
                    stage = state.stage,
                    waveformFlow = waveformFlow,
                    elapsedSeconds = state.elapsedSeconds
                )

                // LIVE SPEECH-TO-TEXT TRANSCRIPT + EDITABLE INPUT
                OvozCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = when (state.stage) {
                                    VoiceStage.LISTENING -> "Tinglanmoqda — erkin gapiring..."
                                    VoiceStage.TRANSCRIBING -> "Jonli matnga aylanmoqda..."
                                    VoiceStage.ANALYZING -> "Gemini mazmunni tahlil qilmoqda..."
                                    else -> "Ovozli matn yoki buyruq"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = primary,
                                fontWeight = FontWeight.SemiBold
                            )
                            if (state.stage == VoiceStage.ANALYZING) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = primary
                                )
                            }
                        }

                        if (state.stage == VoiceStage.ANALYZING) {
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(CircleShape),
                                color = primary,
                                trackColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        }

                        Spacer(Modifier.height(8.dp))
                        val isActivelyRecording = state.stage == VoiceStage.LISTENING || state.stage == VoiceStage.TRANSCRIBING
                        if (isActivelyRecording) {
                            // Lightweight zero-lag live caption surface during active speech recognition
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                border = BorderStroke(1.dp, primary.copy(alpha = 0.45f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("voice_live_caption")
                            ) {
                                Text(
                                    text = if (state.transcript.isNotBlank()) {
                                        "${state.transcript} ▍"
                                    } else {
                                        "Gapiring, so‘zlaringiz darhol shu yerda ko‘rinadi..."
                                    },
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = if (state.transcript.isNotBlank()) {
                                        MaterialTheme.colorScheme.onSurface
                                    } else {
                                        tokens.mutedText
                                    },
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp)
                                )
                            }
                        } else {
                            OutlinedTextField(
                                value = state.transcript,
                                onValueChange = onManualTextChange,
                                placeholder = {
                                    Text(
                                        "Masalan: «Bugun Anvardan 500 ming qarz oldim, tushlikka 60 ming ketdi, ertaga soat 10:00 da hisobot topshirishim kerak»",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = tokens.mutedText
                                    )
                                },
                                minLines = 2,
                                maxLines = 5,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("voice_transcript_input")
                            )
                        }

                        // REAL-TIME RECOGNIZED ENTITY CUES (Amounts, Dates, People, Tasks, Goals, Debts)
                        AnimatedVisibility(
                            visible = state.liveEntityCues.isNotEmpty(),
                            enter = fadeIn() + slideInVertically { it / 2 },
                            exit = fadeOut()
                        ) {
                            Column(modifier = Modifier.padding(top = 12.dp)) {
                                Text(
                                    text = "Aniqlangan ma’lumotlar",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = tokens.mutedText
                                )
                                Spacer(Modifier.height(6.dp))
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    state.liveEntityCues.forEach { cue ->
                                        EntityCuePill(cue = cue)
                                    }
                                }
                            }
                        }
                    }
                }

                // Error state with clear retry
                if (state.errorMessage.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.errorContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = state.errorMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = {
                                if (state.transcript.isNotBlank()) onAnalyzeText(state.transcript)
                                else onStartRecording()
                            }) {
                                Text(strings.retry, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Clarifying Question from Gemini
                if (state.stage == VoiceStage.CLARIFYING && state.clarificationQuestion.isNotBlank()) {
                    OvozCard(
                        containerColor = tokens.warningBg,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Rounded.AutoAwesome,
                                    contentDescription = null,
                                    tint = tokens.warning,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "Aniqlashtirish kerak",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = tokens.warning
                                )
                            }
                            Text(
                                text = state.clarificationQuestion,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = clarifyReply,
                                    onValueChange = { clarifyReply = it },
                                    placeholder = { Text("Aniqlashtiruvchi javob...") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = {
                                        if (clarifyReply.isNotBlank()) {
                                            val merged = "${state.transcript}. Aniqlashtirish: $clarifyReply"
                                            clarifyReply = ""
                                            onAnalyzeText(merged)
                                        }
                                    }
                                ) {
                                    Icon(Icons.Rounded.Send, contentDescription = "Yuborish", tint = primary)
                                }
                            }
                        }
                    }
                }

                // Direct AI Answer (when user asks a question via central mic)
                if (state.stage == VoiceStage.ANSWERING && state.assistantReply.isNotBlank()) {
                    OvozCard(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Rounded.AutoAwesome,
                                    contentDescription = null,
                                    tint = primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "OvozOS javobi",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = primary
                                )
                            }
                            Text(
                                text = state.assistantReply,
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                    }
                }

                // EXTRACTED MULTI-INTENT ACTION CARDS
                if (state.parsedActions.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Aniqlangan amallar (${state.parsedActions.count { it.selected }})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Tahrirlash yoki olib tashlash mumkin",
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.mutedText
                        )
                    }

                    state.parsedActions.forEach { action ->
                        ParsedActionCard(
                            action = action,
                            onToggle = { onToggleAction(action.localId) },
                            onEdit = { editingAction = action },
                            onRemove = { onRemoveAction(action.localId) }
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
            }

            // Bottom Action Controls
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (state.parsedActions.any { it.selected } &&
                    (state.stage == VoiceStage.REVIEW || state.stage == VoiceStage.CLARIFYING)
                ) {
                    OvozPrimaryButton(
                        text = "${strings.saveAll} (${state.parsedActions.count { it.selected }})",
                        icon = Icons.Rounded.Check,
                        loading = state.isSaving,
                        onClick = onSaveAll,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("voice_save_all_button")
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val isListening = state.stage == VoiceStage.LISTENING || state.stage == VoiceStage.TRANSCRIBING

                    if (isListening) {
                        OvozPrimaryButton(
                            text = strings.voiceStop,
                            icon = Icons.Rounded.Stop,
                            onClick = onStopRecording,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("voice_stop_button")
                        )
                    } else {
                        OvozPrimaryButton(
                            text = if (state.transcript.isBlank()) "Gapirishni boshlash" else strings.voiceRetry,
                            icon = if (state.transcript.isBlank()) Icons.Rounded.Mic else Icons.Rounded.Refresh,
                            onClick = onStartRecording,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("voice_record_button")
                        )
                        if (state.transcript.isNotBlank() && state.stage != VoiceStage.ANALYZING) {
                            OutlinedButton(
                                onClick = { onAnalyzeText(state.transcript) },
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .height(50.dp)
                                    .testTag("voice_analyze_button")
                            ) {
                                Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Tahlil")
                            }
                        }
                    }
                }
            }
        }
    }

    editingAction?.let { act ->
        EditParsedActionDialog(
            action = act,
            onDismiss = { editingAction = null },
            onSave = { updated ->
                onUpdateAction(updated)
                editingAction = null
            }
        )
    }
}

@Composable
private fun VoicePipelineStepper(
    stage: VoiceStage,
    strings: AppStrings
) {
    val activeStep = when (stage) {
        VoiceStage.IDLE, VoiceStage.ERROR -> -1
        VoiceStage.LISTENING -> 0
        VoiceStage.TRANSCRIBING -> 1
        VoiceStage.ANALYZING -> 2
        VoiceStage.REVIEW, VoiceStage.CLARIFYING, VoiceStage.ANSWERING -> 3
    }
    val steps = listOf(
        strings.voiceListening,
        strings.voiceTranscribing,
        strings.voiceAnalyzing,
        strings.voiceReady
    )
    val primary = MaterialTheme.colorScheme.primary
    val tokens = LocalOvozTokens.current

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        steps.forEachIndexed { idx, label ->
            val reached = idx <= activeStep
            val current = idx == activeStep
            val barColor by animateColorAsState(
                targetValue = when {
                    reached -> primary
                    else -> MaterialTheme.colorScheme.surfaceVariant
                },
                animationSpec = tween(260),
                label = "step_bar_$idx"
            )
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(CircleShape)
                        .background(barColor)
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (current) primary else if (reached) MaterialTheme.colorScheme.onSurface else tokens.mutedText,
                    fontWeight = if (current) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun LiveVoiceWaveformStage(
    stage: VoiceStage,
    waveformFlow: StateFlow<List<Float>>,
    elapsedSeconds: Int
) {
    val waveformHistory by waveformFlow.collectAsStateWithLifecycle()
    val latestAmp = waveformHistory.lastOrNull() ?: 0.14f
    val primary = MaterialTheme.colorScheme.primary
    val container = MaterialTheme.colorScheme.primaryContainer
    val isLive = stage == VoiceStage.LISTENING || stage == VoiceStage.TRANSCRIBING
    val isAnalyzing = stage == VoiceStage.ANALYZING

    val infinite = rememberInfiniteTransition(label = "voice_wave_anim")
    val phase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isAnalyzing) 1200 else 1900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )
    val animatedAmp by animateFloatAsState(
        targetValue = when {
            isLive -> latestAmp.coerceIn(0.25f, 1.0f)
            isAnalyzing -> 0.55f
            else -> 0.14f
        },
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "rms_amp"
    )

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(142.dp),
        shape = RoundedCornerShape(24.dp),
        color = container.copy(alpha = if (LocalOvozTokens.current.isDark) 0.40f else 0.55f),
        border = BorderStroke(1.dp, primary.copy(alpha = if (isLive || isAnalyzing) 0.45f else 0.18f))
    ) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 14.dp)) {
                val midY = size.height / 2f

                // Flowing harmonic sine ribbon behind bars
                val ribbonPath = Path()
                val samples = 64
                for (i in 0..samples) {
                    val x = (i / samples.toFloat()) * size.width
                    val normX = i / samples.toFloat()
                    val envelope = sin(normX * PI).toFloat()
                    val yOffset = sin(normX * 4f * PI + phase).toFloat() * (size.height * 0.34f * animatedAmp * envelope)
                    if (i == 0) ribbonPath.moveTo(x, midY + yOffset)
                    else ribbonPath.lineTo(x, midY + yOffset)
                }
                drawPath(
                    path = ribbonPath,
                    color = primary.copy(alpha = 0.24f),
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )

                // Live responsive vertical spectrum bars
                val count = waveformHistory.size.coerceAtLeast(24)
                val barW = (size.width / (count * 1.9f)).coerceIn(4.dp.toPx(), 8.dp.toPx())
                val spacing = (size.width - barW * count) / (count - 1).coerceAtLeast(1)

                for (i in 0 until count) {
                    val x = i * (barW + spacing)
                    val centerEnvelope = sin((i.toFloat() / (count - 1)) * PI).toFloat().coerceAtLeast(0.22f)
                    val histVal = waveformHistory.getOrElse(i) { 0.15f }
                    val waveMod = 0.5f + 0.5f * sin(phase * 1.4f + i * 0.45f).toFloat()
                    val heightFactor = when {
                        isLive -> (histVal * 0.65f + waveMod * animatedAmp * 0.45f) * centerEnvelope
                        isAnalyzing -> (0.25f + 0.55f * waveMod) * centerEnvelope
                        else -> 0.14f + 0.10f * centerEnvelope
                    }.coerceIn(0.10f, 0.96f)
                    val barH = size.height * heightFactor
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(primary, primary.copy(alpha = 0.65f))
                        ),
                        topLeft = Offset(x, midY - barH / 2f),
                        size = Size(barW, barH),
                        cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                    )
                }
            }

            // Status pill overlay in top-right of visualizer
            AnimatedContent(
                targetState = stage,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp),
                label = "stage_pill"
            ) { st ->
                val pillText = when (st) {
                    VoiceStage.LISTENING -> "● Yozilmoqda ${formatDuration(elapsedSeconds)}"
                    VoiceStage.TRANSCRIBING -> "● Matnga o‘girilmoqda"
                    VoiceStage.ANALYZING -> "✦ Gemini tahlil qilmoqda"
                    VoiceStage.REVIEW -> "✓ Tayyor"
                    VoiceStage.CLARIFYING -> "? Aniqlashtirish"
                    VoiceStage.ANSWERING -> "✦ Javob tayyor"
                    else -> "Tayyor"
                }
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
                ) {
                    Text(
                        text = pillText,
                        style = MaterialTheme.typography.labelSmall,
                        color = primary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun EntityCuePill(cue: LiveEntityCue) {
    val tokens = LocalOvozTokens.current
    val (bg, fg, icon, prefix) = when (cue.type) {
        LiveEntityType.AMOUNT -> Quad(tokens.incomeBg, tokens.income, Icons.Rounded.Payments, "Summa")
        LiveEntityType.DATE_TIME -> Quad(tokens.infoBg, tokens.info, Icons.Rounded.CalendarMonth, "Vaqt")
        LiveEntityType.PERSON -> Quad(tokens.debtBg, tokens.debt, Icons.Rounded.Person, "Inson")
        LiveEntityType.TASK -> Quad(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.primary, Icons.Rounded.TaskAlt, "Vazifa")
        LiveEntityType.DEBT -> Quad(tokens.expenseBg, tokens.expense, Icons.Rounded.Handshake, "Qarz")
        else -> Quad(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.primary, Icons.Rounded.TaskAlt, "Amal")
    }

    AnimatedVisibility(
        visible = true,
        enter = scaleIn(spring(stiffness = Spring.StiffnessMedium)) + fadeIn()
    ) {
        Surface(
            shape = RoundedCornerShape(999.dp),
            color = bg,
            border = BorderStroke(1.dp, fg.copy(alpha = 0.30f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(14.dp))
                Text(
                    text = "$prefix: ${cue.label}",
                    style = MaterialTheme.typography.labelSmall,
                    color = fg,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun ParsedActionCard(
    action: ParsedAction,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onRemove: () -> Unit
) {
    val tokens = LocalOvozTokens.current
    val (badgeLabel, accentColor, bgColor, icon) = when (action.type) {
        ParsedActionType.CREATE_TASK -> Quad("Yangi vazifa", MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.primaryContainer, Icons.Rounded.TaskAlt)
        ParsedActionType.COMPLETE_TASK -> Quad("Bajarildi", tokens.income, tokens.incomeBg, Icons.Rounded.CheckCircle)
        ParsedActionType.CREATE_EXPENSE -> Quad("Xarajat", tokens.expense, tokens.expenseBg, Icons.Rounded.AccountBalanceWallet)
        ParsedActionType.CREATE_DEBT_BORROWED -> Quad("Olingan qarz", tokens.debt, tokens.debtBg, Icons.Rounded.Handshake)
        ParsedActionType.CREATE_DEBT_LENT -> Quad("Berilgan qarz", tokens.warning, tokens.warningBg, Icons.Rounded.Handshake)
        ParsedActionType.PAY_DEBT -> Quad("Qarz to‘lovi", tokens.income, tokens.incomeBg, Icons.Rounded.Payments)
        else -> Quad("Amal", MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.primaryContainer, Icons.Rounded.AutoAwesome)
    }

    OvozCard(
        modifier = Modifier.fillMaxWidth(),
        containerColor = if (action.selected) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = action.selected,
                onCheckedChange = { onToggle() }
            )
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(bgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = badgeLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = accentColor,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = action.title,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                val details = buildList {
                    if (action.amount > 0.0) {
                        add(Formatters.formatMoney(action.amount, action.currency))
                    }
                    if (action.personName.isNotBlank()) add(action.personName)
                    if (action.category.isNotBlank()) add(action.category)
                    if (action.dueDateMillis > 0L) {
                        add(
                            if (action.hasDueTime) Formatters.formatDateTime24(action.dueDateMillis)
                            else Formatters.formatShortDate(action.dueDateMillis)
                        )
                    }
                }.joinToString(" • ")
                if (details.isNotBlank()) {
                    Text(
                        text = details,
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.mutedText,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            IconButton(onClick = onEdit) {
                Icon(Icons.Rounded.Edit, contentDescription = "Tahrirlash", modifier = Modifier.size(19.dp))
            }
            IconButton(onClick = onRemove) {
                Icon(
                    Icons.Rounded.DeleteOutline,
                    contentDescription = "Olib tashlash",
                    tint = tokens.expense,
                    modifier = Modifier.size(19.dp)
                )
            }
        }
    }
}

@Composable
private fun EditParsedActionDialog(
    action: ParsedAction,
    onDismiss: () -> Unit,
    onSave: (ParsedAction) -> Unit
) {
    var title by remember { mutableStateOf(action.title) }
    var amountText by remember { mutableStateOf(if (action.amount > 0) action.amount.toLong().toString() else "") }
    var category by remember { mutableStateOf(action.category) }
    var person by remember { mutableStateOf(action.personName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Amalni tahrirlash") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Nomi") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (action.type in listOf(
                        ParsedActionType.CREATE_EXPENSE,
                        ParsedActionType.CREATE_DEBT_BORROWED,
                        ParsedActionType.CREATE_DEBT_LENT,
                        ParsedActionType.PAY_DEBT
                    )
                ) {
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
                        label = { Text("Miqdor (${action.currency})") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Turkum") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = person,
                    onValueChange = { person = it },
                    label = { Text("Bog‘langan inson") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    action.copy(
                        title = title.trim().ifEmpty { action.title },
                        amount = amountText.toDoubleOrNull() ?: action.amount,
                        category = category.trim().ifEmpty { action.category },
                        personName = person.trim()
                    )
                )
            }) {
                Text("Saqlash", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Bekor qilish") }
        }
    )
}

private fun formatDuration(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return "%02d:%02d".format(m, s)
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

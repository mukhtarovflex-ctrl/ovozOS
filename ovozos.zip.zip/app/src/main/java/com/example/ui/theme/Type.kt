package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

val ManropeFontFamily = FontFamily(
    Font(R.font.manrope, FontWeight.Normal),
    Font(R.font.manrope, FontWeight.Medium),
    Font(R.font.manrope, FontWeight.SemiBold),
    Font(R.font.manrope, FontWeight.Bold),
    Font(R.font.manrope, FontWeight.ExtraBold)
)

val InterFontFamily = FontFamily(
    Font(R.font.inter, FontWeight.Normal),
    Font(R.font.inter, FontWeight.Medium),
    Font(R.font.inter, FontWeight.SemiBold),
    Font(R.font.inter, FontWeight.Bold)
)

fun buildOvozTypography(scaleMultiplier: Float = 1.0f): Typography {
    fun s(base: Float) = (base * scaleMultiplier).sp
    return Typography(
        displayLarge = TextStyle(
            fontFamily = ManropeFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = s(36f),
            lineHeight = s(44f),
            letterSpacing = (-0.5).sp
        ),
        displayMedium = TextStyle(
            fontFamily = ManropeFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = s(30f),
            lineHeight = s(36f),
            letterSpacing = (-0.3).sp
        ),
        displaySmall = TextStyle(
            fontFamily = ManropeFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = s(24f),
            lineHeight = s(32f)
        ),
        headlineLarge = TextStyle(
            fontFamily = ManropeFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = s(22f),
            lineHeight = s(28f),
            letterSpacing = (-0.2).sp
        ),
        headlineMedium = TextStyle(
            fontFamily = ManropeFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = s(19f),
            lineHeight = s(25f)
        ),
        headlineSmall = TextStyle(
            fontFamily = ManropeFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = s(17f),
            lineHeight = s(22f)
        ),
        titleLarge = TextStyle(
            fontFamily = ManropeFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = s(17f),
            lineHeight = s(23f)
        ),
        titleMedium = TextStyle(
            fontFamily = ManropeFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = s(15f),
            lineHeight = s(20f)
        ),
        titleSmall = TextStyle(
            fontFamily = InterFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = s(13.5f),
            lineHeight = s(18f)
        ),
        bodyLarge = TextStyle(
            fontFamily = InterFontFamily,
            fontWeight = FontWeight.Normal,
            fontSize = s(15.5f),
            lineHeight = s(22f)
        ),
        bodyMedium = TextStyle(
            fontFamily = InterFontFamily,
            fontWeight = FontWeight.Normal,
            fontSize = s(14f),
            lineHeight = s(20f)
        ),
        bodySmall = TextStyle(
            fontFamily = InterFontFamily,
            fontWeight = FontWeight.Normal,
            fontSize = s(12.5f),
            lineHeight = s(17f)
        ),
        labelLarge = TextStyle(
            fontFamily = InterFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = s(13.5f),
            lineHeight = s(18f)
        ),
        labelMedium = TextStyle(
            fontFamily = InterFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = s(12f),
            lineHeight = s(16f)
        ),
        labelSmall = TextStyle(
            fontFamily = InterFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = s(11f),
            lineHeight = s(14f)
        )
    )
}

package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Handshake
import androidx.compose.material.icons.rounded.NextPlan
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.core.Formatters
import com.example.data.model.DailyReviewItem
import com.example.data.model.DebtItem
import com.example.data.model.FinanceTransaction
import com.example.data.model.PersonItem
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.example.ui.components.OvozCard
import com.example.ui.components.OvozPrimaryButton
import com.example.ui.components.OvozProgressRing
import com.example.ui.theme.LocalOvozTokens
import com.example.ui.viewmodel.ReportUiState
import java.util.Calendar

@Composable
fun CalendarScreen(
    profile: UserProfile,
    tasks: List<TaskItem>,
    debts: List<DebtItem>,
    people: List<PersonItem>,
    onBack: () -> Unit,
    onAddTask: (TaskItem) -> Unit,
    onToggleTask: (TaskItem) -> Unit,
    onRescheduleTomorrow: (TaskItem) -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary

    var viewMode by remember { mutableStateOf("month") } // day, week, month, agenda
    var selectedDateMillis by remember { mutableLongStateOf(Formatters.startOfDay()) }
    var displayedMonthOffset by remember { mutableIntStateOf(0) }
    var showAddTaskSheet by remember { mutableStateOf(false) }

    val monthCal = remember(displayedMonthOffset) {
        Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            add(Calendar.MONTH, displayedMonthOffset)
        }
    }
    val monthNames = arrayOf(
        "Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun",
        "Iyul", "Avgust", "Sentyabr", "Oktyabr", "Noyabr", "Dekabr"
    )
    val monthHeader = "${monthNames[monthCal.get(Calendar.MONTH)]} ${monthCal.get(Calendar.YEAR)}"

    val dayTasks = remember(tasks, selectedDateMillis) {
        tasks.filter { Formatters.isSameDay(it.dueDateMillis, selectedDateMillis) }
    }
    val dayDebts = remember(debts, selectedDateMillis) {
        debts.filter { !it.closed && Formatters.isSameDay(it.dueDateMillis, selectedDateMillis) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("calendar_screen"),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Orqaga") }
                    Text("Taqvim", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = {
                        displayedMonthOffset = 0
                        selectedDateMillis = Formatters.startOfDay()
                    }) {
                        Icon(Icons.Rounded.Today, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Bugun")
                    }
                    IconButton(onClick = { showAddTaskSheet = true }) {
                        Icon(Icons.Rounded.Add, contentDescription = "Vazifa qo‘shish", tint = primary)
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("day" to "Kun", "week" to "Hafta", "month" to "Oy", "agenda" to "Rejalar").forEach { (k, l) ->
                    FilterChip(selected = viewMode == k, onClick = { viewMode = k }, label = { Text(l) })
                }
            }
        }

        if (viewMode == "month") {
            item {
                OvozCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { displayedMonthOffset-- }) {
                                Icon(Icons.Rounded.ChevronLeft, contentDescription = "Oldingi oy")
                            }
                            Text(monthHeader, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            IconButton(onClick = { displayedMonthOffset++ }) {
                                Icon(Icons.Rounded.ChevronRight, contentDescription = "Keyingi oy")
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth()) {
                            listOf("Du", "Se", "Ch", "Pa", "Ju", "Sh", "Ya").forEach { d ->
                                Text(
                                    d,
                                    modifier = Modifier.weight(1f),
                                    textAlign = TextAlign.Center,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = tokens.mutedText
                                )
                            }
                        }

                        val daysInMonth = monthCal.getActualMaximum(Calendar.DAY_OF_MONTH)
                        val firstDow = (monthCal.get(Calendar.DAY_OF_WEEK) + 5) % 7
                        val totalCells = ((firstDow + daysInMonth + 6) / 7) * 7

                        for (row in 0 until (totalCells / 7)) {
                            Row(modifier = Modifier.fillMaxWidth()) {
                                for (col in 0 until 7) {
                                    val cellIdx = row * 7 + col
                                    val dayNum = cellIdx - firstDow + 1
                                    if (dayNum in 1..daysInMonth) {
                                        val c = (monthCal.clone() as Calendar).apply {
                                            set(Calendar.DAY_OF_MONTH, dayNum)
                                            set(Calendar.HOUR_OF_DAY, 0)
                                            set(Calendar.MINUTE, 0)
                                            set(Calendar.SECOND, 0)
                                            set(Calendar.MILLISECOND, 0)
                                        }
                                        val ms = c.timeInMillis
                                        val isSelected = Formatters.isSameDay(ms, selectedDateMillis)
                                        val isToday = Formatters.isToday(ms)
                                        val hasTask = tasks.any { Formatters.isSameDay(it.dueDateMillis, ms) }
                                        val hasDebt = debts.any { !it.closed && Formatters.isSameDay(it.dueDateMillis, ms) }

                                        Column(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(
                                                    when {
                                                        isSelected -> primary
                                                        isToday -> MaterialTheme.colorScheme.primaryContainer
                                                        else -> Color.Transparent
                                                    }
                                                )
                                                .clickable { selectedDateMillis = ms }
                                                .padding(vertical = 7.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(
                                                text = "$dayNum",
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                            )
                                            Spacer(Modifier.height(3.dp))
                                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                                if (hasTask) Box(Modifier.size(4.dp).clip(CircleShape).background(if (isSelected) Color.White else primary))
                                                if (hasDebt) Box(Modifier.size(4.dp).clip(CircleShape).background(if (isSelected) Color.White else tokens.debt))
                                            }
                                        }
                                    } else {
                                        Spacer(Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else if (viewMode == "week") {
            item {
                val startOfWeek = Formatters.startOfDay(selectedDateMillis)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (offset in -2..4) {
                        val ms = startOfWeek + offset * 86_400_000L
                        val sel = Formatters.isSameDay(ms, selectedDateMillis)
                        val cal = Calendar.getInstance().apply { timeInMillis = ms }
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { selectedDateMillis = ms },
                            shape = RoundedCornerShape(14.dp),
                            color = if (sel) primary else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, if (sel) primary else tokens.cardBorder)
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "${cal.get(Calendar.DAY_OF_MONTH)}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        if (viewMode == "agenda") {
            val upcoming = tasks.filter { it.dueDateMillis > 0L }.sortedBy { it.dueDateMillis }
            if (upcoming.isEmpty()) {
                item {
                    Text(
                        "Muddatli rejalar yo‘q",
                        style = MaterialTheme.typography.bodyMedium,
                        color = tokens.mutedText,
                        modifier = Modifier.padding(vertical = 24.dp)
                    )
                }
            } else {
                items(upcoming, key = { it.id }) { t ->
                    OvozCard(modifier = Modifier.fillMaxWidth(), onClick = { onToggleTask(t) }) {
                        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Rounded.CheckCircle,
                                contentDescription = null,
                                tint = if (t.completed) primary else tokens.mutedText,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(t.title, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    Formatters.formatDateTime24(t.dueDateMillis, profile.dateFormat, profile.language),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = primary
                                )
                            }
                        }
                    }
                }
            }
        } else {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        Formatters.formatFullDateHeader(selectedDateMillis, profile.language),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = { showAddTaskSheet = true }) {
                        Text("+ Vazifa")
                    }
                }
            }

            if (dayTasks.isEmpty() && dayDebts.isEmpty()) {
                item {
                    Text(
                        "Bu kunga vazifa yoki qarz muddati yo‘q",
                        style = MaterialTheme.typography.bodyMedium,
                        color = tokens.mutedText,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                }
            }

            items(dayTasks, key = { it.id }) { t ->
                OvozCard(modifier = Modifier.fillMaxWidth(), onClick = { onToggleTask(t) }) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(9.dp).clip(CircleShape).background(primary))
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(t.title, style = MaterialTheme.typography.titleSmall)
                            Text(
                                if (t.hasDueTime) Formatters.formatTime24(t.dueDateMillis) else t.category,
                                style = MaterialTheme.typography.labelSmall,
                                color = tokens.mutedText
                            )
                        }
                        if (!t.completed) {
                            IconButton(onClick = { onRescheduleTomorrow(t) }) {
                                Icon(Icons.Rounded.NextPlan, contentDescription = "Ertaga ko‘chirish", tint = tokens.warning)
                            }
                        }
                    }
                }
            }

            items(dayDebts, key = { it.id }) { d ->
                OvozCard(modifier = Modifier.fillMaxWidth(), containerColor = tokens.debtBg.copy(alpha = 0.5f)) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Handshake, contentDescription = null, tint = tokens.debt)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("${d.personName} — qarz muddati", style = MaterialTheme.typography.titleSmall)
                            Text(
                                Formatters.formatMoney(d.remainingAmount, d.currency, profile.hideBalances),
                                style = MaterialTheme.typography.bodySmall,
                                color = tokens.debt
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddTaskSheet) {
        TaskEditorSheet(
            initial = TaskItem(dueDateMillis = selectedDateMillis + 12L * 3_600_000L),
            people = people,
            onDismiss = { showAddTaskSheet = false },
            onSave = { created ->
                onAddTask(created.copy(id = ""))
                showAddTaskSheet = false
            }
        )
    }
}

@Composable
fun EveningReviewScreen(
    profile: UserProfile,
    tasks: List<TaskItem>,
    expenses: List<FinanceTransaction>,
    debts: List<DebtItem>,
    reviews: List<DailyReviewItem>,
    isGenerating: Boolean,
    onGenerateToday: () -> Unit,
    onMoveTaskToTomorrow: (TaskItem) -> Unit,
    onBack: () -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    val cur = profile.primaryCurrency
    val hidden = profile.hideBalances

    var step by remember { mutableIntStateOf(0) }
    val totalSteps = 4

    val todayKey = Formatters.dateKeyFor()
    val todayReview = reviews.firstOrNull { it.dateKey == todayKey }

    val todayTasks = tasks.filter {
        Formatters.isToday(it.dueDateMillis) || (it.completed && Formatters.isToday(it.completedAtMillis))
    }
    val doneToday = todayTasks.filter { it.completed }
    val pendingToday = todayTasks.filter { !it.completed }
    val pct = if (todayTasks.isNotEmpty()) (doneToday.size * 100 / todayTasks.size) else 0

    val todayExp = expenses.filter { it.currency == cur && Formatters.isToday(it.occurredAtMillis) }
    val expenseTotal = todayExp.sumOf { it.amount }
    val biggestExpense = todayExp.maxByOrNull { it.amount }
    val activeBorrowed = debts.filter { !it.closed && it.currency == cur && it.direction == "borrowed" }.sumOf { it.remainingAmount }
    val activeLent = debts.filter { !it.closed && it.currency == cur && it.direction == "lent" }.sumOf { it.remainingAmount }
    val tomorrowTasks = tasks.filter { !it.completed && Formatters.isTomorrow(it.dueDateMillis) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("evening_review_screen"),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Orqaga") }
                Column {
                    Text("Kun yakuni", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(Formatters.formatFullDateHeader(lang = profile.language), style = MaterialTheme.typography.labelSmall, color = tokens.mutedText)
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(totalSteps) { idx ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(5.dp)
                            .clip(CircleShape)
                            .background(if (idx <= step) primary else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { step = idx }
                    )
                }
            }
        }

        item {
            AnimatedContent(targetState = step, label = "review_step") { currentStep ->
                OvozCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        when (currentStep) {
                            0 -> {
                                Text("1-qadam · Bugungi vazifalar", style = MaterialTheme.typography.labelLarge, color = primary)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    OvozProgressRing(progress = pct / 100f, size = 78.dp, strokeWidth = 7.dp) {
                                        Text("$pct%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(Modifier.width(16.dp))
                                    Column {
                                        Text("${doneToday.size} ta bajarildi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                        Text("${pendingToday.size} ta qoldi", style = MaterialTheme.typography.bodyMedium, color = tokens.mutedText)
                                    }
                                }
                                if (pendingToday.isNotEmpty()) {
                                    pendingToday.forEach { t ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("• ${t.title}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                            TextButton(onClick = { onMoveTaskToTomorrow(t) }) {
                                                Text("Ertaga →")
                                            }
                                        }
                                    }
                                }
                            }
                            1 -> {
                                Text("2-qadam · Bugungi xarajatlar va qarzlar", style = MaterialTheme.typography.labelLarge, color = primary)
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    color = tokens.expenseBg
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text("Bugungi xarajatlar", style = MaterialTheme.typography.labelSmall, color = tokens.expense)
                                        Text(
                                            Formatters.formatMoney(expenseTotal, cur, hidden),
                                            style = MaterialTheme.typography.titleLarge,
                                            color = tokens.expense,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                if (biggestExpense != null) {
                                    Text(
                                        "Eng katta xarajat: ${biggestExpense.title} (${Formatters.formatMoney(biggestExpense.amount, cur, hidden)})",
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                } else {
                                    Text("Bugun xarajatlar yo‘q", style = MaterialTheme.typography.bodyMedium, color = tokens.mutedText)
                                }
                                if (activeBorrowed > 0.0 || activeLent > 0.0) {
                                    HorizontalDivider(color = tokens.cardBorder)
                                    Text(
                                        "Men qaytarishim kerak: ${Formatters.formatMoney(activeBorrowed, cur, hidden)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = tokens.mutedText
                                    )
                                    Text(
                                        "Menga qaytarishlari kerak: ${Formatters.formatMoney(activeLent, cur, hidden)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = tokens.mutedText
                                    )
                                }
                            }
                            2 -> {
                                Text("3-qadam · Ertangi rejalar", style = MaterialTheme.typography.labelLarge, color = primary)
                                if (tomorrowTasks.isEmpty()) {
                                    Text("Ertaga vazifalar rejalashtirilmagan", style = MaterialTheme.typography.bodyMedium, color = tokens.mutedText)
                                } else {
                                    tomorrowTasks.take(6).forEach {
                                        Text("• ${it.title}", style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                            else -> {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = primary)
                                    Spacer(Modifier.width(8.dp))
                                    Text("4-qadam · Kun xulosasi", style = MaterialTheme.typography.titleMedium, color = primary)
                                }
                                if (isGenerating) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                        Text("Tahlil qilinmoqda...", style = MaterialTheme.typography.bodyMedium)
                                    }
                                } else if (todayReview != null) {
                                    Text(todayReview.aiSummary, style = MaterialTheme.typography.bodyLarge)
                                    if (todayReview.tomorrowAdvice.isNotBlank()) {
                                        Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Text("Ertangi tavsiya", style = MaterialTheme.typography.labelLarge, color = primary)
                                                Spacer(Modifier.height(4.dp))
                                                Text(todayReview.tomorrowAdvice, style = MaterialTheme.typography.bodyMedium)
                                            }
                                        }
                                    }
                                    OutlinedButton(onClick = onGenerateToday) { Text("Yangilash") }
                                } else {
                                    OvozPrimaryButton(
                                        text = "Hisobotni yaratish",
                                        icon = Icons.Rounded.AutoAwesome,
                                        onClick = onGenerateToday,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            TextButton(enabled = step > 0, onClick = { step-- }) { Text("Oldingi") }
                            if (step < totalSteps - 1) {
                                OvozPrimaryButton(
                                    text = "Keyingi",
                                    icon = Icons.AutoMirrored.Rounded.ArrowForward,
                                    onClick = { step++ }
                                )
                            } else {
                                TextButton(onClick = onBack) { Text("Yopish", fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                }
            }
        }

        if (reviews.isNotEmpty()) {
            item { Text("Oldingi hisobotlar", style = MaterialTheme.typography.titleSmall, color = tokens.mutedText) }
            items(reviews.sortedByDescending { it.dateKey }, key = { it.dateKey }) { rev ->
                OvozCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(rev.dateKey, style = MaterialTheme.typography.titleSmall, color = primary)
                            Text("${rev.completionPercent}% vazifa", style = MaterialTheme.typography.labelMedium)
                        }
                        Text(rev.aiSummary, style = MaterialTheme.typography.bodySmall, color = tokens.mutedText)
                    }
                }
            }
        }
    }
}

@Composable
fun ReportsScreen(
    profile: UserProfile,
    tasks: List<TaskItem>,
    expenses: List<FinanceTransaction>,
    debts: List<DebtItem>,
    reportState: ReportUiState,
    onGenerateReport: (String) -> Unit,
    onBack: () -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    val cur = profile.primaryCurrency
    val hidden = profile.hideBalances

    var period by remember { mutableStateOf("week") }
    val days = if (period == "month") 30L else 7L
    val start = System.currentTimeMillis() - days * 86_400_000L

    val periodExp = expenses.filter { it.currency == cur && it.occurredAtMillis >= start }
    val expTotal = periodExp.sumOf { it.amount }
    val topCats = periodExp
        .groupBy { it.category }
        .entries.map { it.key to it.value.sumOf { tx -> tx.amount } }
        .sortedByDescending { it.second }
        .take(4)

    val doneCount = tasks.count { it.completed && it.completedAtMillis >= start }
    val pendingCount = tasks.count { !it.completed }
    val overdueCount = tasks.count { Formatters.isOverdue(it.dueDateMillis, it.completed) }
    val activeBorrowed = debts.filter { !it.closed && it.currency == cur && it.direction == "borrowed" }.sumOf { it.remainingAmount }
    val activeLent = debts.filter { !it.closed && it.currency == cur && it.direction == "lent" }.sumOf { it.remainingAmount }
    val repaidCount = debts.count { it.closed && it.closedAtMillis >= start }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("reports_screen"),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Orqaga") }
                Text("Hisobotlar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = period == "week", onClick = { period = "week" }, label = { Text("Haftalik (7 kun)") })
                FilterChip(selected = period == "month", onClick = { period = "month" }, label = { Text("Oylik (30 kun)") })
            }
        }

        // Expenses Summary
        item {
            OvozCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Xarajatlar", style = MaterialTheme.typography.labelMedium, color = tokens.mutedText)
                    Text(
                        Formatters.formatMoney(expTotal, cur, hidden),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = tokens.expense
                    )
                    if (topCats.isNotEmpty()) {
                        HorizontalDivider(color = tokens.cardBorder)
                        topCats.forEach { (cat, sum) ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(cat, style = MaterialTheme.typography.bodyMedium)
                                Text(Formatters.formatMoney(sum, cur, hidden), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }

        // Tasks & Debts Summary
        item {
            OvozCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Vazifalar va qarzlar", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text("• Bajarilgan vazifalar: $doneCount ta", style = MaterialTheme.typography.bodyMedium)
                    Text("• Faol vazifalar: $pendingCount ta", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "• Kechikkan vazifalar: $overdueCount ta",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (overdueCount > 0) tokens.expense else tokens.mutedText
                    )
                    HorizontalDivider(color = tokens.cardBorder)
                    Text("• Men qaytarishim kerak: ${Formatters.formatMoney(activeBorrowed, cur, hidden)}", style = MaterialTheme.typography.bodyMedium)
                    Text("• Menga qaytarishlari kerak: ${Formatters.formatMoney(activeLent, cur, hidden)}", style = MaterialTheme.typography.bodyMedium)
                    if (repaidCount > 0) {
                        Text("• Davrda yopilgan qarzlar: $repaidCount ta", style = MaterialTheme.typography.bodyMedium, color = tokens.income)
                    }
                }
            }
        }

        // Gemini Summary & Advice
        item {
            OvozCard(
                modifier = Modifier.fillMaxWidth(),
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = primary)
                        Spacer(Modifier.width(8.dp))
                        Text("AI xulosasi", style = MaterialTheme.typography.titleSmall, color = primary, fontWeight = FontWeight.SemiBold)
                    }
                    if (reportState.isGenerating) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                    } else if (reportState.aiSummary.isNotBlank() && reportState.period == period) {
                        Text(reportState.aiSummary, style = MaterialTheme.typography.bodyMedium)
                        if (reportState.aiAdvice.isNotBlank()) {
                            Text("Tavsiya: ${reportState.aiAdvice}", style = MaterialTheme.typography.bodySmall, color = primary)
                        }
                    } else if (reportState.error.isNotBlank()) {
                        Text(reportState.error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                    OvozPrimaryButton(
                        text = if (period == "month") "Oylik tahlilni yaratish" else "Haftalik tahlilni yaratish",
                        icon = Icons.Rounded.AutoAwesome,
                        loading = reportState.isGenerating,
                        onClick = { onGenerateReport(period) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

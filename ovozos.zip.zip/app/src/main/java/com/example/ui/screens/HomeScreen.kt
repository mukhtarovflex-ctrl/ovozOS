package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.core.AppStrings
import com.example.core.Formatters
import com.example.data.model.DebtItem
import com.example.data.model.FinanceTransaction
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.example.ui.theme.LocalOvozTokens

@Composable
fun HomeScreen(
    profile: UserProfile,
    strings: AppStrings,
    tasks: List<TaskItem>,
    expenses: List<FinanceTransaction>,
    debts: List<DebtItem>,
    bottomBarPadding: Dp = 116.dp,
    onOpenSearch: () -> Unit,
    onNavigate: (String) -> Unit,
    onToggleTask: (TaskItem) -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    val cur = profile.primaryCurrency
    var showNotifications by remember { mutableStateOf(false) }

    // Today's tasks (plus active overdue tasks so nothing urgent is missed)
    val todayTasks = remember(tasks) {
        tasks.filter { task ->
            Formatters.isToday(task.dueDateMillis) ||
                Formatters.isOverdue(task.dueDateMillis, task.completed) ||
                (task.completed && Formatters.isToday(task.completedAtMillis))
        }.sortedWith(
            compareBy<TaskItem> { it.completed }
                .thenBy { if (it.dueDateMillis > 0L) it.dueDateMillis else Long.MAX_VALUE }
        )
    }

    val activeDebts = remember(debts) {
        debts.filter { !it.closed }.sortedBy { if (it.dueDateMillis > 0L) it.dueDateMillis else Long.MAX_VALUE }
    }
    val borrowedPrimary = remember(activeDebts, cur) {
        activeDebts.filter { it.currency == cur && it.direction == "borrowed" }.sumOf { it.remainingAmount }
    }
    val lentPrimary = remember(activeDebts, cur) {
        activeDebts.filter { it.currency == cur && it.direction == "lent" }.sumOf { it.remainingAmount }
    }

    val todayExpenses = remember(expenses) {
        expenses.filter { Formatters.isToday(it.occurredAtMillis) }
            .sortedByDescending { it.occurredAtMillis }
    }
    val todayExpenseTotal = remember(todayExpenses, cur) {
        todayExpenses.filter { it.currency == cur }.sumOf { it.amount }
    }

    val alertTasks = remember(tasks) {
        tasks.filter { !it.completed && (Formatters.isToday(it.dueDateMillis) || Formatters.isOverdue(it.dueDateMillis, false)) }
    }
    val alertDebts = remember(activeDebts) {
        val soon = System.currentTimeMillis() + 3L * 86_400_000L
        activeDebts.filter { it.dueDateMillis > 0L && it.dueDateMillis <= soon }
    }
    val hasAlerts = alertTasks.isNotEmpty() || alertDebts.isNotEmpty()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen"),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = bottomBarPadding),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // 1. Short first-name greeting + date + subtle bell
        item(key = "header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = Formatters.formatFullDateHeader(lang = profile.language),
                        style = MaterialTheme.typography.labelMedium,
                        color = tokens.mutedText
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = Formatters.greetingForHour(profile.displayName, profile.language),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Box {
                    IconButton(
                        onClick = { showNotifications = true },
                        modifier = Modifier.testTag("home_notifications_button")
                    ) {
                        Icon(
                            Icons.Outlined.Notifications,
                            contentDescription = "Bildirishnomalar",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    if (hasAlerts) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(top = 10.dp, end = 10.dp)
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(tokens.expense)
                        )
                    }
                }
            }
        }

        // 2. Compact Smart Search bar
        item(key = "search") {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(onClick = onOpenSearch)
                    .testTag("home_search_bar"),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, tokens.cardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Rounded.Search,
                        contentDescription = "Qidiruv",
                        tint = tokens.mutedText,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "Qidiruv...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = tokens.mutedText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        // 3. HERO SECTION: Bugungi vazifalar (Visually prominent, interactive checkboxes)
        item(key = "today_tasks_hero") {
            val heroBg = if (tokens.isDark) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.28f)
            } else {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.50f)
            }
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_tasks_hero_card"),
                shape = RoundedCornerShape(22.dp),
                color = heroBg,
                border = BorderStroke(1.2.dp, primary.copy(alpha = if (tokens.isDark) 0.42f else 0.32f))
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(primary)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "Bugungi vazifalar",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                        Text(
                            text = strings.all,
                            style = MaterialTheme.typography.labelLarge,
                            color = primary,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onNavigate("tasks") }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                .testTag("home_tasks_see_all")
                        )
                    }

                    Spacer(Modifier.height(10.dp))

                    if (todayTasks.isEmpty()) {
                        Text(
                            text = "Bugun vazifalar yo‘q",
                            style = MaterialTheme.typography.bodyMedium,
                            color = tokens.mutedText,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        val visibleTasks = todayTasks.take(5)
                        visibleTasks.forEachIndexed { idx, task ->
                            HomeTaskRow(
                                task = task,
                                onToggle = { onToggleTask(task) },
                                onOpenTasks = { onNavigate("tasks") }
                            )
                            if (idx < visibleTasks.lastIndex) {
                                HorizontalDivider(
                                    color = primary.copy(alpha = 0.14f),
                                    thickness = 0.8.dp
                                )
                            }
                        }
                        if (todayTasks.size > visibleTasks.size) {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "+ yana ${todayTasks.size - visibleTasks.size} ta",
                                style = MaterialTheme.typography.labelMedium,
                                color = primary,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier
                                    .clickable { onNavigate("tasks") }
                                    .padding(vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // 4. Mavjud qarzlar (Active debts — compact & clear)
        item(key = "active_debts") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_debts_section")
            ) {
                SectionHeaderRow(
                    title = "Mavjud qarzlar",
                    actionLabel = strings.all,
                    onAction = { onNavigate("finance/debts") }
                )
                Spacer(Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, tokens.cardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (activeDebts.isEmpty()) {
                        Text(
                            text = "Faol qarzlar yo‘q",
                            style = MaterialTheme.typography.bodyMedium,
                            color = tokens.mutedText,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp)
                        )
                    } else {
                        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                            // Clear 2-indicator summary strip
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = strings.iOwe,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = tokens.mutedText,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = if (profile.hideBalances) "•••" else Formatters.formatMoney(borrowedPrimary, cur),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (borrowedPrimary > 0) tokens.expense else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = strings.owedToMe,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = tokens.mutedText,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = if (profile.hideBalances) "•••" else Formatters.formatMoney(lentPrimary, cur),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (lentPrimary > 0) tokens.income else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }

                            HorizontalDivider(
                                color = tokens.cardBorder,
                                modifier = Modifier.padding(vertical = 10.dp)
                            )

                            val shownDebts = activeDebts.take(3)
                            shownDebts.forEachIndexed { idx, d ->
                                val isBorrowed = d.direction == "borrowed"
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onNavigate("finance/debts") }
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = d.personName,
                                            style = MaterialTheme.typography.bodyLarge,
                                            fontWeight = FontWeight.Medium,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        val meta = buildList {
                                            add(if (isBorrowed) "Men olgan" else "Men bergan")
                                            if (d.dueDateMillis > 0L) add(Formatters.formatShortDate(d.dueDateMillis))
                                        }.joinToString(" · ")
                                        Text(
                                            text = meta,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = tokens.mutedText
                                        )
                                    }
                                    Text(
                                        text = if (profile.hideBalances) "•••" else Formatters.formatMoney(d.remainingAmount, d.currency),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isBorrowed) tokens.expense else tokens.income
                                    )
                                }
                                if (idx < shownDebts.lastIndex) {
                                    HorizontalDivider(color = tokens.cardBorder.copy(alpha = 0.6f))
                                }
                            }
                        }
                    }
                }
            }
        }

        // 5. Bugungi xarajatlar (Today's expenses — compact list + total)
        item(key = "today_expenses") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_expenses_section")
            ) {
                SectionHeaderRow(
                    title = "Bugungi xarajatlar",
                    actionLabel = strings.all,
                    onAction = { onNavigate("finance/expenses") }
                )
                Spacer(Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, tokens.cardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (todayExpenses.isEmpty()) {
                        Text(
                            text = "Bugun xarajatlar yo‘q",
                            style = MaterialTheme.typography.bodyMedium,
                            color = tokens.mutedText,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp)
                        )
                    } else {
                        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Bugun jami",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = tokens.mutedText
                                )
                                Text(
                                    text = if (profile.hideBalances) "•••" else Formatters.formatMoney(todayExpenseTotal, cur),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.expense
                                )
                            }
                            HorizontalDivider(
                                color = tokens.cardBorder,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                            val shownExp = todayExpenses.take(3)
                            shownExp.forEachIndexed { idx, exp ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onNavigate("finance/expenses") }
                                        .padding(vertical = 7.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = exp.title,
                                            style = MaterialTheme.typography.bodyLarge,
                                            fontWeight = FontWeight.Medium,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = exp.category,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = tokens.mutedText
                                        )
                                    }
                                    Text(
                                        text = if (profile.hideBalances) "•••" else "-${Formatters.formatMoney(exp.amount, exp.currency)}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                if (idx < shownExp.lastIndex) {
                                    HorizontalDivider(color = tokens.cardBorder.copy(alpha = 0.6f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNotifications) {
        AlertDialog(
            onDismissRequest = { showNotifications = false },
            title = { Text("Bildirishnomalar") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (alertTasks.isEmpty() && alertDebts.isEmpty()) {
                        Text("Yangi bildirishnomalar yo‘q.", color = tokens.mutedText)
                    } else {
                        alertTasks.take(5).forEach { t ->
                            val isOverdue = Formatters.isOverdue(t.dueDateMillis, false)
                            Text(
                                text = "• ${t.title}${if (isOverdue) " (kechikkan)" else if (t.hasDueTime) " · ${Formatters.formatTime24(t.dueDateMillis)}" else ""}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isOverdue) tokens.expense else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        alertDebts.take(4).forEach { d ->
                            Text(
                                text = "• Qarz: ${d.personName} (${Formatters.formatMoney(d.remainingAmount, d.currency)})",
                                style = MaterialTheme.typography.bodyMedium,
                                color = tokens.warning
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showNotifications = false }) { Text("Yopish") }
            }
        )
    }
}

@Composable
private fun HomeTaskRow(
    task: TaskItem,
    onToggle: () -> Unit,
    onOpenTasks: () -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    val isOverdue = Formatters.isOverdue(task.dueDateMillis, task.completed)
    val checkBg by animateColorAsState(
        targetValue = if (task.completed) primary else androidx.compose.ui.graphics.Color.Transparent,
        animationSpec = tween(180),
        label = "home_task_check"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenTasks)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .clickable(onClick = onToggle)
                .testTag("home_task_check_${task.id}"),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(checkBg)
                    .border(
                        width = 1.6.dp,
                        color = if (task.completed) primary else if (isOverdue) tokens.expense else primary.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(7.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (task.completed) {
                    Icon(
                        Icons.Rounded.Check,
                        contentDescription = "Bajarildi",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
        }

        Spacer(Modifier.width(4.dp))

        Text(
            text = task.title,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = if (task.completed) FontWeight.Normal else FontWeight.Medium,
            textDecoration = if (task.completed) TextDecoration.LineThrough else TextDecoration.None,
            color = if (task.completed) tokens.mutedText else MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )

        if (!task.completed && task.priority == "high") {
            Spacer(Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(tokens.expense)
            )
        }

        if (task.hasDueTime && task.dueDateMillis > 0L) {
            Spacer(Modifier.width(8.dp))
            Text(
                text = Formatters.formatTime24(task.dueDateMillis),
                style = MaterialTheme.typography.labelMedium,
                color = if (isOverdue) tokens.expense else tokens.mutedText
            )
        } else if (isOverdue) {
            Spacer(Modifier.width(8.dp))
            Text(
                text = Formatters.formatShortDate(task.dueDateMillis),
                style = MaterialTheme.typography.labelSmall,
                color = tokens.expense
            )
        }
    }
}

@Composable
private fun SectionHeaderRow(
    title: String,
    actionLabel: String,
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .clickable(onClick = onAction)
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = actionLabel,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Icon(
                Icons.Rounded.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

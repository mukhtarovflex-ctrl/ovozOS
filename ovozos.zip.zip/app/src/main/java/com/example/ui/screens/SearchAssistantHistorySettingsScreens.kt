package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.Formatters
import com.example.data.model.ActionLogItem
import com.example.data.model.AssistantMessage
import com.example.data.model.DebtItem
import com.example.data.model.FinanceTransaction
import com.example.data.model.PersonItem
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.example.ui.components.OvozCard
import com.example.ui.components.OvozPrimaryButton
import com.example.ui.theme.LocalOvozTokens
import com.example.ui.viewmodel.SmartSearchUiState

@Composable
fun SmartSearchScreen(
    state: SmartSearchUiState,
    profile: UserProfile,
    tasks: List<TaskItem>,
    expenses: List<FinanceTransaction>,
    debts: List<DebtItem>,
    people: List<PersonItem>,
    onQueryChange: (String) -> Unit,
    onFilterType: (String) -> Unit,
    onRunAiSearch: (String?) -> Unit,
    onNavigateToSection: (String) -> Unit,
    onOpenVoice: () -> Unit,
    onBack: () -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    val q = state.query.trim()

    val aiRes = state.aiResult
    val matchedTasks = remember(tasks, q, aiRes) {
        if (q.isEmpty()) emptyList()
        else tasks.filter {
            (aiRes != null && it.id in aiRes.taskIds) ||
                it.title.contains(q, true) || it.description.contains(q, true) || it.personName.contains(q, true)
        }
    }
    val matchedExpenses = remember(expenses, q, aiRes) {
        if (q.isEmpty()) emptyList()
        else expenses.filter {
            (aiRes != null && it.id in aiRes.transactionIds) ||
                it.title.contains(q, true) || it.category.contains(q, true) || it.personName.contains(q, true)
        }
    }
    val matchedDebts = remember(debts, q, aiRes) {
        if (q.isEmpty()) emptyList()
        else debts.filter {
            (aiRes != null && it.id in aiRes.debtIds) ||
                it.personName.contains(q, true) || it.note.contains(q, true)
        }
    }
    val matchedPeople = remember(people, q, aiRes) {
        if (q.isEmpty()) emptyList()
        else people.filter { (aiRes != null && it.id in aiRes.personIds) || it.name.contains(q, true) }
    }

    val suggestedQueries = listOf(
        "Bajarilmagan vazifalarim",
        "Eng katta xarajatlarim",
        "Qaytarilmagan qarzlar"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("smart_search_screen"),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 124.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Orqaga") }
                Text("Aqlli qidiruv", style = MaterialTheme.typography.headlineMedium)
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = state.query,
                    onValueChange = onQueryChange,
                    placeholder = { Text("Mazmun bo‘yicha izlang...") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    trailingIcon = {
                        IconButton(onClick = onOpenVoice) {
                            Icon(Icons.Rounded.Mic, contentDescription = "Ovozli qidiruv", tint = primary)
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f).testTag("smart_search_input")
                )
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = primary,
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onRunAiSearch(null) }
                        .testTag("smart_search_ai_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (state.isSearchingAi) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Rounded.AutoAwesome, contentDescription = "AI qidiruv", tint = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(
                    listOf(
                        "all" to "Barchasi",
                        "tasks" to "Vazifalar",
                        "expenses" to "Xarajatlar",
                        "debts" to "Qarzlar",
                        "people" to "Insonlar"
                    )
                ) { (k, l) ->
                    FilterChip(selected = state.filterType == k, onClick = { onFilterType(k) }, label = { Text(l) })
                }
            }
        }

        if (q.isEmpty()) {
            if (state.recentQueries.isNotEmpty()) {
                item {
                    Text("Oxirgi qidiruvlar", style = MaterialTheme.typography.titleSmall, color = tokens.mutedText)
                }
                items(state.recentQueries) { rq ->
                    OvozCard(modifier = Modifier.fillMaxWidth(), onClick = { onRunAiSearch(rq) }) {
                        Text(rq, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(14.dp))
                    }
                }
            }
            item {
                Text("Tavsiya etilgan so‘rovlar", style = MaterialTheme.typography.titleSmall, color = tokens.mutedText)
            }
            items(suggestedQueries) { sq ->
                OvozCard(modifier = Modifier.fillMaxWidth(), onClick = { onRunAiSearch(sq) }) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = primary, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(sq, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        } else {
            if (aiRes?.summary?.isNotBlank() == true) {
                item {
                    OvozCard(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f), modifier = Modifier.fillMaxWidth()) {
                        Text(aiRes.summary, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(14.dp))
                    }
                }
            }

            if ((state.filterType == "all" || state.filterType == "tasks") && matchedTasks.isNotEmpty()) {
                item { Text("Vazifalar (${matchedTasks.size})", style = MaterialTheme.typography.titleMedium) }
                items(matchedTasks, key = { "t_${it.id}" }) { t ->
                    OvozCard(modifier = Modifier.fillMaxWidth(), onClick = { onNavigateToSection("tasks") }) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(t.title, style = MaterialTheme.typography.titleSmall)
                            Text(t.category, style = MaterialTheme.typography.labelSmall, color = tokens.mutedText)
                        }
                    }
                }
            }

            if ((state.filterType == "all" || state.filterType == "expenses") && matchedExpenses.isNotEmpty()) {
                item { Text("Xarajatlar (${matchedExpenses.size})", style = MaterialTheme.typography.titleMedium) }
                items(matchedExpenses, key = { "tx_${it.id}" }) { tx ->
                    OvozCard(modifier = Modifier.fillMaxWidth(), onClick = { onNavigateToSection("finance/expenses") }) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(tx.title, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "${tx.category} · ${Formatters.formatShortDate(tx.occurredAtMillis)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = tokens.mutedText
                                )
                            }
                            Text(
                                "-${Formatters.formatMoney(tx.amount, tx.currency, profile.hideBalances)}",
                                style = MaterialTheme.typography.titleSmall,
                                color = tokens.expense,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            if ((state.filterType == "all" || state.filterType == "debts") && matchedDebts.isNotEmpty()) {
                item { Text("Oldi-berdi (${matchedDebts.size})", style = MaterialTheme.typography.titleMedium) }
                items(matchedDebts, key = { "d_${it.id}" }) { d ->
                    OvozCard(modifier = Modifier.fillMaxWidth(), onClick = { onNavigateToSection("finance/debts") }) {
                        Row(modifier = Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(d.personName, style = MaterialTheme.typography.titleSmall)
                            Text(Formatters.formatMoney(d.remainingAmount, d.currency, profile.hideBalances), style = MaterialTheme.typography.titleSmall, color = tokens.debt)
                        }
                    }
                }
            }

            if ((state.filterType == "all" || state.filterType == "people") && matchedPeople.isNotEmpty()) {
                item { Text("Insonlar (${matchedPeople.size})", style = MaterialTheme.typography.titleMedium) }
                items(matchedPeople, key = { "p_${it.id}" }) { p ->
                    OvozCard(modifier = Modifier.fillMaxWidth(), onClick = { onNavigateToSection("people") }) {
                        Text(p.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(14.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun AssistantChatScreen(
    profile: UserProfile,
    messages: List<AssistantMessage>,
    streamingText: String,
    isLoading: Boolean,
    error: String,
    tasks: List<TaskItem>,
    debts: List<DebtItem>,
    onSend: (String) -> Unit,
    onSpeakText: (String) -> Unit,
    onClearChat: () -> Unit,
    onOpenVoice: () -> Unit,
    onBack: () -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    var input by remember { mutableStateOf("") }

    val quickPrompts = listOf(
        "Ertaga qanday rejalarim bor?",
        "Hozir jami qancha qarzim bor?",
        "Bu oy xarajatlarim asosan nimalarga ketdi?"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .testTag("assistant_chat_screen")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Orqaga") }
                Column {
                    Text("OvozOS Yordamchi", style = MaterialTheme.typography.titleLarge)
                    Text("Haqiqiy ma’lumotlaringiz asosida javob beradi", style = MaterialTheme.typography.labelSmall, color = tokens.mutedText)
                }
            }
            if (messages.isNotEmpty()) {
                TextButton(onClick = onClearChat) { Text("Tozalash") }
            }
        }

        val sortedMessages = remember(messages) {
            messages.sortedBy { it.createdAt?.seconds ?: 0L }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (sortedMessages.isEmpty() && !isLoading) {
                item {
                    OvozCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = primary)
                                Spacer(Modifier.width(8.dp))
                                Text("Yordamchidan so‘rang", style = MaterialTheme.typography.titleMedium)
                            }
                            Text(
                                "Saqlangan vazifalaringiz, xarajatlaringiz va qarzlaringiz haqida so‘rang.",
                                style = MaterialTheme.typography.bodySmall,
                                color = tokens.mutedText
                            )
                            quickPrompts.forEach { q ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onSend(q) }
                                ) {
                                    Text(q, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(12.dp))
                                }
                            }
                        }
                    }
                }
            }

            items(sortedMessages, key = { it.id }) { msg ->
                val isUser = msg.role == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        shape = RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 18.dp,
                            bottomStart = if (isUser) 18.dp else 4.dp,
                            bottomEnd = if (isUser) 4.dp else 18.dp
                        ),
                        color = if (isUser) primary else MaterialTheme.colorScheme.surface,
                        border = if (isUser) null else BorderStroke(1.dp, tokens.cardBorder),
                        modifier = Modifier.fillMaxWidth(0.86f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = msg.text,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            )
                            if (!isUser) {
                                // Interactive embedded summary pills when relevant
                                if (msg.attachmentType == "debts" && debts.any { !it.closed }) {
                                    Text(
                                        "Faol qarzlar: ${debts.count { !it.closed }} ta",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = tokens.debt
                                    )
                                } else if (msg.attachmentType == "tasks") {
                                    Text(
                                        "Faol vazifalar: ${tasks.count { !it.completed }} ta",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = primary
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                                    IconButton(onClick = { onSpeakText(msg.text) }, modifier = Modifier.size(28.dp)) {
                                        Icon(Icons.Rounded.VolumeUp, contentDescription = "O‘qib berish", tint = tokens.mutedText, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (isLoading) {
                item {
                    OvozCard(modifier = Modifier.fillMaxWidth(0.86f)) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (streamingText.isNotBlank()) {
                                Text(streamingText, style = MaterialTheme.typography.bodyMedium)
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                    Text("Gemini javob tayyorlamoqda...", style = MaterialTheme.typography.bodySmall, color = tokens.mutedText)
                                }
                            }
                        }
                    }
                }
            }

            if (error.isNotBlank()) {
                item {
                    Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.errorContainer) {
                        Text(error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(12.dp))
                    }
                }
            }
        }

        // Input bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 104.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(onClick = onOpenVoice) {
                Icon(Icons.Rounded.Mic, contentDescription = "Ovoz bilan so‘rash", tint = primary)
            }
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("Savol yozing...") },
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.weight(1f)
            )
            IconButton(
                enabled = input.trim().isNotEmpty() && !isLoading,
                onClick = {
                    val text = input.trim()
                    input = ""
                    onSend(text)
                }
            ) {
                Icon(Icons.Rounded.Send, contentDescription = "Yuborish", tint = primary)
            }
        }
    }
}

@Composable
fun ActionHistoryScreen(
    profile: UserProfile,
    logs: List<ActionLogItem>,
    onUndoSingle: (ActionLogItem) -> Unit,
    onUndoBatch: (String) -> Unit,
    onBack: () -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    val grouped = remember(logs) {
        logs.sortedByDescending { it.createdAt?.seconds ?: 0L }.groupBy { it.batchId }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("action_history_screen"),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 124.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Orqaga") }
                Text("Amallar tarixi", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }
        }

        if (logs.isEmpty()) {
            item {
                OvozCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Hozircha amallar tarixi bo‘sh. Vazifa, xarajat yoki ovozli buyruq bajarganingizda bu yerda ko‘rinadi.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = tokens.mutedText,
                        modifier = Modifier.padding(18.dp)
                    )
                }
            }
        } else {
            grouped.forEach { (batchId, batchLogs) ->
                val hasActive = batchLogs.any { !it.reverted }
                item(key = "batch_$batchId") {
                    OvozCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (batchLogs.size > 1) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        "Ovozli buyruq (${batchLogs.size} ta amal)",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = primary
                                    )
                                    if (hasActive) {
                                        TextButton(onClick = { onUndoBatch(batchId) }) {
                                            Icon(Icons.Rounded.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Hammasini bekor qilish")
                                        }
                                    }
                                }
                                HorizontalDivider(color = tokens.cardBorder)
                            }
                            batchLogs.forEach { log ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            log.summaryText,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = if (log.reverted) tokens.mutedText else MaterialTheme.colorScheme.onSurface
                                        )
                                        if (log.beforeSummary.isNotBlank() || log.afterSummary.isNotBlank()) {
                                            Text(
                                                "${log.beforeSummary.ifBlank { "Yangi" }} → ${log.afterSummary}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = tokens.mutedText,
                                                maxLines = 2
                                            )
                                        }
                                        val ts = log.createdAt?.toDate()?.time ?: 0L
                                        if (ts > 0L) {
                                            Text(
                                                Formatters.formatDateTime24(ts, profile.dateFormat, profile.language),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = tokens.mutedText
                                            )
                                        }
                                    }
                                    if (log.reverted) {
                                        Text("Bekor qilingan", style = MaterialTheme.typography.labelSmall, color = tokens.mutedText)
                                    } else {
                                        TextButton(onClick = { onUndoSingle(log) }) {
                                            Text("Bekor qilish", color = tokens.expense)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    profile: UserProfile,
    geminiStatus: String?,
    onUpdateProfile: (Map<String, Any>, String?) -> Unit,
    onCheckGemini: () -> Unit,
    onBuildBackupJson: () -> String,
    onRestoreBackupJson: (String) -> Unit,
    onWipeAllData: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onSignOut: () -> Unit,
    onBack: () -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    val context = LocalContext.current

    var showNameDialog by remember { mutableStateOf(false) }
    var showPinDialog by remember { mutableStateOf(false) }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var showWipeConfirm by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("settings_screen"),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 124.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Orqaga") }
                Text("Sozlamalar", style = MaterialTheme.typography.headlineMedium)
            }
        }

        // 1. Tashqi ko'rinish (with live theme & text scale preview)
        item {
            OvozCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Tashqi ko‘rinish", style = MaterialTheme.typography.titleMedium, color = primary)

                    Text("Mavzu", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("system" to "Avto", "light" to "Yorug‘", "dark" to "Qorong‘i").forEach { (k, l) ->
                            FilterChip(
                                selected = profile.themeMode == k,
                                onClick = { onUpdateProfile(mapOf("themeMode" to k), null) },
                                label = { Text(l) }
                            )
                        }
                    }

                    Text("Matn o‘lchami", style = MaterialTheme.typography.labelLarge)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf("small" to "Kichik", "standard" to "Standart", "large" to "Katta", "xlarge" to "Juda katta")) { (k, l) ->
                            FilterChip(
                                selected = profile.textScale == k,
                                onClick = { onUpdateProfile(mapOf("textScale" to k), null) },
                                label = { Text(l) }
                            )
                        }
                    }

                    Text("Asosiy urg‘u rangi", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        listOf(
                            "emerald" to Color(0xFF167D69),
                            "ocean" to Color(0xFF146C94),
                            "amber" to Color(0xFFB4651D),
                            "violet" to Color(0xFF5E4BA8)
                        ).forEach { (k, c) ->
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(c)
                                    .clickable { onUpdateProfile(mapOf("accentPreset" to k), null) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (profile.accentPreset == k) {
                                    Box(Modifier.size(14.dp).clip(CircleShape).background(Color.White))
                                }
                            }
                        }
                    }

                    Text("Interfeys zichligi", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = profile.density == "comfortable",
                            onClick = { onUpdateProfile(mapOf("density" to "comfortable"), null) },
                            label = { Text("Keng") }
                        )
                        FilterChip(
                            selected = profile.density == "compact",
                            onClick = { onUpdateProfile(mapOf("density" to "compact"), null) },
                            label = { Text("Ixcham") }
                        )
                    }
                }
            }
        }

        // 2. Til va hudud
        item {
            OvozCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Til va hudud", style = MaterialTheme.typography.titleMedium, color = primary)

                    Text("Ilova tili", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("uz" to "O‘zbek", "ru" to "Русский", "en" to "English").forEach { (k, l) ->
                            FilterChip(
                                selected = profile.language == k,
                                onClick = { onUpdateProfile(mapOf("language" to k), "Til o‘zgartirildi") },
                                label = { Text(l) }
                            )
                        }
                    }

                    Text("Yordamchi javob tili", style = MaterialTheme.typography.labelLarge)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf("auto" to "Avto", "uz" to "O‘zbek", "ru" to "Русский", "en" to "English")) { (k, l) ->
                            FilterChip(
                                selected = profile.aiResponseLang == k,
                                onClick = { onUpdateProfile(mapOf("aiResponseLang" to k), null) },
                                label = { Text(l) }
                            )
                        }
                    }

                    Text("Asosiy valyuta", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("UZS", "USD", "EUR", "RUB").forEach { c ->
                            FilterChip(
                                selected = profile.primaryCurrency == c,
                                onClick = { onUpdateProfile(mapOf("primaryCurrency" to c), null) },
                                label = { Text(c) }
                            )
                        }
                    }

                    Text("Sana ko‘rinishi (vaqt 24 soatlik)", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("dd.MM.yyyy" to "24.11.2026", "d MMM" to "24-noy", "yyyy-MM-dd" to "2026-11-24").forEach { (k, l) ->
                            FilterChip(
                                selected = profile.dateFormat == k,
                                onClick = { onUpdateProfile(mapOf("dateFormat" to k), null) },
                                label = { Text(l) }
                            )
                        }
                    }
                }
            }
        }

        // 3. Bildirishnomalar
        item {
            OvozCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Bildirishnomalar", style = MaterialTheme.typography.titleMedium, color = primary)
                    SettingsToggleRow("Barcha bildirishnomalar", profile.notifyAll) {
                        if (it) onRequestNotificationPermission()
                        onUpdateProfile(mapOf("notifyAll" to it), null)
                    }
                    SettingsToggleRow("Vazifalar muddati", profile.notifyTasks) {
                        onUpdateProfile(mapOf("notifyTasks" to it), null)
                    }
                    SettingsToggleRow("Qarz qaytarish muddatlari", profile.notifyDebts) {
                        onUpdateProfile(mapOf("notifyDebts" to it), null)
                    }
                    SettingsToggleRow("Kun yakuni hisoboti (${"%02d".format(profile.eveningReviewHour)}:00)", profile.notifyEvening) {
                        onUpdateProfile(mapOf("notifyEvening" to it), null)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(20L, 21L, 22L).forEach { hr ->
                            FilterChip(
                                selected = profile.eveningReviewHour == hr,
                                onClick = { onUpdateProfile(mapOf("eveningReviewHour" to hr), null) },
                                label = { Text("$hr:00") }
                            )
                        }
                    }
                    SettingsToggleRow("Haftalik va oylik hisobotlar", profile.notifyReports) {
                        onUpdateProfile(mapOf("notifyReports" to it), null)
                    }
                    SettingsToggleRow("Bildirishnomalar ovozi", profile.notifySound) {
                        onUpdateProfile(mapOf("notifySound" to it), null)
                    }
                }
            }
        }

        // 4. Sun'iy intellekt va ovoz
        item {
            OvozCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Sun’iy intellekt va ovoz", style = MaterialTheme.typography.titleMedium, color = primary)
                    SettingsToggleRow("Ovozli javoblarni o‘qib berish", profile.voiceSpokenReply) {
                        onUpdateProfile(mapOf("voiceSpokenReply" to it), null)
                    }
                    SettingsToggleRow("Oddiy amallarni avtomatik saqlash", profile.autoSaveVoice) {
                        onUpdateProfile(mapOf("autoSaveVoice" to it), null)
                    }
                    Text(
                        "Muhim moliyaviy va qarz o‘zgarishlari har doim tasdiqlash orqali saqlanadi.",
                        style = MaterialTheme.typography.labelSmall,
                        color = tokens.mutedText
                    )
                    Text("Javob uzunligi", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("short" to "Qisqa", "standard" to "Standart", "detailed" to "Batafsil").forEach { (k, l) ->
                            FilterChip(
                                selected = profile.aiResponseLength == k,
                                onClick = { onUpdateProfile(mapOf("aiResponseLength" to k), null) },
                                label = { Text(l) }
                            )
                        }
                    }
                    OutlinedButton(onClick = onCheckGemini, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Gemini ulanishini tekshirish")
                    }
                    if (!geminiStatus.isNullOrBlank()) {
                        Text(geminiStatus, style = MaterialTheme.typography.bodySmall, color = primary)
                    }
                }
            }
        }

        // 5. Shaxsiy hisob, Bosh sahifa & Ma'lumotlar
        item {
            OvozCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Shaxsiy hisob va maxfiylik", style = MaterialTheme.typography.titleMedium, color = primary)

                    SettingsToggleRow("Moliyaviy raqamlarni yashirish", profile.hideBalances) {
                        onUpdateProfile(mapOf("hideBalances" to it), null)
                    }
                    SettingsToggleRow("4 xonali kirish kodi (PIN)", profile.pinLockEnabled) { enable ->
                        if (enable) showPinDialog = true
                        else onUpdateProfile(mapOf("pinLockEnabled" to false, "pinHash" to ""), "PIN himoya o‘chirildi")
                    }

                    OutlinedButton(onClick = { showNameDialog = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Ism: ${profile.displayName}", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val json = onBuildBackupJson()
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/json"
                                    putExtra(Intent.EXTRA_SUBJECT, "OvozOS zaxira nusxasi")
                                    putExtra(Intent.EXTRA_TEXT, json)
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Zaxira nusxasini saqlash"))
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.Backup, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Zaxira olish")
                        }
                        OutlinedButton(onClick = { showRestoreDialog = true }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Tiklash")
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { showWipeConfirm = true }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.DeleteForever, contentDescription = null, tint = tokens.expense, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Hammasini o‘chirish", color = tokens.expense, maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = onSignOut,
                            modifier = Modifier.weight(1f).testTag("sign_out_button")
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Chiqish")
                        }
                    }
                }
            }
        }

        // 6. Ilova haqida
        item {
            OvozCard(modifier = Modifier.fillMaxWidth(), onClick = { showAboutDialog = true }) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Ilova haqida", style = MaterialTheme.typography.titleMedium)
                        Text("OvozOS 1.0 • Maxfiylik siyosati va yordam", style = MaterialTheme.typography.bodySmall, color = tokens.mutedText)
                    }
                    Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = primary)
                }
            }
        }
    }

    if (showNameDialog) {
        var newName by remember { mutableStateOf(profile.displayName) }
        AlertDialog(
            onDismissRequest = { showNameDialog = false },
            title = { Text("Ismni o‘zgartirish") },
            text = { OutlinedTextField(value = newName, onValueChange = { if (it.length <= 50) newName = it }, singleLine = true) },
            confirmButton = {
                TextButton(enabled = newName.trim().isNotEmpty(), onClick = {
                    onUpdateProfile(mapOf("displayName" to newName.trim()), "Ism yangilandi")
                    showNameDialog = false
                }) { Text("Saqlash") }
            },
            dismissButton = { TextButton(onClick = { showNameDialog = false }) { Text("Bekor qilish") } }
        )
    }

    if (showPinDialog) {
        var pin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text("4 xonali PIN kod o‘rnatish") },
            text = {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it.filter(Char::isDigit).take(4) },
                    label = { Text("4 ta raqam") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(enabled = pin.length == 4, onClick = {
                    onUpdateProfile(mapOf("pinLockEnabled" to true, "pinHash" to Formatters.hashPin(pin)), "PIN himoya yoqildi")
                    showPinDialog = false
                }) { Text("O‘rnatish") }
            },
            dismissButton = { TextButton(onClick = { showPinDialog = false }) { Text("Bekor qilish") } }
        )
    }

    if (showRestoreDialog) {
        var raw by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text("Zaxira nusxasidan tiklash") },
            text = {
                OutlinedTextField(
                    value = raw,
                    onValueChange = { raw = it },
                    label = { Text("Zaxira JSON matnini joylashtiring") },
                    minLines = 4,
                    maxLines = 6
                )
            },
            confirmButton = {
                TextButton(enabled = raw.trim().startsWith("{"), onClick = {
                    onRestoreBackupJson(raw.trim())
                    showRestoreDialog = false
                }) { Text("Tiklash") }
            },
            dismissButton = { TextButton(onClick = { showRestoreDialog = false }) { Text("Bekor qilish") } }
        )
    }

    if (showWipeConfirm) {
        AlertDialog(
            onDismissRequest = { showWipeConfirm = false },
            title = { Text("Barcha ma’lumotlarni o‘chirish?") },
            text = { Text("Barcha vazifalar, xarajatlar, qarzlar va insonlar butunlay o‘chiriladi. Bu amalni qaytarib bo‘lmaydi.") },
            confirmButton = {
                TextButton(onClick = {
                    onWipeAllData()
                    showWipeConfirm = false
                }) { Text("Ha, o‘chirish", color = tokens.expense, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showWipeConfirm = false }) { Text("Bekor qilish") } }
        )
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text("OvozOS 1.0") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Kamroq yozing, ko‘proq yashang.", fontWeight = FontWeight.SemiBold)
                    Text("• Ovozli boshqaruv: Markaziy mikrofon tugmasini bosib bir gapda vazifa, xarajat va qarz kiriting.")
                    Text("• Maxfiylik: Barcha ma’lumotlaringiz shaxsiy Google hisobingiz ostida saqlanadi. Mikrofon faqat siz tugmani bosganingizda ishlaydi.")
                }
            },
            confirmButton = { TextButton(onClick = { showAboutDialog = false }) { Text("Yopish") } }
        )
    }
}

@Composable
private fun SettingsToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

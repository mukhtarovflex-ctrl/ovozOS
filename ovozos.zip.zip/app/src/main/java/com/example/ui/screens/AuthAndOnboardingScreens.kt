package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Login
import androidx.compose.material.icons.rounded.SettingsBrightness
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.core.attemptAutoSignIn
import com.example.core.onGoogleSignInClicked
import com.example.ui.components.OvozCard
import com.example.ui.components.OvozPrimaryButton
import com.example.ui.theme.LocalOvozTokens
import kotlin.math.sin

@Composable
fun AuthScreen(
    onAuthSuccess: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var isLoading by remember { mutableStateOf(false) }
    var isAutoChecking by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = {
                isAutoChecking = false
                onAuthSuccess()
            },
            onUnauthenticated = {
                isAutoChecking = false
            },
            scope = scope
        )
    }

    val primary = MaterialTheme.colorScheme.primary
    val container = MaterialTheme.colorScheme.primaryContainer
    val bg = MaterialTheme.colorScheme.background
    val tokens = LocalOvozTokens.current

    val infinite = rememberInfiniteTransition(label = "auth_wave")
    val phase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = (2f * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(3200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "auth_phase"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(container.copy(alpha = 0.55f), bg, bg)
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 460.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(16.dp))

            // Animated acoustic emblem
            Canvas(modifier = Modifier.size(164.dp)) {
                val c = Offset(size.width / 2f, size.height / 2f)
                val pulse = 1f + 0.05f * sin(phase)
                drawCircle(
                    color = primary.copy(alpha = 0.10f),
                    radius = size.minDimension * 0.48f * pulse,
                    center = c
                )
                drawCircle(
                    color = primary.copy(alpha = 0.18f),
                    radius = size.minDimension * 0.36f,
                    center = c
                )
                drawCircle(
                    brush = Brush.linearGradient(
                        colors = listOf(primary, primary.copy(alpha = 0.78f))
                    ),
                    radius = size.minDimension * 0.27f,
                    center = c
                )
                val bars = 5
                val barW = size.width * 0.036f
                val gap = size.width * 0.028f
                val totalW = bars * barW + (bars - 1) * gap
                var x = c.x - totalW / 2f
                for (i in 0 until bars) {
                    val base = when (i) {
                        0, 4 -> 0.14f
                        1, 3 -> 0.24f
                        else -> 0.34f
                    }
                    val wave = base + 0.05f * sin(phase + i * 0.9f)
                    val h = size.height * wave
                    drawRoundRect(
                        color = Color.White,
                        topLeft = Offset(x, c.y - h / 2f),
                        size = Size(barW, h),
                        cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                    )
                    x += barW + gap
                }
            }

            Spacer(Modifier.height(22.dp))
            Text(
                text = "OvozOS",
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Kamroq yozing, ko‘proq yashang.",
                style = MaterialTheme.typography.titleMedium,
                color = primary,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "Gapiring — qolganini sun’iy intellekt bajaradi. Vazifalar, xarajatlar va qarzlar yagona aqlli tizimda.",
                style = MaterialTheme.typography.bodyMedium,
                color = tokens.mutedText,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(28.dp))

            OvozCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AuthFeatureRow(
                        icon = Icons.Rounded.GraphicEq,
                        title = "Bitta ovozli buyruq — bir nechta amal",
                        subtitle = "O‘zbek, rus va ingliz tillarida erkin gapiring"
                    )
                    AuthFeatureRow(
                        icon = Icons.Rounded.AutoAwesome,
                        title = "Xavfsiz bulutli saqlash",
                        subtitle = "Barcha shaxsiy ma’lumotlaringiz faqat sizga tegishli"
                    )
                }
            }

            Spacer(Modifier.height(26.dp))

            if (errorMessage != null) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Text(
                        text = errorMessage!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            if (isAutoChecking) {
                CircularProgressIndicator(
                    modifier = Modifier.size(32.dp),
                    color = primary,
                    strokeWidth = 3.dp
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    "Hisob tekshirilmoqda...",
                    style = MaterialTheme.typography.bodySmall,
                    color = tokens.mutedText
                )
            } else {
                OvozPrimaryButton(
                    text = "Google orqali kirish",
                    icon = Icons.Rounded.Login,
                    loading = isLoading,
                    onClick = {
                        errorMessage = null
                        isLoading = true
                        onGoogleSignInClicked(
                            context = context,
                            credentialManager = credentialManager,
                            onAuthSuccess = {
                                isLoading = false
                                onAuthSuccess()
                            },
                            onAuthError = { msg ->
                                isLoading = false
                                errorMessage = msg
                            },
                            scope = scope,
                            onAuthCancelled = {
                                isLoading = false
                            }
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("google_sign_in_button")
                )
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun AuthFeatureRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(21.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = LocalOvozTokens.current.mutedText
            )
        }
    }
}

@Composable
fun OnboardingScreen(
    initialName: String,
    onFinish: (name: String, language: String, currency: String, themeMode: String) -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var language by remember { mutableStateOf("uz") }
    var currency by remember { mutableStateOf("UZS") }
    var themeMode by remember { mutableStateOf("system") }
    val tokens = LocalOvozTokens.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 560.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "OvozOS — Xush kelibsiz",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Shaxsiy tizimingizni sozlang",
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Atigi bir necha soniya. Barcha bo‘limlar toza holatda ochiladi — o‘z ma’lumotlaringiz bilan noldan boshlaysiz.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = tokens.mutedText
                )
            }

            // 1. Name
            OvozCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Ismingiz", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = name,
                        onValueChange = { if (it.length <= 50) name = it },
                        placeholder = { Text("Masalan, Sardor") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("onboarding_name_input")
                    )
                }
            }

            // 2. Language
            OvozCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Ilova tili", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("uz" to "O‘zbek", "ru" to "Русский", "en" to "English").forEach { (code, label) ->
                            SelectableChipBox(
                                label = label,
                                selected = language == code,
                                onClick = { language = code },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // 3. Currency
            OvozCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Asosiy valyuta", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("UZS" to "So‘m", "USD" to "USD $", "EUR" to "EUR €", "RUB" to "RUB ₽").forEach { (code, label) ->
                            SelectableChipBox(
                                label = label,
                                selected = currency == code,
                                onClick = { currency = code },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // 4. Theme
            OvozCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Tashqi ko‘rinish", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val themes = listOf(
                            Triple("system", "Avto", Icons.Rounded.SettingsBrightness),
                            Triple("light", "Yorug‘", Icons.Rounded.LightMode),
                            Triple("dark", "Qorong‘i", Icons.Rounded.DarkMode)
                        )
                        themes.forEach { (code, label, icon) ->
                            val sel = themeMode == code
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { themeMode = code },
                                shape = RoundedCornerShape(14.dp),
                                color = if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                border = BorderStroke(
                                    1.5.dp,
                                    if (sel) MaterialTheme.colorScheme.primary else Color.Transparent
                                )
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        icon,
                                        contentDescription = label,
                                        tint = if (sel) MaterialTheme.colorScheme.primary else tokens.mutedText,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        label,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(6.dp))

            OvozPrimaryButton(
                text = "Boshlash",
                icon = Icons.Rounded.Check,
                onClick = { onFinish(name.trim().ifEmpty { "Do‘st" }, language, currency, themeMode) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("onboarding_start_button")
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SelectableChipBox(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        border = BorderStroke(
            1.5.dp,
            if (selected) MaterialTheme.colorScheme.primary else Color.Transparent
        )
    ) {
        Box(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

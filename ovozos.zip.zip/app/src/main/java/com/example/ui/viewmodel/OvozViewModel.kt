package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiVoiceEngine
import com.example.ai.SemanticSearchResult
import com.example.core.Formatters
import com.example.core.guessExpenseCategory
import com.example.data.model.ActionLogItem
import com.example.data.model.AssistantMessage
import com.example.data.model.DailyReviewItem
import com.example.data.model.DebtItem
import com.example.data.model.FinanceTransaction
import com.example.data.model.ParsedAction
import com.example.data.model.ParsedActionType
import com.example.data.model.PersonItem
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.example.data.model.VoiceStage
import com.example.data.model.VoiceUiState
import com.example.data.repo.OvozRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

private const val TAG = "OvozViewModel"

sealed interface LoadState<out T> {
    data object Loading : LoadState<Nothing>
    data class Ready<T>(val data: T) : LoadState<T>
    data class Error(val message: String) : LoadState<Nothing>
}

data class UndoBannerState(
    val message: String,
    val batchId: String
)

data class SmartSearchUiState(
    val query: String = "",
    val isSearchingAi: Boolean = false,
    val filterType: String = "all", // all, tasks, expenses, debts, people
    val filterPerson: String = "",
    val aiResult: SemanticSearchResult? = null,
    val recentQueries: List<String> = emptyList(),
    val error: String = ""
)

data class ReportUiState(
    val isGenerating: Boolean = false,
    val period: String = "week", // week, month, year
    val aiSummary: String = "",
    val aiAdvice: String = "",
    val error: String = ""
)

class OvozViewModel(
    private val repository: OvozRepository,
    private val geminiEngine: GeminiVoiceEngine,
    val currentUserId: String
) : ViewModel() {

    private fun <T> Flow<T>.toSafeStateFlow(initial: LoadState<T> = LoadState.Loading): StateFlow<LoadState<T>> =
        this.map<T, LoadState<T>> { LoadState.Ready(it) }
            .catch { error ->
                val fsError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsError == null && error is CancellationException) throw error
                val root = fsError ?: error
                Log.w(TAG, "Stream error", root)
                emit(LoadState.Error(root.localizedMessage ?: "Ma’lumotlarni yuklashda xatolik"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.Eagerly,
                initialValue = initial
            )

    private fun <T> Flow<List<T>>.toListStateFlow(): StateFlow<List<T>> =
        this.catch { error ->
            val fsError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsError == null && error is CancellationException) throw error
            Log.w(TAG, "Collection stream error", fsError ?: error)
            emit(emptyList())
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = emptyList()
        )

    val profileState: StateFlow<LoadState<UserProfile?>> =
        repository.observeProfile(currentUserId).toSafeStateFlow()

    // Single shared real-time Firestore sources across Home, Tasks, Finance, Calendar, People, Voice & Reports
    val tasks: StateFlow<List<TaskItem>> = repository.observeTasks(currentUserId).toListStateFlow()
    private val allTransactions: StateFlow<List<FinanceTransaction>> =
        repository.observeTransactions(currentUserId).toListStateFlow()
    val expenses: StateFlow<List<FinanceTransaction>> = allTransactions
        .map { list -> list.filter { it.kind == "expense" } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val debts: StateFlow<List<DebtItem>> = repository.observeDebts(currentUserId).toListStateFlow()
    val people: StateFlow<List<PersonItem>> = repository.observePeople(currentUserId).toListStateFlow()
    val actionLogs: StateFlow<List<ActionLogItem>> = repository.observeActionLogs(currentUserId).toListStateFlow()
    val dailyReviews: StateFlow<List<DailyReviewItem>> = repository.observeDailyReviews(currentUserId).toListStateFlow()
    val chatMessages: StateFlow<List<AssistantMessage>> = repository.observeChatMessages(currentUserId).toListStateFlow()

    private val _voiceState = MutableStateFlow(VoiceUiState())
    val voiceState: StateFlow<VoiceUiState> = _voiceState.asStateFlow()

    // Decoupled high-frequency audio waveform flow so RMS updates never recompose transcript/buttons
    private val _voiceWaveform = MutableStateFlow(List(28) { 0.12f })
    val voiceWaveform: StateFlow<List<Float>> = _voiceWaveform.asStateFlow()

    private val _undoBanner = MutableStateFlow<UndoBannerState?>(null)
    val undoBanner: StateFlow<UndoBannerState?> = _undoBanner.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _searchState = MutableStateFlow(SmartSearchUiState())
    val searchState: StateFlow<SmartSearchUiState> = _searchState.asStateFlow()

    private val _assistantStreamingText = MutableStateFlow("")
    val assistantStreamingText: StateFlow<String> = _assistantStreamingText.asStateFlow()

    private val _assistantLoading = MutableStateFlow(false)
    val assistantLoading: StateFlow<Boolean> = _assistantLoading.asStateFlow()

    private val _assistantError = MutableStateFlow("")
    val assistantError: StateFlow<String> = _assistantError.asStateFlow()

    private val _reportState = MutableStateFlow(ReportUiState())
    val reportState: StateFlow<ReportUiState> = _reportState.asStateFlow()

    private val _financeInsightState = MutableStateFlow(ReportUiState(period = "month"))
    val financeInsightState: StateFlow<ReportUiState> = _financeInsightState.asStateFlow()

    private val _eveningGenerating = MutableStateFlow(false)
    val eveningGenerating: StateFlow<Boolean> = _eveningGenerating.asStateFlow()

    private val _geminiStatus = MutableStateFlow<String?>(null)
    val geminiStatus: StateFlow<String?> = _geminiStatus.asStateFlow()

    private val _pinUnlocked = MutableStateFlow(false)
    val pinUnlocked: StateFlow<Boolean> = _pinUnlocked.asStateFlow()

    private var timerJob: Job? = null
    private var analyzeJob: Job? = null
    private var lastRmsUpdateMs: Long = 0L
    private var lastCueDetectMs: Long = 0L

    val currentProfile: UserProfile
        get() = (profileState.value as? LoadState.Ready)?.data ?: UserProfile(userId = currentUserId)

    fun clearToast() {
        _toastMessage.value = null
    }

    fun dismissUndoBanner() {
        _undoBanner.value = null
    }

    fun unlockPin() {
        _pinUnlocked.value = true
    }

    // --- Onboarding & Profile ---
    fun completeOnboarding(
        displayName: String,
        language: String,
        currency: String,
        themeMode: String
    ) {
        viewModelScope.launch {
            val profile = UserProfile(
                userId = currentUserId,
                displayName = displayName.trim().ifEmpty { "Foydalanuvchi" },
                onboardingDone = true,
                language = language,
                primaryCurrency = currency,
                themeMode = themeMode
            )
            val res = repository.createOrCompleteProfile(currentUserId, profile)
            if (res.isFailure) {
                _toastMessage.value = "Sozlamalarni saqlashda xatolik yuz berdi."
            }
        }
    }

    fun updateProfile(updates: Map<String, Any>, toast: String? = null) {
        viewModelScope.launch {
            val res = repository.updateProfileFields(currentUserId, updates)
            if (res.isSuccess && toast != null) {
                _toastMessage.value = toast
            } else if (res.isFailure) {
                _toastMessage.value = "Saqlashda xatolik yuz berdi."
            }
        }
    }

    // --- Real-Time Voice Assistant Pipeline ---
    fun openVoiceModal() {
        geminiEngine.warmUp()
        _voiceWaveform.value = List(28) { 0.12f }
        _voiceState.value = VoiceUiState(
            isOpen = true,
            stage = VoiceStage.IDLE,
            speechLocale = when (currentProfile.language) {
                "ru" -> "ru-RU"
                "en" -> "en-US"
                else -> "auto"
            }
        )
    }

    fun closeVoiceModal() {
        timerJob?.cancel()
        analyzeJob?.cancel()
        _voiceState.update { it.copy(isOpen = false, stage = VoiceStage.IDLE) }
    }

    fun setSpeechLocale(locale: String) {
        _voiceState.update { it.copy(speechLocale = locale) }
    }

    fun onVoiceListeningStarted() {
        timerJob?.cancel()
        analyzeJob?.cancel()
        lastRmsUpdateMs = 0L
        lastCueDetectMs = 0L
        _voiceWaveform.value = List(28) { 0.14f }
        _voiceState.update {
            it.copy(
                stage = VoiceStage.LISTENING,
                elapsedSeconds = 0,
                transcript = "",
                partialTranscript = "",
                liveEntityCues = emptyList(),
                errorMessage = "",
                parsedActions = emptyList(),
                clarificationQuestion = "",
                assistantReply = ""
            )
        }
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                _voiceState.update { st ->
                    if (st.stage == VoiceStage.LISTENING || st.stage == VoiceStage.TRANSCRIBING) {
                        st.copy(elapsedSeconds = st.elapsedSeconds + 1)
                    } else st
                }
            }
        }
    }

    fun onVoiceRmsChanged(rmsDb: Float) {
        val now = System.currentTimeMillis()
        if (now - lastRmsUpdateMs < 55L) return
        lastRmsUpdateMs = now
        val normalized = ((rmsDb + 2f) / 12f).coerceIn(0.10f, 1.0f)
        _voiceWaveform.update { prev -> prev.drop(1) + normalized }
    }

    fun onVoicePartialResult(partial: String) {
        val now = System.currentTimeMillis()
        val shouldRefreshCues = (now - lastCueDetectMs) >= 220L || partial.endsWith(" ")
        val liveCues = if (shouldRefreshCues) {
            lastCueDetectMs = now
            geminiEngine.detectLiveEntities(partial)
        } else {
            _voiceState.value.liveEntityCues
        }
        _voiceState.update {
            it.copy(
                stage = VoiceStage.TRANSCRIBING,
                partialTranscript = partial,
                transcript = partial,
                liveEntityCues = liveCues
            )
        }
    }

    fun onVoiceFinalResult(finalText: String) {
        timerJob?.cancel()
        val clean = finalText.trim()
        val liveCues = geminiEngine.detectLiveEntities(clean)
        _voiceState.update {
            it.copy(
                transcript = clean,
                partialTranscript = clean,
                liveEntityCues = liveCues
            )
        }
        if (clean.isNotBlank()) {
            analyzeTranscript(clean)
        }
    }

    fun onVoiceError(message: String) {
        timerJob?.cancel()
        _voiceState.update { st ->
            if (st.transcript.isNotBlank()) {
                st.copy(stage = VoiceStage.IDLE, errorMessage = message)
            } else {
                st.copy(stage = VoiceStage.ERROR, errorMessage = message)
            }
        }
    }

    fun updateManualVoiceTranscript(text: String) {
        val cues = geminiEngine.detectLiveEntities(text)
        _voiceState.update {
            it.copy(
                transcript = text,
                partialTranscript = text,
                liveEntityCues = cues,
                errorMessage = ""
            )
        }
    }

    fun onVoiceAudioResult(audio: ByteArray) {
        analyzeTranscript("", audio)
    }

    fun analyzeTranscript(inputText: String = _voiceState.value.transcript, audio: ByteArray? = null) {
        val clean = inputText.trim()
        if (clean.isEmpty() && audio == null) return
        timerJob?.cancel()
        analyzeJob?.cancel()
        analyzeJob = viewModelScope.launch {
            _voiceState.update {
                it.copy(
                    stage = VoiceStage.ANALYZING,
                    transcript = clean,
                    liveEntityCues = geminiEngine.detectLiveEntities(clean),
                    errorMessage = ""
                )
            }
            try {
                val prof = currentProfile
                val result = geminiEngine.parseVoiceCommand(
                    transcript = clean,
                    primaryCurrency = prof.primaryCurrency,
                    responseLang = if (prof.aiResponseLang == "auto") prof.language else prof.aiResponseLang,
                    tasks = tasks.value,
                    debts = debts.value,
                    people = people.value,
                    recentExpenses = expenses.value,
                    audioBytes = audio
                )
                if (audio != null) {
                    _voiceState.update { it.copy(transcript = result.transcript, partialTranscript = result.transcript, liveEntityCues = result.recognizedEntities) }
                }

                val supportedActions = result.actions.filter {
                    it.type in setOf(
                        ParsedActionType.CREATE_TASK,
                        ParsedActionType.COMPLETE_TASK,
                        ParsedActionType.CREATE_EXPENSE,
                        ParsedActionType.CREATE_DEBT_BORROWED,
                        ParsedActionType.CREATE_DEBT_LENT,
                        ParsedActionType.PAY_DEBT,
                        ParsedActionType.UNDO_LAST_ACTION,
                        ParsedActionType.ANSWER_QUESTION
                    )
                }

                when {
                    result.clarificationQuestion.isNotBlank() -> {
                        _voiceState.update {
                            it.copy(
                                stage = VoiceStage.CLARIFYING,
                                clarificationQuestion = result.clarificationQuestion,
                                parsedActions = supportedActions,
                                assistantReply = result.assistantReply
                            )
                        }
                    }
                    result.isQuestionOnly || (supportedActions.isEmpty() && result.assistantReply.isNotBlank()) -> {
                        _voiceState.update {
                            it.copy(
                                stage = VoiceStage.ANSWERING,
                                assistantReply = result.assistantReply,
                                parsedActions = emptyList()
                            )
                        }
                    }
                    supportedActions.any { it.type == ParsedActionType.UNDO_LAST_ACTION } -> {
                        if (audio != null) {
                            _voiceState.update { it.copy(stage = VoiceStage.CLARIFYING, clarificationQuestion = "Oxirgi amalni bekor qilishni tasdiqlash uchun matnda ‘oxirgi amalni bekor qil’ deb yozing.", parsedActions = emptyList()) }
                            return@launch
                        }
                        val undone = undoMostRecentBatchInternal()
                        _voiceState.update {
                            it.copy(
                                stage = VoiceStage.ANSWERING,
                                assistantReply = if (undone > 0) {
                                    "Oxirgi $undone ta amal bekor qilindi."
                                } else {
                                    "Bekor qilinadigan oxirgi amal topilmadi."
                                }
                            )
                        }
                    }
                    supportedActions.isEmpty() -> {
                        _voiceState.update {
                            it.copy(
                                stage = VoiceStage.ERROR,
                                errorMessage = "Buyruqdan vazifa, xarajat yoki qarz aniqlanmadi. Qaytadan aniqroq ayting."
                            )
                        }
                    }
                    else -> {
                        _voiceState.update {
                            it.copy(
                                stage = VoiceStage.REVIEW,
                                parsedActions = supportedActions,
                                assistantReply = result.assistantReply
                            )
                        }
                        // Respect autoSaveVoice ONLY if no financial/debt changes
                        val hasFinancial = supportedActions.any {
                            it.type in setOf(
                                ParsedActionType.CREATE_EXPENSE,
                                ParsedActionType.CREATE_DEBT_BORROWED,
                                ParsedActionType.CREATE_DEBT_LENT,
                                ParsedActionType.PAY_DEBT
                            )
                        }
                        if (audio == null && prof.autoSaveVoice && !hasFinancial && supportedActions.isNotEmpty()) {
                            saveConfirmedVoiceActions()
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "analyzeTranscript error", e)
                _voiceState.update {
                    it.copy(
                        stage = VoiceStage.ERROR,
                        errorMessage = e.localizedMessage ?: "Sun’iy intellekt bilan bog‘lanishda xatolik yuz berdi."
                    )
                }
            }
        }
    }

    fun toggleParsedAction(localId: String) {
        _voiceState.update { st ->
            st.copy(
                parsedActions = st.parsedActions.map {
                    if (it.localId == localId) it.copy(selected = !it.selected) else it
                }
            )
        }
    }

    fun removeParsedAction(localId: String) {
        _voiceState.update { st ->
            st.copy(parsedActions = st.parsedActions.filterNot { it.localId == localId })
        }
    }

    fun updateParsedAction(updated: ParsedAction) {
        _voiceState.update { st ->
            st.copy(
                parsedActions = st.parsedActions.map {
                    if (it.localId == updated.localId) updated else it
                }
            )
        }
    }

    fun saveConfirmedVoiceActions() {
        val selected = _voiceState.value.parsedActions.filter { it.selected }
        if (selected.isEmpty()) {
            closeVoiceModal()
            return
        }
        viewModelScope.launch {
            _voiceState.update { it.copy(isSaving = true, errorMessage = "") }
            val batchId = "voice_${UUID.randomUUID().toString().take(8)}"
            val workingPeople = people.value.toMutableList()
            var savedCount = 0
            val failedActions = mutableListOf<ParsedAction>()
            var firstError = ""

            suspend fun resolvePersonId(name: String): Pair<String, String> {
                val clean = name.trim()
                if (clean.isEmpty()) return "" to ""
                val existing = workingPeople.firstOrNull { it.name.equals(clean, ignoreCase = true) }
                if (existing != null) return existing.id to existing.name
                val created = repository.ensurePerson(
                    uid = currentUserId,
                    name = clean,
                    existingPeople = workingPeople,
                    batchId = batchId,
                    sourceVoice = true
                ).getOrNull()
                if (created != null) {
                    workingPeople.add(created)
                    return created.id to created.name
                }
                return "" to clean
            }

            for (act in selected) {
                val (personId, personName) = resolvePersonId(act.personName)
                val result: Result<*> = when (act.type) {
                    ParsedActionType.CREATE_TASK -> {
                        repository.addTask(
                            uid = currentUserId,
                            task = TaskItem(
                                title = act.title.trim().ifEmpty { "Yangi vazifa" },
                                description = act.noteContent.ifBlank { act.subtitle },
                                dueDateMillis = act.dueDateMillis,
                                hasDueTime = act.hasDueTime,
                                priority = act.priority,
                                category = act.category.ifBlank { "Shaxsiy" },
                                personId = personId,
                                personName = personName,
                                reminderEnabled = act.dueDateMillis > 0L
                            ),
                            batchId = batchId,
                            sourceVoice = true
                        )
                    }
                    ParsedActionType.COMPLETE_TASK -> {
                        val target = tasks.value.firstOrNull { it.id == act.matchedEntityId }
                            ?: tasks.value.firstOrNull {
                                !it.completed && it.title.contains(act.title, ignoreCase = true)
                            }
                        if (target != null) {
                            val after = target.copy(
                                completed = true,
                                completedAtMillis = System.currentTimeMillis()
                            )
                            repository.updateTask(
                                uid = currentUserId,
                                before = target,
                                after = after,
                                summary = "Vazifa bajarildi: ${target.title}",
                                batchId = batchId,
                                sourceVoice = true
                            )
                        } else {
                            repository.addTask(
                                uid = currentUserId,
                                task = TaskItem(
                                    title = act.title.trim().ifEmpty { "Bajarilgan vazifa" },
                                    completed = true,
                                    completedAtMillis = System.currentTimeMillis(),
                                    category = act.category.ifBlank { "Shaxsiy" }
                                ),
                                batchId = batchId,
                                sourceVoice = true
                            )
                        }
                    }
                    ParsedActionType.CREATE_EXPENSE -> {
                        if (act.amount <= 0.0) {
                            Result.failure<Unit>(IllegalArgumentException("Xarajat summasi kiritilmagan"))
                        } else {
                            val cat = act.category.ifBlank { guessExpenseCategory(act.title) }
                            repository.addTransaction(
                                uid = currentUserId,
                                tx = FinanceTransaction(
                                    kind = "expense",
                                    amount = act.amount,
                                    currency = act.currency,
                                    category = cat,
                                    title = act.title.trim().ifEmpty { cat },
                                    note = act.noteContent,
                                    occurredAtMillis = if (act.dueDateMillis > 0L) act.dueDateMillis else System.currentTimeMillis(),
                                    personId = personId,
                                    personName = personName
                                ),
                                batchId = batchId,
                                sourceVoice = true
                            )
                        }
                    }
                    ParsedActionType.CREATE_DEBT_BORROWED, ParsedActionType.CREATE_DEBT_LENT -> {
                        if (act.amount <= 0.0) {
                            Result.failure<Unit>(IllegalArgumentException("Qarz summasi kiritilmagan"))
                        } else {
                            val dir = if (act.type == ParsedActionType.CREATE_DEBT_LENT) "lent" else "borrowed"
                            repository.addDebt(
                                uid = currentUserId,
                                debt = DebtItem(
                                    direction = dir,
                                    personId = personId,
                                    personName = personName.ifBlank { act.title.ifBlank { "Inson" } },
                                    originalAmount = act.amount,
                                    paidAmount = 0.0,
                                    currency = act.currency,
                                    note = act.noteContent.ifBlank { act.subtitle },
                                    issuedAtMillis = System.currentTimeMillis(),
                                    dueDateMillis = act.dueDateMillis
                                ),
                                batchId = batchId,
                                sourceVoice = true
                            )
                        }
                    }
                    ParsedActionType.PAY_DEBT -> {
                        val target = debts.value.firstOrNull { it.id == act.matchedEntityId && !it.closed }
                            ?: debts.value.firstOrNull {
                                !it.closed && it.personName.equals(act.personName, ignoreCase = true)
                            }
                        if (target != null) {
                            val payAmt = if (act.amount > 0.0) act.amount else target.remainingAmount
                            repository.recordDebtPayment(
                                uid = currentUserId,
                                debt = target,
                                paymentAmount = payAmt,
                                batchId = batchId,
                                sourceVoice = true
                            )
                        } else {
                            Result.failure<Unit>(IllegalArgumentException("Mos faol qarz topilmadi"))
                        }
                    }
                    else -> Result.success(Unit)
                }

                if (result.isSuccess) {
                    savedCount++
                } else {
                    failedActions.add(act)
                    if (firstError.isEmpty()) {
                        firstError = result.exceptionOrNull()?.localizedMessage ?: "Ma’lumotni saqlab bo‘lmadi"
                    }
                    Log.e(TAG, "Failed saving voice action ${act.type}: ${act.title}", result.exceptionOrNull())
                }
            }

            if (failedActions.isEmpty()) {
                _voiceState.update { it.copy(isSaving = false, isOpen = false, stage = VoiceStage.IDLE) }
                if (savedCount > 0) {
                    _undoBanner.value = UndoBannerState(
                        message = if (savedCount == 1) "Saqlandi" else "$savedCount ta amal saqlandi",
                        batchId = batchId
                    )
                }
            } else {
                // Never claim saved when any write failed! Keep failed actions visible so user can retry.
                _voiceState.update {
                    it.copy(
                        isSaving = false,
                        stage = VoiceStage.REVIEW,
                        parsedActions = failedActions,
                        errorMessage = if (savedCount > 0) {
                            "$savedCount ta amal saqlandi, lekin ${failedActions.size} tasida xatolik: $firstError"
                        } else {
                            "Saqlab bo‘lmadi: $firstError"
                        }
                    )
                }
            }
        }
    }

    // --- Direct CRUD Actions ---
    fun addTask(task: TaskItem) {
        viewModelScope.launch {
            val batchId = "task_${UUID.randomUUID().toString().take(8)}"
            var finalTask = task
            if (task.personName.isNotBlank() && task.personId.isBlank()) {
                val p = repository.ensurePerson(currentUserId, task.personName, people.value, batchId = batchId).getOrNull()
                if (p != null) finalTask = task.copy(personId = p.id, personName = p.name)
            }
            val res = repository.addTask(currentUserId, finalTask, batchId = batchId)
            if (res.isSuccess) {
                _undoBanner.value = UndoBannerState("Vazifa qo‘shildi", batchId)
            } else {
                _toastMessage.value = "Vazifani saqlab bo‘lmadi"
            }
        }
    }

    fun toggleTaskCompleted(task: TaskItem) {
        viewModelScope.launch {
            val batchId = "chk_${UUID.randomUUID().toString().take(8)}"
            val nowDone = !task.completed
            val after = task.copy(
                completed = nowDone,
                completedAtMillis = if (nowDone) System.currentTimeMillis() else 0L
            )
            val res = repository.updateTask(
                uid = currentUserId,
                before = task,
                after = after,
                summary = if (nowDone) "Vazifa bajarildi: ${task.title}" else "Vazifa qayta ochildi: ${task.title}",
                batchId = batchId
            )
            if (res.isSuccess) {
                if (nowDone && task.recurrence != "none" && task.dueDateMillis > 0L) {
                    val shiftDays = when (task.recurrence) {
                        "daily" -> 1L
                        "weekly" -> 7L
                        "monthly" -> 30L
                        else -> 0L
                    }
                    if (shiftDays > 0L) {
                        repository.addTask(
                            uid = currentUserId,
                            task = task.copy(
                                id = "",
                                completed = false,
                                completedAtMillis = 0L,
                                dueDateMillis = task.dueDateMillis + shiftDays * 86_400_000L
                            ),
                            batchId = batchId
                        )
                    }
                }
                _undoBanner.value = UndoBannerState(
                    if (nowDone) "«${task.title}» bajarildi" else "Vazifa qayta ochildi",
                    batchId
                )
            } else {
                _toastMessage.value = "Vazifani yangilab bo‘lmadi"
            }
        }
    }

    fun updateTask(before: TaskItem, after: TaskItem) {
        viewModelScope.launch {
            val batchId = "utask_${UUID.randomUUID().toString().take(8)}"
            val res = repository.updateTask(currentUserId, before, after, batchId = batchId)
            if (res.isSuccess) _undoBanner.value = UndoBannerState("Vazifa yangilandi", batchId)
            else _toastMessage.value = "Vazifani yangilab bo‘lmadi"
        }
    }

    fun rescheduleTaskToTomorrow(task: TaskItem) {
        val tomorrowNoon = Formatters.startOfDay() + 86_400_000L + 12L * 3_600_000L
        updateTask(task, task.copy(dueDateMillis = tomorrowNoon))
    }

    fun deleteTask(task: TaskItem) {
        viewModelScope.launch {
            val batchId = "dtask_${UUID.randomUUID().toString().take(8)}"
            val res = repository.deleteTask(currentUserId, task, batchId = batchId)
            if (res.isSuccess) _undoBanner.value = UndoBannerState("Vazifa o‘chirildi", batchId)
            else _toastMessage.value = "Vazifani o‘chirib bo‘lmadi"
        }
    }

    // --- Expenses (strictly kind == "expense") ---
    fun addExpense(tx: FinanceTransaction) {
        viewModelScope.launch {
            val batchId = "exp_${UUID.randomUUID().toString().take(8)}"
            var finalTx = tx.copy(kind = "expense")
            if (tx.personName.isNotBlank() && tx.personId.isBlank()) {
                val p = repository.ensurePerson(currentUserId, tx.personName, people.value, batchId = batchId).getOrNull()
                if (p != null) finalTx = finalTx.copy(personId = p.id, personName = p.name)
            }
            val res = repository.addTransaction(currentUserId, finalTx, batchId = batchId)
            if (res.isSuccess) _undoBanner.value = UndoBannerState("Xarajat saqlandi", batchId)
            else _toastMessage.value = "Xarajatni saqlab bo‘lmadi"
        }
    }

    fun updateExpense(before: FinanceTransaction, after: FinanceTransaction) {
        viewModelScope.launch {
            val res = repository.updateTransaction(currentUserId, before, after.copy(kind = "expense"))
            if (res.isSuccess) _toastMessage.value = "Xarajat yangilandi"
            else _toastMessage.value = "Xarajatni yangilab bo‘lmadi"
        }
    }

    fun deleteExpense(tx: FinanceTransaction) {
        viewModelScope.launch {
            val res = repository.deleteTransaction(currentUserId, tx)
            if (res.isSuccess) _toastMessage.value = "Xarajat o‘chirildi"
            else _toastMessage.value = "Xarajatni o‘chirib bo‘lmadi"
        }
    }

    // --- Debts ---
    fun addDebt(debt: DebtItem) {
        viewModelScope.launch {
            val batchId = "debt_${UUID.randomUUID().toString().take(8)}"
            val person = repository.ensurePerson(currentUserId, debt.personName, people.value, batchId = batchId).getOrNull()
            val linked = if (person != null) debt.copy(personId = person.id, personName = person.name) else debt
            val res = repository.addDebt(currentUserId, linked, batchId = batchId)
            if (res.isSuccess) _undoBanner.value = UndoBannerState("Qarz saqlandi", batchId)
            else _toastMessage.value = "Qarzni saqlab bo‘lmadi"
        }
    }

    fun payDebt(debt: DebtItem, amount: Double) {
        viewModelScope.launch {
            val batchId = "dpay_${UUID.randomUUID().toString().take(8)}"
            val res = repository.recordDebtPayment(currentUserId, debt, amount, batchId = batchId)
            if (res.isSuccess) _undoBanner.value = UndoBannerState("Qarz to‘lovi qayd etildi", batchId)
            else _toastMessage.value = "To‘lovni saqlab bo‘lmadi"
        }
    }

    fun deleteDebt(debt: DebtItem) {
        viewModelScope.launch {
            val res = repository.deleteDebt(currentUserId, debt)
            if (res.isSuccess) _toastMessage.value = "Qarz o‘chirildi"
            else _toastMessage.value = "Qarzni o‘chirib bo‘lmadi"
        }
    }

    // --- People ---
    fun addPerson(name: String, phone: String, note: String) {
        viewModelScope.launch {
            val res = repository.ensurePerson(currentUserId, name, people.value, phone, note)
            if (res.isSuccess) _toastMessage.value = "$name qo‘shildi"
            else _toastMessage.value = "Saqlab bo‘lmadi"
        }
    }

    fun updatePerson(before: PersonItem, after: PersonItem) {
        viewModelScope.launch {
            val res = repository.updatePerson(currentUserId, before, after)
            if (res.isSuccess) _toastMessage.value = "Ma’lumot yangilandi"
        }
    }

    fun deletePerson(person: PersonItem) {
        viewModelScope.launch {
            val res = repository.deletePerson(currentUserId, person)
            if (res.isSuccess) _toastMessage.value = "${person.name} o‘chirildi"
        }
    }

    // --- Undo ---
    fun undoBannerBatch() {
        val banner = _undoBanner.value ?: return
        _undoBanner.value = null
        viewModelScope.launch {
            val logs = actionLogs.value.filter { it.batchId == banner.batchId && !it.reverted }
            val res = repository.undoBatch(currentUserId, logs)
            if (res.isSuccess) {
                _toastMessage.value = "Amal bekor qilindi"
            }
        }
    }

    fun undoSingleAction(log: ActionLogItem) {
        viewModelScope.launch {
            val res = repository.undoActionLog(currentUserId, log)
            if (res.isSuccess) _toastMessage.value = "Oldingi holat tiklandi"
            else _toastMessage.value = "Amalni bekor qilib bo‘lmadi"
        }
    }

    fun undoBatchById(batchId: String) {
        viewModelScope.launch {
            val logs = actionLogs.value.filter { it.batchId == batchId && !it.reverted }
            val res = repository.undoBatch(currentUserId, logs)
            if (res.isSuccess) _toastMessage.value = "${res.getOrDefault(0)} ta amal bekor qilindi"
        }
    }

    private suspend fun undoMostRecentBatchInternal(): Int {
        val latest = actionLogs.value
            .filter { !it.reverted }
            .maxByOrNull { it.createdAt?.seconds ?: 0L } ?: return 0
        val batchLogs = actionLogs.value.filter { it.batchId == latest.batchId && !it.reverted }
        return repository.undoBatch(currentUserId, batchLogs).getOrDefault(0)
    }

    // --- Smart Search ---
    fun updateSearchQuery(q: String) {
        _searchState.update { it.copy(query = q, error = "") }
    }

    fun setSearchFilterType(type: String) {
        _searchState.update { it.copy(filterType = type) }
    }

    fun setSearchFilterPerson(person: String) {
        _searchState.update { it.copy(filterPerson = person) }
    }

    fun runSemanticSearch(queryOverride: String? = null) {
        val q = (queryOverride ?: _searchState.value.query).trim()
        if (q.isEmpty()) return
        _searchState.update { st ->
            val recents = (listOf(q) + st.recentQueries.filterNot { it == q }).take(6)
            st.copy(query = q, isSearchingAi = true, recentQueries = recents, error = "")
        }
        viewModelScope.launch {
            try {
                val res = geminiEngine.semanticSearch(
                    query = q,
                    tasks = tasks.value,
                    expenses = expenses.value,
                    debts = debts.value,
                    people = people.value
                )
                _searchState.update { it.copy(isSearchingAi = false, aiResult = res) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _searchState.update {
                    it.copy(
                        isSearchingAi = false,
                        error = e.localizedMessage ?: "Qidiruvda xatolik yuz berdi"
                    )
                }
            }
        }
    }

    // --- Conversational AI Assistant ---
    fun sendAssistantQuestion(text: String, voiceInput: Boolean = false) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            _assistantError.value = ""
            _assistantLoading.value = true
            _assistantStreamingText.value = ""
            repository.addChatMessage(
                currentUserId,
                AssistantMessage(role = "user", text = clean, voiceInput = voiceInput)
            )
            try {
                val prof = currentProfile
                val lower = clean.lowercase()
                val attachment = when {
                    lower.contains("qarz") || lower.contains("долг") -> "debts"
                    lower.contains("pul") || lower.contains("xarajat") || lower.contains("moliya") || lower.contains("расход") -> "expenses"
                    lower.contains("reja") || lower.contains("vazifa") || lower.contains("ish") || lower.contains("ertaga") -> "tasks"
                    else -> "none"
                }
                var fullAnswer = ""
                geminiEngine.askAssistantStream(
                    question = clean,
                    responseLang = if (prof.aiResponseLang == "auto") prof.language else prof.aiResponseLang,
                    responseLength = prof.aiResponseLength,
                    primaryCurrency = prof.primaryCurrency,
                    tasks = tasks.value,
                    expenses = expenses.value,
                    debts = debts.value,
                    people = people.value
                ).collect { partial ->
                    fullAnswer = partial
                    _assistantStreamingText.value = partial
                }
                if (fullAnswer.isNotBlank()) {
                    repository.addChatMessage(
                        currentUserId,
                        AssistantMessage(
                            role = "assistant",
                            text = fullAnswer,
                            attachmentType = attachment
                        )
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Assistant error", e)
                _assistantError.value = e.localizedMessage ?: "Javob olishda xatolik yuz berdi."
            } finally {
                _assistantLoading.value = false
                _assistantStreamingText.value = ""
            }
        }
    }

    fun clearAssistantChat() {
        viewModelScope.launch {
            repository.clearChatHistory(currentUserId)
            _toastMessage.value = "Suhbat tarixi tozalandi"
        }
    }

    // --- Finance Kuzatuv AI Insight (Strictly Expenses + Debts) ---
    fun generateFinanceInsight(period: String, currency: String) {
        viewModelScope.launch {
            _financeInsightState.value = ReportUiState(isGenerating = true, period = period)
            try {
                val periodExp = expenses.value.filter { it.currency == currency && Formatters.isInPeriod(it.occurredAtMillis, period) }
                val totalExp = periodExp.sumOf { it.amount }
                val byCat = periodExp.groupBy { it.category }
                    .entries.sortedByDescending { e -> e.value.sumOf { it.amount } }
                    .take(5)
                    .joinToString { "${it.key}: ${Formatters.formatMoney(it.value.sumOf { tx -> tx.amount }, currency)}" }

                val activeDebts = debts.value.filter { !it.closed && it.currency == currency }
                val borrowed = activeDebts.filter { it.direction == "borrowed" }.sumOf { it.remainingAmount }
                val lent = activeDebts.filter { it.direction == "lent" }.sumOf { it.remainingAmount }

                if (periodExp.isEmpty() && activeDebts.isEmpty()) {
                    _financeInsightState.value = ReportUiState(
                        isGenerating = false,
                        period = period,
                        aiSummary = "Tahlil uchun xarajat yoki qarz ma’lumotlari yo‘q.",
                        aiAdvice = ""
                    )
                    return@launch
                }

                val periodName = when (period) {
                    "today" -> "Bugun"
                    "week" -> "Shu hafta"
                    "year" -> "Shu yil"
                    else -> "Shu oy"
                }
                val stats = """
                    Davr: $periodName ($currency)
                    Jami xarajat: ${Formatters.formatMoney(totalExp, currency)} (${periodExp.size} ta yozuv)
                    Asosiy turkumlar: ${byCat.ifEmpty { "yo‘q" }}
                    Men qaytarishim kerak bo‘lgan qarzlar: ${Formatters.formatMoney(borrowed, currency)}
                    Menga qaytarishlari kerak bo‘lgan qarzlar: ${Formatters.formatMoney(lent, currency)}
                """.trimIndent()

                val (summary, advice) = geminiEngine.generateDailyOrPeriodInsight(
                    periodTitle = "Moliyaviy kuzatuv ($periodName)",
                    statsSummary = stats,
                    lang = currentProfile.language
                )
                _financeInsightState.value = ReportUiState(
                    isGenerating = false,
                    period = period,
                    aiSummary = summary,
                    aiAdvice = advice
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _financeInsightState.value = ReportUiState(
                    isGenerating = false,
                    period = period,
                    error = e.localizedMessage ?: "Tahlil yaratishda xatolik"
                )
            }
        }
    }

    // --- Evening Daily Review (Strictly Tasks + Expenses + Debts) ---
    fun generateTodayReview() {
        viewModelScope.launch {
            _eveningGenerating.value = true
            try {
                val cur = currentProfile.primaryCurrency
                val todayTasks = tasks.value.filter {
                    Formatters.isToday(it.dueDateMillis) ||
                        (it.completed && Formatters.isToday(it.completedAtMillis))
                }
                val doneCount = todayTasks.count { it.completed }
                val pendingCount = todayTasks.count { !it.completed }
                val overdueCount = tasks.value.count { Formatters.isOverdue(it.dueDateMillis, it.completed) }
                val totalCount = doneCount + pendingCount
                val percent = if (totalCount > 0) (doneCount * 100 / totalCount) else 0

                val todayExpenses = expenses.value.filter {
                    it.currency == cur && Formatters.isToday(it.occurredAtMillis)
                }
                val expense = todayExpenses.sumOf { it.amount }
                val topCat = todayExpenses
                    .groupBy { it.category }
                    .maxByOrNull { e -> e.value.sumOf { it.amount } }?.key.orEmpty()

                val activeBorrowed = debts.value.filter { !it.closed && it.currency == cur && it.direction == "borrowed" }.sumOf { it.remainingAmount }
                val activeLent = debts.value.filter { !it.closed && it.currency == cur && it.direction == "lent" }.sumOf { it.remainingAmount }
                val tomorrowTasks = tasks.value.filter { !it.completed && Formatters.isTomorrow(it.dueDateMillis) }

                val stats = """
                    Bugungi sana: ${Formatters.dateKeyFor()}
                    Bajarilgan vazifalar: $doneCount ta, bajarilmagan: $pendingCount ta ($percent%), kechikkan: $overdueCount ta.
                    Bugungi xarajatlar: ${Formatters.formatMoney(expense, cur)}. Eng katta turkum: ${topCat.ifEmpty { "yo‘q" }}.
                    Faol qarzlar ($cur): Men qaytarishim kerak ${Formatters.formatMoney(activeBorrowed, cur)}, menga qaytarishlari kerak ${Formatters.formatMoney(activeLent, cur)}.
                    Ertangi rejalar (${tomorrowTasks.size} ta): ${tomorrowTasks.take(5).joinToString { it.title }}.
                """.trimIndent()

                val (summary, advice) = geminiEngine.generateDailyOrPeriodInsight(
                    periodTitle = "Kun yakuni hisoboti",
                    statsSummary = stats,
                    lang = currentProfile.language
                )

                repository.saveDailyReview(
                    currentUserId,
                    DailyReviewItem(
                        dateKey = Formatters.dateKeyFor(),
                        completedTasksCount = doneCount.toLong(),
                        pendingTasksCount = pendingCount.toLong(),
                        completionPercent = percent.toLong(),
                        totalIncome = 0.0,
                        totalExpense = expense,
                        currency = cur,
                        topExpenseCategory = topCat,
                        aiSummary = summary,
                        tomorrowAdvice = advice
                    )
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _toastMessage.value = "Kun yakuni tahlilida xatolik: ${e.localizedMessage ?: "aloqa yo‘q"}"
            } finally {
                _eveningGenerating.value = false
            }
        }
    }

    // --- Weekly / Monthly Reports (Strictly Tasks + Expenses + Debts) ---
    fun generatePeriodReport(period: String) {
        viewModelScope.launch {
            _reportState.value = ReportUiState(isGenerating = true, period = period)
            try {
                val now = System.currentTimeMillis()
                val days = if (period == "month") 30L else 7L
                val start = now - days * 86_400_000L
                val prevStart = start - days * 86_400_000L
                val cur = currentProfile.primaryCurrency

                val periodExp = expenses.value.filter { it.currency == cur && it.occurredAtMillis >= start }
                val prevExpList = expenses.value.filter { it.currency == cur && it.occurredAtMillis in prevStart until start }

                val exp = periodExp.sumOf { it.amount }
                val prevExp = prevExpList.sumOf { it.amount }

                val completedTasks = tasks.value.count { it.completed && it.completedAtMillis >= start }
                val pendingTasks = tasks.value.count { !it.completed }
                val overdueTasks = tasks.value.count { Formatters.isOverdue(it.dueDateMillis, it.completed) }
                val activeBorrowed = debts.value.filter { !it.closed && it.currency == cur && it.direction == "borrowed" }.sumOf { it.remainingAmount }
                val activeLent = debts.value.filter { !it.closed && it.currency == cur && it.direction == "lent" }.sumOf { it.remainingAmount }
                val closedDebtsInPeriod = debts.value.count { it.closed && it.closedAtMillis >= start }

                if (periodExp.isEmpty() && tasks.value.isEmpty() && debts.value.isEmpty()) {
                    _reportState.value = ReportUiState(
                        isGenerating = false,
                        period = period,
                        aiSummary = "Ushbu davr uchun hali ma’lumot yo‘q.",
                        aiAdvice = ""
                    )
                    return@launch
                }

                val byCat = periodExp
                    .groupBy { it.category }
                    .entries.sortedByDescending { e -> e.value.sumOf { it.amount } }
                    .take(5)
                    .joinToString { "${it.key}: ${Formatters.formatMoney(it.value.sumOf { tx -> tx.amount }, cur)}" }

                val stats = """
                    Davr: ${if (period == "month") "Oxirgi 30 kun (Oylik)" else "Oxirgi 7 kun (Haftalik)"}
                    Jami xarajatlar: ${Formatters.formatMoney(exp, cur)} (oldingi davr: ${Formatters.formatMoney(prevExp, cur)})
                    Xarajat turkumlari: ${byCat.ifEmpty { "yo‘q" }}
                    Vazifalar: bajarilgan $completedTasks ta, faol $pendingTasks ta, kechikkan $overdueTasks ta
                    Qarzlar ($cur): men qaytarishim kerak ${Formatters.formatMoney(activeBorrowed, cur)}, menga qaytarishlari kerak ${Formatters.formatMoney(activeLent, cur)}, davrda yopilgan qarzlar: $closedDebtsInPeriod ta
                """.trimIndent()

                val (summary, advice) = geminiEngine.generateDailyOrPeriodInsight(
                    periodTitle = if (period == "month") "Oylik hisobot" else "Haftalik hisobot",
                    statsSummary = stats,
                    lang = currentProfile.language
                )
                _reportState.value = ReportUiState(
                    isGenerating = false,
                    period = period,
                    aiSummary = summary,
                    aiAdvice = advice
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _reportState.value = ReportUiState(
                    isGenerating = false,
                    period = period,
                    error = e.localizedMessage ?: "Hisobot yaratishda xatolik"
                )
            }
        }
    }

    // --- Backup, Restore, Wipe & Gemini Connection ---
    fun buildBackupJson(): String = repository.buildBackupJson(
        profile = currentProfile,
        tasks = tasks.value,
        notes = emptyList(),
        transactions = expenses.value,
        debts = debts.value,
        people = people.value,
        goals = emptyList()
    )

    fun restoreBackupJson(rawJson: String) {
        viewModelScope.launch {
            val res = repository.restoreFromBackupJson(currentUserId, rawJson)
            if (res.isSuccess) {
                _toastMessage.value = "${res.getOrDefault(0)} ta yozuv tiklandi"
            } else {
                _toastMessage.value = "Zaxira faylini o‘qishda xatolik"
            }
        }
    }

    fun wipeAllData() {
        viewModelScope.launch {
            val res = repository.wipeAllUserData(currentUserId)
            if (res.isSuccess) _toastMessage.value = "Barcha shaxsiy ma’lumotlar o‘chirildi"
            else _toastMessage.value = "Ma’lumotlarni o‘chirishda xatolik"
        }
    }

    fun checkGeminiHealth() {
        viewModelScope.launch {
            _geminiStatus.value = "Tekshirilmoqda..."
            val res = geminiEngine.checkGeminiConnection()
            _geminiStatus.value = if (res.isSuccess) {
                "Ulanish faol (Gemini)"
            } else {
                "Ulanishda xatolik: ${res.exceptionOrNull()?.localizedMessage ?: "Aloqa yo‘q"}"
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
        analyzeJob?.cancel()
    }
}

package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.statusBars
import androidx.compose.material3.HorizontalDivider
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.core.AppStrings
import com.example.core.Formatters
import com.example.ui.theme.ChartPalette
import com.example.ui.theme.LocalOvozTokens
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

@Composable
fun OvozCard(
    modifier: Modifier = Modifier,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    cornerRadius: Dp = 22.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val tokens = LocalOvozTokens.current
    val shape = RoundedCornerShape(cornerRadius)
    Surface(
        modifier = modifier
            .then(if (onClick != null) Modifier.clip(shape).clickable(onClick = onClick) else Modifier),
        shape = shape,
        color = containerColor,
        tonalElevation = if (tokens.isDark) 1.dp else 0.dp,
        shadowElevation = if (tokens.isDark) 0.dp else 2.dp,
        border = BorderStroke(1.dp, tokens.cardBorder.copy(alpha = if (tokens.isDark) 0.7f else 0.85f))
    ) {
        content()
    }
}

@Composable
fun OvozPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    loading: Boolean = false
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "btn_scale"
    )

    Button(
        onClick = onClick,
        enabled = enabled && !loading,
        interactionSource = interactionSource,
        shape = RoundedCornerShape(16.dp),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ),
        modifier = modifier
            .scale(scale)
            .minimumInteractiveComponentSize()
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                color = MaterialTheme.colorScheme.onPrimary,
                strokeWidth = 2.dp
            )
        } else {
            if (icon != null) {
                Icon(icon, contentDescription = null, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(8.dp))
            }
            Text(text, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
fun OvozFloatingBottomBar(
    currentTab: String,
    strings: AppStrings,
    onSelectTab: (String) -> Unit,
    onMicClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    val surface = MaterialTheme.colorScheme.surface

    Box(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        // Clean floating pill bar
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(66.dp),
            shape = RoundedCornerShape(30.dp),
            color = surface.copy(alpha = 0.98f),
            shadowElevation = 6.dp,
            border = BorderStroke(1.dp, tokens.cardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                NavTabItem(
                    label = strings.navHome,
                    selected = currentTab == "home",
                    selectedIcon = Icons.Rounded.Home,
                    unselectedIcon = Icons.Outlined.Home,
                    tag = "nav_home",
                    onClick = { onSelectTab("home") },
                    modifier = Modifier.weight(1f)
                )
                NavTabItem(
                    label = strings.navTasks,
                    selected = currentTab == "tasks",
                    selectedIcon = Icons.Rounded.CheckCircle,
                    unselectedIcon = Icons.Outlined.CheckCircle,
                    tag = "nav_tasks",
                    onClick = { onSelectTab("tasks") },
                    modifier = Modifier.weight(1f)
                )

                Spacer(Modifier.width(72.dp))

                NavTabItem(
                    label = strings.navFinance,
                    selected = currentTab == "finance",
                    selectedIcon = Icons.Rounded.AccountBalanceWallet,
                    unselectedIcon = Icons.Outlined.AccountBalanceWallet,
                    tag = "nav_finance",
                    onClick = { onSelectTab("finance") },
                    modifier = Modifier.weight(1f)
                )
                NavTabItem(
                    label = strings.navMore,
                    selected = currentTab == "more",
                    selectedIcon = Icons.Rounded.GridView,
                    unselectedIcon = Icons.Outlined.GridView,
                    tag = "nav_more",
                    onClick = { onSelectTab("more") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Clean elevated central Microphone button (no continuous pulsing halo)
        val micInteraction = remember { MutableInteractionSource() }
        val micPressed by micInteraction.collectIsPressedAsState()
        val micScale by animateFloatAsState(
            targetValue = if (micPressed) 0.92f else 1f,
            animationSpec = spring(stiffness = Spring.StiffnessMedium),
            label = "mic_press"
        )

        Box(
            modifier = Modifier
                .offset(y = (-14).dp)
                .size(60.dp)
                .scale(micScale)
                .shadow(6.dp, CircleShape)
                .clip(CircleShape)
                .background(primary)
                .border(2.dp, surface, CircleShape)
                .clickable(
                    interactionSource = micInteraction,
                    indication = null,
                    onClick = onMicClick
                )
                .testTag("central_mic_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.Mic,
                contentDescription = strings.navVoice,
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
fun OvozNavigationRail(
    currentTab: String,
    strings: AppStrings,
    onSelectTab: (String) -> Unit,
    onMicClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    val surface = MaterialTheme.colorScheme.surface

    Surface(
        modifier = modifier
            .fillMaxHeight()
            .width(88.dp),
        color = surface,
        border = BorderStroke(1.dp, tokens.cardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(vertical = 18.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .shadow(4.dp, CircleShape)
                    .clip(CircleShape)
                    .background(primary)
                    .clickable(onClick = onMicClick)
                    .testTag("central_mic_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Mic,
                    contentDescription = strings.navVoice,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(26.dp)
                )
            }
            HorizontalDivider(color = tokens.cardBorder, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
            NavTabItem(
                label = strings.navHome,
                selected = currentTab == "home",
                selectedIcon = Icons.Rounded.Home,
                unselectedIcon = Icons.Outlined.Home,
                tag = "nav_home",
                onClick = { onSelectTab("home") },
                modifier = Modifier.fillMaxWidth()
            )
            NavTabItem(
                label = strings.navTasks,
                selected = currentTab == "tasks",
                selectedIcon = Icons.Rounded.CheckCircle,
                unselectedIcon = Icons.Outlined.CheckCircle,
                tag = "nav_tasks",
                onClick = { onSelectTab("tasks") },
                modifier = Modifier.fillMaxWidth()
            )
            NavTabItem(
                label = strings.navFinance,
                selected = currentTab == "finance",
                selectedIcon = Icons.Rounded.AccountBalanceWallet,
                unselectedIcon = Icons.Outlined.AccountBalanceWallet,
                tag = "nav_finance",
                onClick = { onSelectTab("finance") },
                modifier = Modifier.fillMaxWidth()
            )
            NavTabItem(
                label = strings.navMore,
                selected = currentTab == "more",
                selectedIcon = Icons.Rounded.GridView,
                unselectedIcon = Icons.Outlined.GridView,
                tag = "nav_more",
                onClick = { onSelectTab("more") },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun NavTabItem(
    label: String,
    selected: Boolean,
    selectedIcon: ImageVector,
    unselectedIcon: ImageVector,
    tag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeColor by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.primary else LocalOvozTokens.current.mutedText,
        animationSpec = tween(200),
        label = "tab_color"
    )
    val pillWidth by animateDpAsState(
        targetValue = if (selected) 26.dp else 0.dp,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "tab_pill"
    )

    Column(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp)
            .testTag(tag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = if (selected) selectedIcon else unselectedIcon,
            contentDescription = label,
            tint = activeColor,
            modifier = Modifier.size(23.dp)
        )
        Spacer(Modifier.height(3.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = activeColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
        )
        Spacer(Modifier.height(2.dp))
        Box(
            modifier = Modifier
                .width(pillWidth)
                .height(3.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
        )
    }
}

@Composable
fun OvozUndoSnackbar(
    message: String,
    undoLabel: String,
    onUndo: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.onBackground,
        contentColor = MaterialTheme.colorScheme.background,
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            TextButton(
                onClick = onUndo,
                modifier = Modifier.testTag("undo_action_button")
            ) {
                Icon(
                    Icons.Rounded.Undo,
                    contentDescription = undoLabel,
                    tint = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    undoLabel,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun OvozEmptyState(
    title: String,
    subtitle: String,
    actionLabel: String,
    onAction: () -> Unit,
    secondaryActionLabel: String? = null,
    onSecondaryAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val primary = MaterialTheme.colorScheme.primary
    val container = MaterialTheme.colorScheme.primaryContainer
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Editorial bespoke Canvas artwork (soundwave rings + floating calm orb)
        Canvas(modifier = Modifier.size(136.dp)) {
            val c = Offset(size.width / 2f, size.height / 2f)
            drawCircle(
                color = container.copy(alpha = 0.55f),
                radius = size.minDimension * 0.48f,
                center = c
            )
            drawCircle(
                color = primary.copy(alpha = 0.14f),
                radius = size.minDimension * 0.36f,
                center = c,
                style = Stroke(width = 3f)
            )
            drawCircle(
                color = primary.copy(alpha = 0.24f),
                radius = size.minDimension * 0.24f,
                center = c
            )
            // Stylized acoustic bars inside orb
            val barHeights = listOf(0.14f, 0.24f, 0.34f, 0.22f, 0.14f)
            val barW = size.width * 0.042f
            val gap = size.width * 0.032f
            val totalW = barHeights.size * barW + (barHeights.size - 1) * gap
            var startX = c.x - totalW / 2f
            barHeights.forEach { hFrac ->
                val h = size.height * hFrac
                drawRoundRect(
                    color = primary,
                    topLeft = Offset(startX, c.y - h / 2f),
                    size = Size(barW, h),
                    cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                )
                startX += barW + gap
            }
            // Decorative floating dots
            drawCircle(color = primary.copy(alpha = 0.5f), radius = 5f, center = Offset(c.x + 48f, c.y - 42f))
            drawCircle(color = surfaceVariant, radius = 8f, center = Offset(c.x - 50f, c.y + 36f))
        }
        Spacer(Modifier.height(14.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            color = LocalOvozTokens.current.mutedText
        )
        Spacer(Modifier.height(18.dp))
        OvozPrimaryButton(
            text = actionLabel,
            onClick = onAction,
            modifier = Modifier.testTag("empty_primary_action")
        )
        if (secondaryActionLabel != null && onSecondaryAction != null) {
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onSecondaryAction) {
                Text(secondaryActionLabel, color = primary)
            }
        }
    }
}

@Composable
fun OvozProgressRing(
    progress: Float,
    size: Dp = 74.dp,
    strokeWidth: Dp = 7.dp,
    ringColor: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    centerContent: @Composable () -> Unit
) {
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "ring_progress"
    )
    Box(modifier = Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokePx = strokeWidth.toPx()
            val arcSize = Size(this.size.width - strokePx, this.size.height - strokePx)
            val topLeft = Offset(strokePx / 2f, strokePx / 2f)
            drawArc(
                color = trackColor,
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )
            drawArc(
                color = ringColor,
                startAngle = -90f,
                sweepAngle = 360f * animated,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )
        }
        centerContent()
    }
}

@Composable
fun PersonInitialBadge(
    name: String,
    colorKey: String = "emerald",
    size: Dp = 44.dp
) {
    val bg = when (colorKey) {
        "ocean" -> Color(0xFF146C94)
        "amber" -> Color(0xFFB4651D)
        "violet" -> Color(0xFF5E4BA8)
        "coral" -> Color(0xFFC74B3E)
        else -> Color(0xFF167D69)
    }
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(bg.copy(alpha = 0.16f))
            .border(1.dp, bg.copy(alpha = 0.35f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = Formatters.initialsFor(name),
            style = MaterialTheme.typography.titleSmall,
            color = bg,
            fontWeight = FontWeight.Bold
        )
    }
}

// --- Interactive Canvas Charts (Tappable slices, bars & points!) ---

data class ChartSlice(
    val label: String,
    val value: Double,
    val color: Color
)

@Composable
fun InteractiveDonutChart(
    slices: List<ChartSlice>,
    selectedLabel: String?,
    onSelectSlice: (String?) -> Unit,
    centerTitle: String,
    centerSubtitle: String,
    modifier: Modifier = Modifier
) {
    val total = slices.sumOf { it.value }.coerceAtLeast(0.01)
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(
            modifier = Modifier
                .size(190.dp)
                .pointerInput(slices, selectedLabel) {
                    detectTapGestures { tap ->
                        val cx = size.width / 2f
                        val cy = size.height / 2f
                        val dx = tap.x - cx
                        val dy = tap.y - cy
                        val dist = hypot(dx, dy)
                        if (dist < size.width * 0.22f) {
                            onSelectSlice(null)
                            return@detectTapGestures
                        }
                        var angle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat() + 90f
                        if (angle < 0f) angle += 360f
                        var accum = 0f
                        for (s in slices) {
                            val sweep = (s.value / total * 360.0).toFloat()
                            if (angle in accum..(accum + sweep)) {
                                onSelectSlice(if (selectedLabel == s.label) null else s.label)
                                return@detectTapGestures
                            }
                            accum += sweep
                        }
                    }
                }
        ) {
            val baseStroke = 26.dp.toPx()
            val selectedStroke = 33.dp.toPx()
            val pad = selectedStroke / 2f + 4f
            val arcSize = Size(size.width - pad * 2f, size.height - pad * 2f)
            val topLeft = Offset(pad, pad)
            var start = -90f
            slices.forEach { slice ->
                val sweep = ((slice.value / total) * 360.0).toFloat().coerceAtLeast(2f)
                val isSelected = selectedLabel == slice.label
                val alpha = if (selectedLabel == null || isSelected) 1f else 0.35f
                drawArc(
                    color = slice.color.copy(alpha = alpha),
                    startAngle = start,
                    sweepAngle = (sweep - 2f).coerceAtLeast(1f),
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(
                        width = if (isSelected) selectedStroke else baseStroke,
                        cap = StrokeCap.Butt
                    )
                )
                start += sweep
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = centerTitle,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
            Text(
                text = centerSubtitle,
                style = MaterialTheme.typography.labelSmall,
                color = LocalOvozTokens.current.mutedText,
                maxLines = 1
            )
        }
    }
}

data class ExpenseBarPoint(
    val label: String,
    val amount: Double
)

@Composable
fun InteractiveExpenseBarChart(
    points: List<ExpenseBarPoint>,
    selectedIndex: Int?,
    onSelectIndex: (Int?) -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    val maxVal = points.maxOfOrNull { it.amount }?.coerceAtLeast(1.0) ?: 1.0

    Column(modifier = modifier.fillMaxWidth()) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(152.dp)
                .pointerInput(points, selectedIndex) {
                    detectTapGestures { offset ->
                        if (points.isEmpty()) return@detectTapGestures
                        val slot = size.width / points.size.toFloat()
                        val idx = (offset.x / slot).toInt().coerceIn(0, points.lastIndex)
                        onSelectIndex(if (selectedIndex == idx) null else idx)
                    }
                }
        ) {
            if (points.isEmpty()) return@Canvas
            val slotW = size.width / points.size.toFloat()
            val barW = (slotW * 0.42f).coerceIn(10.dp.toPx(), 24.dp.toPx())
            val chartH = size.height - 12.dp.toPx()

            for (i in 0..3) {
                val y = chartH * (i / 3f)
                drawLine(
                    color = tokens.cardBorder.copy(alpha = 0.45f),
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            points.forEachIndexed { idx, p ->
                val centerX = slotW * idx + slotW / 2f
                val isSel = selectedIndex == null || selectedIndex == idx
                val barColor = if (selectedIndex == idx) primary else tokens.expense.copy(alpha = if (isSel) 0.85f else 0.28f)
                val barH = ((p.amount / maxVal) * chartH).toFloat().coerceAtLeast(if (p.amount > 0) 6f else 0f)
                if (barH > 0f) {
                    drawRoundRect(
                        color = barColor,
                        topLeft = Offset(centerX - barW / 2f, chartH - barH),
                        size = Size(barW, barH),
                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                    )
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            points.forEachIndexed { idx, p ->
                val active = selectedIndex == idx
                Text(
                    text = p.label,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSelectIndex(if (active) null else idx) },
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (active) primary else tokens.mutedText,
                    fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun InteractiveTrendLineChart(
    values: List<Pair<String, Double>>,
    selectedIndex: Int?,
    onSelectIndex: (Int?) -> Unit,
    modifier: Modifier = Modifier
) {
    val primary = MaterialTheme.colorScheme.primary
    val tokens = LocalOvozTokens.current
    if (values.isEmpty()) return
    val minV = values.minOf { it.second }
    val maxV = values.maxOf { it.second }
    val span = (maxV - minV).coerceAtLeast(1.0)

    Column(modifier = modifier.fillMaxWidth()) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(148.dp)
                .pointerInput(values, selectedIndex) {
                    detectTapGestures { offset ->
                        val step = if (values.size > 1) size.width / (values.size - 1).toFloat() else size.width.toFloat()
                        val idx = if (values.size > 1) ((offset.x + step / 2f) / step).toInt().coerceIn(0, values.lastIndex) else 0
                        onSelectIndex(if (selectedIndex == idx) null else idx)
                    }
                }
        ) {
            val padY = 14.dp.toPx()
            val usableH = size.height - padY * 2f
            val stepX = if (values.size > 1) size.width / (values.size - 1).toFloat() else size.width / 2f

            val coords = values.mapIndexed { idx, pair ->
                val x = if (values.size > 1) idx * stepX else size.width / 2f
                val norm = ((pair.second - minV) / span).toFloat()
                val y = padY + usableH * (1f - norm)
                Offset(x, y)
            }

            if (coords.size >= 2) {
                val fillPath = Path().apply {
                    moveTo(coords.first().x, size.height)
                    coords.forEach { lineTo(it.x, it.y) }
                    lineTo(coords.last().x, size.height)
                    close()
                }
                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(primary.copy(alpha = 0.24f), primary.copy(alpha = 0.0f))
                    )
                )

                val strokePath = Path().apply {
                    moveTo(coords.first().x, coords.first().y)
                    for (i in 1 until coords.size) {
                        val prev = coords[i - 1]
                        val curr = coords[i]
                        val midX = (prev.x + curr.x) / 2f
                        cubicTo(midX, prev.y, midX, curr.y, curr.x, curr.y)
                    }
                }
                drawPath(
                    path = strokePath,
                    color = primary,
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }

            coords.forEachIndexed { idx, pt ->
                val isSel = selectedIndex == idx
                drawCircle(
                    color = if (isSel) primary else primary.copy(alpha = 0.8f),
                    radius = if (isSel) 7.dp.toPx() else 4.dp.toPx(),
                    center = pt
                )
                if (isSel) {
                    drawCircle(
                        color = primary.copy(alpha = 0.22f),
                        radius = 13.dp.toPx(),
                        center = pt
                    )
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            values.forEachIndexed { idx, (lbl, _) ->
                val sel = selectedIndex == idx
                Text(
                    text = lbl,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (sel) primary else tokens.mutedText,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun PinLockOverlay(
    expectedHash: String,
    onUnlocked: () -> Unit
) {
    var entered by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.Lock,
                    contentDescription = "Himoya",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(30.dp)
                )
            }
            Spacer(Modifier.height(16.dp))
            Text("OvozOS himoyalangan", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(6.dp))
            Text(
                if (error) "Kod noto‘g‘ri. Qaytadan kiriting." else "4 xonali kirish kodini kiriting",
                style = MaterialTheme.typography.bodyMedium,
                color = if (error) MaterialTheme.colorScheme.error else LocalOvozTokens.current.mutedText
            )
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                repeat(4) { i ->
                    val filled = i < entered.length
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(
                                if (filled) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                    )
                }
            }
            Spacer(Modifier.height(32.dp))

            val rows = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("", "0", "del")
            )
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                rows.forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                        row.forEach { key ->
                            if (key.isEmpty()) {
                                Spacer(Modifier.size(68.dp))
                            } else {
                                Surface(
                                    modifier = Modifier
                                        .size(68.dp)
                                        .clip(CircleShape)
                                        .clickable {
                                            error = false
                                            if (key == "del") {
                                                if (entered.isNotEmpty()) entered = entered.dropLast(1)
                                            } else if (entered.length < 4) {
                                                entered += key
                                                if (entered.length == 4) {
                                                    if (Formatters.hashPin(entered) == expectedHash) {
                                                        onUnlocked()
                                                    } else {
                                                        error = true
                                                        entered = ""
                                                    }
                                                }
                                            }
                                        },
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, LocalOvozTokens.current.cardBorder)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        if (key == "del") {
                                            Icon(Icons.Rounded.Backspace, contentDescription = "O‘chirish")
                                        } else {
                                            Text(key, style = MaterialTheme.typography.headlineMedium)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fun sliceColorAt(index: Int): Color = ChartPalette[index % ChartPalette.size]

package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette (OvozOS Design System)
val LightBackground = Color(0xFFF5F6F2)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFECEFE8)
val LightOnBackground = Color(0xFF172421)
val LightOnSurface = Color(0xFF172421)
val LightPrimaryEmerald = Color(0xFF167D69)
val LightPrimaryContainerEmerald = Color(0xFFDDF2E8)
val LightSecondaryText = Color(0xFF6B7773)
val LightMutedGray = Color(0xFF8A9491)
val LightOutline = Color(0xFFDCE3DF)

// Dark Theme Palette (OvozOS Design System)
val DarkBackground = Color(0xFF101715)
val DarkSurface = Color(0xFF1B2622)
val DarkSurfaceVariant = Color(0xFF293A33)
val DarkPrimaryEmerald = Color(0xFF58C6A3)
val DarkPrimaryContainerEmerald = Color(0xFF1E3F34)
val DarkOnBackground = Color(0xFFEDF5F0)
val DarkOnSurface = Color(0xFFEDF5F0)
val DarkSecondaryText = Color(0xFF9BAEA5)
val DarkOutline = Color(0xFF2C3E37)

// Additional Accent Presets
val OceanPrimaryLight = Color(0xFF146C94)
val OceanContainerLight = Color(0xFFDCEFF8)
val OceanPrimaryDark = Color(0xFF58B9E6)
val OceanContainerDark = Color(0xFF1A3848)

val AmberPrimaryLight = Color(0xFFB4651D)
val AmberContainerLight = Color(0xFFFAEBDC)
val AmberPrimaryDark = Color(0xFFEBA85E)
val AmberContainerDark = Color(0xFF3E2D1A)

val VioletPrimaryLight = Color(0xFF5E4BA8)
val VioletContainerLight = Color(0xFFEAE5FA)
val VioletPrimaryDark = Color(0xFFA896F2)
val VioletContainerDark = Color(0xFF2C2547)

// Semantic Finance, Status & Entity Colors
val IncomeGreenLight = Color(0xFF13865D)
val IncomeBgLight = Color(0xFFE0F5EC)
val IncomeGreenDark = Color(0xFF54D2A4)
val IncomeBgDark = Color(0xFF1A3A2E)

val ExpenseCoralLight = Color(0xFFC74B3E)
val ExpenseBgLight = Color(0xFFFDE9E6)
val ExpenseCoralDark = Color(0xFFF07B6E)
val ExpenseBgDark = Color(0xFF3D211E)

val WarningAmberLight = Color(0xFFC27803)
val WarningBgLight = Color(0xFFFEF4DE)
val WarningAmberDark = Color(0xFFF2B84B)
val WarningBgDark = Color(0xFF3C2E14)

val InfoBlueLight = Color(0xFF2563A6)
val InfoBgLight = Color(0xFFE3EFFC)
val InfoBlueDark = Color(0xFF6BA8EC)
val InfoBgDark = Color(0xFF1A2E44)

val DebtPurpleLight = Color(0xFF6A4FB3)
val DebtBgLight = Color(0xFFEEE8FA)
val DebtPurpleDark = Color(0xFFB59DF5)
val DebtBgDark = Color(0xFF2E2347)

// Chart Categorical Palette
val ChartPalette = listOf(
    Color(0xFF167D69),
    Color(0xFF2E86AB),
    Color(0xFFD97736),
    Color(0xFF7B5EA7),
    Color(0xFFC74B3E),
    Color(0xFF4D9E6B),
    Color(0xFF3D6CB9),
    Color(0xFFB8860B)
)

package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.core.AppStrings
import com.example.core.ExpenseCategoriesUz
import com.example.core.Formatters
import com.example.core.guessExpenseCategory
import com.example.data.model.DebtItem
import com.example.data.model.FinanceTransaction
import com.example.data.model.PersonItem
import com.example.data.model.UserProfile
import com.example.ui.components.ChartSlice
import com.example.ui.components.ExpenseBarPoint
import com.example.ui.components.InteractiveDonutChart
import com.example.ui.components.InteractiveExpenseBarChart
import com.example.ui.components.OvozCard
import com.example.ui.components.OvozPrimaryButton
import com.example.ui.components.PersonInitialBadge
import com.example.ui.components.sliceColorAt
import com.example.ui.theme.LocalOvozTokens
import com.example.ui.viewmodel.ReportUiState
import java.util.Calendar
import kotlin.math.roundToInt

@Composable
fun FinanceScreen(
    profile: UserProfile,
    strings: AppStrings,
    expenses: List<FinanceTransaction>,
    debts: List<DebtItem>,
    people: List<PersonItem>,
    insightState: ReportUiState,
    initialTab: String = "expenses",
    bottomBarPadding: Dp = 116.dp,
    onToggleHideAmounts: () -> Unit,
    onAddExpense: (FinanceTransaction) -> Unit,
    onUpdateExpense: (FinanceTransaction, FinanceTransaction) -> Unit,
    onDeleteExpense: (FinanceTransaction) -> Unit,
    onAddDebt: (DebtItem) -> Unit,
    onPayDebt: (DebtItem, Double) -> Unit,
    onDeleteDebt: (DebtItem) -> Unit,
    onGenerateInsight: (String, String) -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    var activeTab by remember { mutableStateOf(initialTab) }
    var selectedCurrency by remember(profile.primaryCurrency) { mutableStateOf(profile.primaryCurrency) }
    var showAddExpense by remember { mutableStateOf(false) }
    var editingExpense by remember { mutableStateOf<FinanceTransaction?>(null) }
    var showAddDebt by remember { mutableStateOf(false) }
    var payingDebt by remember { mutableStateOf<DebtItem?>(null) }

    LaunchedEffect(initialTab) {
        if (initialTab in listOf("expenses", "debts", "analytics")) {
            activeTab = initialTab
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("finance_screen")
    ) {
        // Header: Moliya + Hide amounts + single contextual Add button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = strings.financeTitle,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                IconButton(onClick = onToggleHideAmounts) {
                    Icon(
                        if (profile.hideBalances) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                        contentDescription = "Summalarni yashirish",
                        tint = tokens.mutedText
                    )
                }
                val isDebtTab = activeTab == "debts"
                Button(
                    onClick = { if (isDebtTab) showAddDebt = true else showAddExpense = true },
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag(if (isDebtTab) "finance_add_debt_btn" else "finance_add_expense_btn")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (isDebtTab) "Qarz" else "Xarajat", style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        // Clean 3-tab segmented switch: Xarajatlar | Oldi-berdi | Kuzatuv
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, tokens.cardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(
                    "expenses" to strings.expensesTab,
                    "debts" to strings.debtsTab,
                    "analytics" to strings.analyticsTab
                ).forEach { (key, label) ->
                    val selected = activeTab == key
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (selected) primary else androidx.compose.ui.graphics.Color.Transparent,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { activeTab = key }
                            .testTag("finance_tab_$key")
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selected) MaterialTheme.colorScheme.onPrimary else tokens.mutedText,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        when (activeTab) {
            "expenses" -> ExpensesTabContent(
                expenses = expenses,
                selectedCurrency = selectedCurrency,
                hideAmounts = profile.hideBalances,
                bottomBarPadding = bottomBarPadding,
                onSelectCurrency = { selectedCurrency = it },
                onClickExpense = { editingExpense = it }
            )
            "debts" -> DebtsTabContent(
                strings = strings,
                debts = debts,
                selectedCurrency = selectedCurrency,
                hideAmounts = profile.hideBalances,
                bottomBarPadding = bottomBarPadding,
                onSelectCurrency = { selectedCurrency = it },
                onPayClick = { payingDebt = it },
                onDeleteDebt = onDeleteDebt
            )
            else -> AnalyticsTabContent(
                strings = strings,
                expenses = expenses,
                debts = debts,
                selectedCurrency = selectedCurrency,
                hideAmounts = profile.hideBalances,
                insightState = insightState,
                bottomBarPadding = bottomBarPadding,
                onSelectCurrency = { selectedCurrency = it },
                onGenerateInsight = onGenerateInsight
            )
        }
    }

    if (showAddExpense) {
        ExpenseEditorSheet(
            initial = null,
            defaultCurrency = selectedCurrency,
            people = people,
            onDismiss = { showAddExpense = false },
            onSave = { tx ->
                onAddExpense(tx)
                showAddExpense = false
            }
        )
    }

    editingExpense?.let { exp ->
        ExpenseEditorSheet(
            initial = exp,
            defaultCurrency = exp.currency,
            people = people,
            onDismiss = { editingExpense = null },
            onSave = { updated ->
                onUpdateExpense(exp, updated)
                editingExpense = null
            },
            onDelete = {
                onDeleteExpense(exp)
                editingExpense = null
            }
        )
    }

    if (showAddDebt) {
        AddDebtSheet(
            defaultCurrency = selectedCurrency,
            people = people,
            onDismiss = { showAddDebt = false },
            onSave = { d ->
                onAddDebt(d)
                showAddDebt = false
            }
        )
    }

    payingDebt?.let { debt ->
        DebtPaymentDialog(
            debt = debt,
            onDismiss = { payingDebt = null },
            onConfirm = { amt ->
                onPayDebt(debt, amt)
                payingDebt = null
            }
        )
    }
}

@Composable
private fun ExpensesTabContent(
    expenses: List<FinanceTransaction>,
    selectedCurrency: String,
    hideAmounts: Boolean,
    bottomBarPadding: Dp,
    onSelectCurrency: (String) -> Unit,
    onClickExpense: (FinanceTransaction) -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    var period by remember { mutableStateOf("month") }

    val availableCurrencies = remember(expenses, selectedCurrency) {
        (listOf(selectedCurrency) + expenses.map { it.currency }).distinct()
    }

    val filtered = remember(expenses, selectedCurrency, period) {
        expenses
            .filter { it.currency == selectedCurrency && Formatters.isInPeriod(it.occurredAtMillis, period) }
            .sortedByDescending { it.occurredAtMillis }
    }
    val totalSpent = remember(filtered) { filtered.sumOf { it.amount } }

    Column(modifier = Modifier.fillMaxSize()) {
        // Period selector + currency selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("today" to "Bugun", "week" to "Hafta", "month" to "Oy", "year" to "Yil").forEach { (k, lbl) ->
                    val sel = period == k
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, if (sel) primary else tokens.cardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { period = k }
                    ) {
                        Text(
                            text = lbl,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (sel) primary else tokens.mutedText,
                            fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                            modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp)
                        )
                    }
                }
            }

            if (availableCurrencies.size > 1) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    availableCurrencies.forEach { c ->
                        val sel = c == selectedCurrency
                        Text(
                            text = c,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                            color = if (sel) primary else tokens.mutedText,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onSelectCurrency(c) }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // Period total header (NO balance card, strictly expense sum)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            Column {
                Text(
                    text = when (period) {
                        "today" -> "Bugungi xarajatlar"
                        "week" -> "Shu haftadagi xarajatlar"
                        "year" -> "Shu yilgi xarajatlar"
                        else -> "Shu oydagi xarajatlar"
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = tokens.mutedText
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = if (hideAmounts) "••••••" else Formatters.formatMoney(totalSpent, selectedCurrency),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
            if (filtered.isNotEmpty()) {
                Text(
                    text = "${filtered.size} ta",
                    style = MaterialTheme.typography.labelMedium,
                    color = tokens.mutedText
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        HorizontalDivider(color = tokens.cardBorder, modifier = Modifier.padding(horizontal = 20.dp))

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(bottom = bottomBarPadding),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Xarajatlar yo‘q",
                    style = MaterialTheme.typography.bodyLarge,
                    color = tokens.mutedText
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = bottomBarPadding)
            ) {
                itemsIndexed(filtered, key = { _, tx -> tx.id }) { idx, tx ->
                    val catIndex = ExpenseCategoriesUz.indexOf(tx.category).coerceAtLeast(0)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onClickExpense(tx) }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(sliceColorAt(catIndex))
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = tx.title,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${tx.category} · ${Formatters.formatShortDate(tx.occurredAtMillis)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = tokens.mutedText,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = if (hideAmounts) "•••" else "-${Formatters.formatMoney(tx.amount, tx.currency)}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = tokens.expense
                        )
                    }
                    if (idx < filtered.lastIndex) {
                        HorizontalDivider(color = tokens.cardBorder.copy(alpha = 0.65f))
                    }
                }
            }
        }
    }
}

@Composable
private fun DebtsTabContent(
    strings: AppStrings,
    debts: List<DebtItem>,
    selectedCurrency: String,
    hideAmounts: Boolean,
    bottomBarPadding: Dp,
    onSelectCurrency: (String) -> Unit,
    onPayClick: (DebtItem) -> Unit,
    onDeleteDebt: (DebtItem) -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    var filter by remember { mutableStateOf("active") }

    val availableCurrencies = remember(debts, selectedCurrency) {
        (listOf(selectedCurrency) + debts.map { it.currency }).distinct()
    }
    val currencyDebts = remember(debts, selectedCurrency) {
        debts.filter { it.currency == selectedCurrency }
    }
    val borrowedTotal = remember(currencyDebts) {
        currencyDebts.filter { !it.closed && it.direction == "borrowed" }.sumOf { it.remainingAmount }
    }
    val lentTotal = remember(currencyDebts) {
        currencyDebts.filter { !it.closed && it.direction == "lent" }.sumOf { it.remainingAmount }
    }

    val filtered = remember(debts, filter) {
        when (filter) {
            "borrowed" -> debts.filter { !it.closed && it.direction == "borrowed" }
            "lent" -> debts.filter { !it.closed && it.direction == "lent" }
            "closed" -> debts.filter { it.closed }
            else -> debts.filter { !it.closed }
        }.sortedBy { if (it.dueDateMillis > 0L) it.dueDateMillis else Long.MAX_VALUE }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 2.dp, bottom = bottomBarPadding),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Two clear debt summary indicators
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = tokens.expenseBg,
                    border = BorderStroke(1.dp, tokens.expense.copy(alpha = 0.25f)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = strings.iOwe,
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.expense,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = if (hideAmounts) "•••" else Formatters.formatMoney(borrowedTotal, selectedCurrency),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = tokens.incomeBg,
                    border = BorderStroke(1.dp, tokens.income.copy(alpha = 0.25f)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = strings.owedToMe,
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.income,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = if (hideAmounts) "•••" else Formatters.formatMoney(lentTotal, selectedCurrency),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // Filter pills + currency switch
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
                    items(
                        listOf(
                            "active" to "Faol",
                            "borrowed" to "Men olgan",
                            "lent" to "Men bergan",
                            "closed" to "Yopilgan"
                        )
                    ) { (k, lbl) ->
                        val sel = filter == k
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (sel) primary else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, if (sel) primary else tokens.cardBorder),
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { filter = k }
                        ) {
                            Text(
                                text = lbl,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp)
                            )
                        }
                    }
                }
                if (availableCurrencies.size > 1) {
                    Spacer(Modifier.width(8.dp))
                    availableCurrencies.forEach { c ->
                        val sel = c == selectedCurrency
                        Text(
                            text = c,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                            color = if (sel) primary else tokens.mutedText,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onSelectCurrency(c) }
                                .padding(horizontal = 5.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        if (filtered.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (filter == "closed") "Yopilgan qarzlar yo‘q" else "Qarzlar yo‘q",
                        style = MaterialTheme.typography.bodyLarge,
                        color = tokens.mutedText
                    )
                }
            }
        } else {
            itemsIndexed(filtered, key = { _, d -> d.id }) { idx, debt ->
                val isBorrowed = debt.direction == "borrowed"
                val accent = if (isBorrowed) tokens.expense else tokens.income
                val overdue = !debt.closed && debt.dueDateMillis > 0L && debt.dueDateMillis < System.currentTimeMillis()
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PersonInitialBadge(name = debt.personName, size = 40.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = debt.personName,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val meta = buildList {
                                add(if (isBorrowed) "Men olgan" else "Men bergan")
                                if (debt.dueDateMillis > 0L) add(Formatters.formatShortDate(debt.dueDateMillis))
                                if (debt.closed) add("Yopilgan")
                            }.joinToString(" · ")
                            Text(
                                text = meta,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (overdue) tokens.expense else tokens.mutedText
                            )
                            if (debt.note.isNotBlank()) {
                                Text(
                                    text = debt.note,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = tokens.mutedText,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = if (hideAmounts) "•••" else Formatters.formatMoney(
                                    if (debt.closed) debt.originalAmount else debt.remainingAmount,
                                    debt.currency
                                ),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (debt.closed) tokens.mutedText else accent
                            )
                            if (!debt.closed && debt.paidAmount > 0.0) {
                                Text(
                                    text = "To‘langan: ${Formatters.formatNumber(debt.paidAmount)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = tokens.mutedText
                                )
                            }
                        }
                    }

                    if (!debt.closed && debt.paidAmount > 0.0) {
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = {
                                if (debt.originalAmount > 0.0) {
                                    (debt.paidAmount / debt.originalAmount).toFloat().coerceIn(0f, 1f)
                                } else 0f
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(CircleShape),
                            color = accent,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    }

                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!debt.closed) {
                            TextButton(
                                onClick = { onPayClick(debt) },
                                modifier = Modifier.testTag("debt_pay_btn_${debt.id}")
                            ) {
                                Text("Qaytarish", color = primary, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        IconButton(onClick = { onDeleteDebt(debt) }) {
                            Icon(
                                Icons.Rounded.DeleteOutline,
                                contentDescription = "O‘chirish",
                                tint = tokens.mutedText,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }

                    if (idx < filtered.lastIndex) {
                        HorizontalDivider(color = tokens.cardBorder.copy(alpha = 0.65f))
                    }
                }
            }
        }
    }
}

@Composable
private fun AnalyticsTabContent(
    strings: AppStrings,
    expenses: List<FinanceTransaction>,
    debts: List<DebtItem>,
    selectedCurrency: String,
    hideAmounts: Boolean,
    insightState: ReportUiState,
    bottomBarPadding: Dp,
    onSelectCurrency: (String) -> Unit,
    onGenerateInsight: (String, String) -> Unit
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    var period by remember { mutableStateOf("month") }
    var selectedBar by remember { mutableStateOf<Int?>(null) }
    var selectedSlice by remember { mutableStateOf<String?>(null) }

    val availableCurrencies = remember(expenses, debts, selectedCurrency) {
        (listOf(selectedCurrency) + expenses.map { it.currency } + debts.map { it.currency }).distinct()
    }

    val periodDays = when (period) {
        "week" -> 7L
        "year" -> 365L
        else -> 30L
    }
    val now = System.currentTimeMillis()
    val periodStart = now - periodDays * 86_400_000L
    val prevPeriodStart = periodStart - periodDays * 86_400_000L

    val periodExpenses = remember(expenses, selectedCurrency, period) {
        expenses.filter { it.currency == selectedCurrency && it.occurredAtMillis >= periodStart }
    }
    val prevPeriodExpenses = remember(expenses, selectedCurrency, period) {
        expenses.filter { it.currency == selectedCurrency && it.occurredAtMillis in prevPeriodStart until periodStart }
    }
    val totalCurrent = remember(periodExpenses) { periodExpenses.sumOf { it.amount } }
    val totalPrev = remember(prevPeriodExpenses) { prevPeriodExpenses.sumOf { it.amount } }
    val diffPercent = remember(totalCurrent, totalPrev) {
        if (totalPrev <= 0.0) null else (((totalCurrent - totalPrev) / totalPrev) * 100.0).roundToInt()
    }

    val categorySlices = remember(periodExpenses) {
        periodExpenses
            .groupBy { it.category }
            .entries
            .map { it.key to it.value.sumOf { tx -> tx.amount } }
            .sortedByDescending { it.second }
            .mapIndexed { i, (cat, sum) -> ChartSlice(cat, sum, sliceColorAt(i)) }
    }

    val barPoints = remember(periodExpenses, period) {
        when (period) {
            "week" -> {
                val cal = Calendar.getInstance()
                val dayNames = listOf("Ya", "Du", "Se", "Ch", "Pa", "Ju", "Sh")
                (6 downTo 0).map { back ->
                    val start = Formatters.startOfDay() - back * 86_400_000L
                    val end = start + 86_400_000L - 1L
                    cal.timeInMillis = start
                    val lbl = dayNames[cal.get(Calendar.DAY_OF_WEEK) - 1]
                    val amt = periodExpenses.filter { it.occurredAtMillis in start..end }.sumOf { it.amount }
                    ExpenseBarPoint(lbl, amt)
                }
            }
            "year" -> {
                val months = listOf("Yan", "Fev", "Mar", "Apr", "May", "Iyn", "Iyl", "Avg", "Sen", "Okt", "Noy", "Dek")
                val cal = Calendar.getInstance()
                (5 downTo 0).map { back ->
                    val c = Calendar.getInstance().apply { add(Calendar.MONTH, -back) }
                    val m = c.get(Calendar.MONTH)
                    val y = c.get(Calendar.YEAR)
                    val amt = expenses.filter {
                        if (it.currency != selectedCurrency) return@filter false
                        cal.timeInMillis = it.occurredAtMillis
                        cal.get(Calendar.MONTH) == m && cal.get(Calendar.YEAR) == y
                    }.sumOf { it.amount }
                    ExpenseBarPoint(months[m], amt)
                }
            }
            else -> {
                // 4 weeks of current month
                (3 downTo 0).map { back ->
                    val end = now - back * 7L * 86_400_000L
                    val start = end - 7L * 86_400_000L
                    val amt = periodExpenses.filter { it.occurredAtMillis in start..end }.sumOf { it.amount }
                    ExpenseBarPoint("${4 - back}-h", amt)
                }
            }
        }
    }

    val activeBorrowed = remember(debts, selectedCurrency) {
        debts.filter { !it.closed && it.currency == selectedCurrency && it.direction == "borrowed" }.sumOf { it.remainingAmount }
    }
    val activeLent = remember(debts, selectedCurrency) {
        debts.filter { !it.closed && it.currency == selectedCurrency && it.direction == "lent" }.sumOf { it.remainingAmount }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 2.dp, bottom = bottomBarPadding),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Period & Currency controls
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("week" to "Hafta", "month" to "Oy", "year" to "Yil").forEach { (k, lbl) ->
                        val sel = period == k
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, if (sel) primary else tokens.cardBorder),
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    period = k
                                    selectedBar = null
                                    selectedSlice = null
                                }
                        ) {
                            Text(
                                lbl,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (sel) primary else tokens.mutedText,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                            )
                        }
                    }
                }
                if (availableCurrencies.size > 1) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        availableCurrencies.forEach { c ->
                            val sel = c == selectedCurrency
                            Text(
                                c,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                                color = if (sel) primary else tokens.mutedText,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { onSelectCurrency(c) }
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        if (periodExpenses.isEmpty() && activeBorrowed == 0.0 && activeLent == 0.0) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 56.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Kuzatuv uchun ma’lumot yo‘q",
                        style = MaterialTheme.typography.bodyLarge,
                        color = tokens.mutedText
                    )
                }
            }
        } else {
            // Total Expense + Previous-period comparison
            item {
                OvozCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Davr xarajati",
                            style = MaterialTheme.typography.labelMedium,
                            color = tokens.mutedText
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (hideAmounts) "••••••" else Formatters.formatMoney(totalCurrent, selectedCurrency),
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold
                            )
                            if (diffPercent != null) {
                                val up = diffPercent > 0
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (up) tokens.expenseBg else tokens.incomeBg
                                ) {
                                    Text(
                                        text = "${if (up) "+" else ""}$diffPercent% oldingi davrga nisbatan",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (up) tokens.expense else tokens.income,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                        categorySlices.firstOrNull()?.let { top ->
                            val pct = if (totalCurrent > 0) ((top.value / totalCurrent) * 100).roundToInt() else 0
                            Text(
                                text = "Eng katta turkum: ${top.label} ($pct%)",
                                style = MaterialTheme.typography.bodySmall,
                                color = tokens.mutedText
                            )
                        }
                    }
                }
            }

            // Expenses over time chart (ONLY when expenses exist)
            if (periodExpenses.isNotEmpty()) {
                item {
                    OvozCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Xarajatlar dinamikasi",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                selectedBar?.let { idx ->
                                    barPoints.getOrNull(idx)?.let { pt ->
                                        Text(
                                            text = "${pt.label}: ${if (hideAmounts) "•••" else Formatters.formatMoney(pt.amount, selectedCurrency)}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = primary,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            InteractiveExpenseBarChart(
                                points = barPoints,
                                selectedIndex = selectedBar,
                                onSelectIndex = { selectedBar = it }
                            )
                        }
                    }
                }

                // Category Donut + Breakdown
                item {
                    OvozCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Turkumlar bo‘yicha",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.align(Alignment.Start)
                            )
                            Spacer(Modifier.height(12.dp))
                            val selSliceObj = categorySlices.firstOrNull { it.label == selectedSlice }
                            InteractiveDonutChart(
                                slices = categorySlices,
                                selectedLabel = selectedSlice,
                                onSelectSlice = { selectedSlice = it },
                                centerTitle = if (hideAmounts) "•••" else Formatters.formatNumber(selSliceObj?.value ?: totalCurrent),
                                centerSubtitle = selSliceObj?.label ?: selectedCurrency
                            )
                            Spacer(Modifier.height(14.dp))
                            categorySlices.forEachIndexed { idx, slice ->
                                val pct = if (totalCurrent > 0) ((slice.value / totalCurrent) * 100).roundToInt() else 0
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedSlice = if (selectedSlice == slice.label) null else slice.label }
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(slice.color)
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Text(
                                        text = slice.label,
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = "$pct%",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = tokens.mutedText
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Text(
                                        text = if (hideAmounts) "•••" else Formatters.formatMoney(slice.value, selectedCurrency),
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                if (idx < categorySlices.lastIndex) {
                                    HorizontalDivider(color = tokens.cardBorder.copy(alpha = 0.5f))
                                }
                            }
                        }
                    }
                }
            }

            // Debts status summary
            if (activeBorrowed > 0.0 || activeLent > 0.0) {
                item {
                    OvozCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "Qarzlar holati",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(strings.iOwe, style = MaterialTheme.typography.bodyMedium, color = tokens.mutedText)
                                Text(
                                    if (hideAmounts) "•••" else Formatters.formatMoney(activeBorrowed, selectedCurrency),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = tokens.expense,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(strings.owedToMe, style = MaterialTheme.typography.bodyMedium, color = tokens.mutedText)
                                Text(
                                    if (hideAmounts) "•••" else Formatters.formatMoney(activeLent, selectedCurrency),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = tokens.income,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            // On-demand Gemini concise financial insight
            item {
                OvozCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Rounded.AutoAwesome,
                                    contentDescription = null,
                                    tint = primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = "Qisqa AI tahlil",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            TextButton(
                                onClick = { onGenerateInsight(period, selectedCurrency) },
                                enabled = !insightState.isGenerating
                            ) {
                                Text(if (insightState.aiSummary.isBlank()) "Tahlil qilish" else "Yangilash")
                            }
                        }

                        if (insightState.isGenerating) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Text("Tahlil qilinmoqda...", style = MaterialTheme.typography.bodySmall, color = tokens.mutedText)
                            }
                        } else if (insightState.error.isNotBlank()) {
                            Text(insightState.error, style = MaterialTheme.typography.bodySmall, color = tokens.expense)
                        } else if (insightState.aiSummary.isNotBlank()) {
                            Text(insightState.aiSummary, style = MaterialTheme.typography.bodyMedium)
                            if (insightState.aiAdvice.isNotBlank()) {
                                Text(
                                    insightState.aiAdvice,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpenseEditorSheet(
    initial: FinanceTransaction?,
    defaultCurrency: String,
    people: List<PersonItem>,
    onDismiss: () -> Unit,
    onSave: (FinanceTransaction) -> Unit,
    onDelete: (() -> Unit)? = null
) {
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    var amountText by remember { mutableStateOf(if (initial != null && initial.amount > 0) initial.amount.toLong().toString() else "") }
    var currency by remember { mutableStateOf(initial?.currency ?: defaultCurrency) }
    var title by remember { mutableStateOf(initial?.title.orEmpty()) }
    var category by remember { mutableStateOf(initial?.category ?: ExpenseCategoriesUz.first()) }
    var userPickedCategory by remember { mutableStateOf(initial != null) }
    var occurredAt by remember { mutableLongStateOf(initial?.occurredAtMillis ?: System.currentTimeMillis()) }
    var personName by remember { mutableStateOf(initial?.personName.orEmpty()) }
    var note by remember { mutableStateOf(initial?.note.orEmpty()) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (initial == null) "Yangi xarajat" else "Xarajatni tahrirlash",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                if (onDelete != null) {
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Rounded.DeleteOutline, contentDescription = "O‘chirish", tint = tokens.expense)
                    }
                }
            }

            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                label = { Text("Summa") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("expense_amount_input")
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("UZS", "USD", "EUR", "RUB").forEach { c ->
                    val sel = currency == c
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (sel) primary else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, if (sel) primary else tokens.cardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { currency = c }
                    ) {
                        Text(
                            c,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }
                }
            }

            OutlinedTextField(
                value = title,
                onValueChange = { newTitle ->
                    title = newTitle
                    if (!userPickedCategory && newTitle.length >= 2) {
                        category = guessExpenseCategory(newTitle)
                    }
                },
                label = { Text("Nima uchun") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("expense_title_input")
            )

            Text("Turkum", style = MaterialTheme.typography.labelMedium, color = tokens.mutedText)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ExpenseCategoriesUz) { cat ->
                    val sel = category == cat
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, if (sel) primary else tokens.cardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                category = cat
                                userPickedCategory = true
                            }
                    ) {
                        Text(
                            cat,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (sel) primary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val isToday = Formatters.isToday(occurredAt)
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isToday) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, if (isToday) primary else tokens.cardBorder),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { occurredAt = System.currentTimeMillis() }
                ) {
                    Text(
                        "Bugun",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isToday) primary else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (!isToday) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, if (!isToday) primary else tokens.cardBorder),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { occurredAt = System.currentTimeMillis() - 86_400_000L }
                ) {
                    Text(
                        "Kecha",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (!isToday) primary else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                    )
                }
            }

            OutlinedTextField(
                value = personName,
                onValueChange = { personName = it },
                label = { Text("Inson (ixtiyoriy)") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Izoh (ixtiyoriy)") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            val parsedAmt = amountText.toDoubleOrNull() ?: 0.0
            OvozPrimaryButton(
                text = "Saqlash",
                enabled = parsedAmt > 0.0,
                onClick = {
                    val matchedPerson = people.firstOrNull { it.name.equals(personName.trim(), ignoreCase = true) }
                    onSave(
                        (initial ?: FinanceTransaction()).copy(
                            kind = "expense",
                            amount = parsedAmt,
                            currency = currency,
                            category = category,
                            title = title.trim().ifEmpty { category },
                            note = note.trim(),
                            occurredAtMillis = occurredAt,
                            personId = matchedPerson?.id.orEmpty(),
                            personName = personName.trim()
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("expense_save_button")
            )
            Spacer(Modifier.height(12.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddDebtSheet(
    defaultCurrency: String,
    people: List<PersonItem>,
    onDismiss: () -> Unit,
    onSave: (DebtItem) -> Unit
) {
    val context = LocalContext.current
    val tokens = LocalOvozTokens.current
    val primary = MaterialTheme.colorScheme.primary
    var direction by remember { mutableStateOf("borrowed") }
    var personName by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf(defaultCurrency) }
    var dueDateMillis by remember { mutableLongStateOf(0L) }
    var note by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Yangi qarz", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("borrowed" to "Men oldim", "lent" to "Men berdim").forEach { (dir, lbl) ->
                    val sel = direction == dir
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (sel) primary else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, if (sel) primary else tokens.cardBorder),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { direction = dir }
                    ) {
                        Box(modifier = Modifier.padding(vertical = 11.dp), contentAlignment = Alignment.Center) {
                            Text(
                                lbl,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            OutlinedTextField(
                value = personName,
                onValueChange = { personName = it },
                label = { Text("Kim bilan") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("debt_person_input")
            )
            if (people.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(people.take(8)) { p ->
                        TextButton(onClick = { personName = p.name }) {
                            Text(p.name, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                label = { Text("Summa") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("debt_amount_input")
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("UZS", "USD", "EUR", "RUB").forEach { c ->
                    val sel = currency == c
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (sel) primary else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, if (sel) primary else tokens.cardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { currency = c }
                    ) {
                        Text(
                            c,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }
                }
            }

            OutlinedButton(
                onClick = {
                    val cal = Calendar.getInstance().apply {
                        if (dueDateMillis > 0L) timeInMillis = dueDateMillis
                    }
                    DatePickerDialog(
                        context,
                        { _, y, m, d ->
                            dueDateMillis = Calendar.getInstance().apply { set(y, m, d, 12, 0, 0) }.timeInMillis
                        },
                        cal.get(Calendar.YEAR),
                        cal.get(Calendar.MONTH),
                        cal.get(Calendar.DAY_OF_MONTH)
                    ).show()
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(if (dueDateMillis > 0L) "Qaytarish sanasi: ${Formatters.formatShortDate(dueDateMillis)}" else "Qaytarish sanasi (ixtiyoriy)")
            }

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Izoh (ixtiyoriy)") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            val amt = amountText.toDoubleOrNull() ?: 0.0
            OvozPrimaryButton(
                text = "Saqlash",
                enabled = personName.isNotBlank() && amt > 0.0,
                onClick = {
                    onSave(
                        DebtItem(
                            direction = direction,
                            personName = personName.trim(),
                            originalAmount = amt,
                            paidAmount = 0.0,
                            currency = currency,
                            note = note.trim(),
                            issuedAtMillis = System.currentTimeMillis(),
                            dueDateMillis = dueDateMillis
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("debt_save_button")
            )
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
fun DebtPaymentDialog(
    debt: DebtItem,
    onDismiss: () -> Unit,
    onConfirm: (Double) -> Unit
) {
    var payText by remember { mutableStateOf(debt.remainingAmount.toLong().toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${debt.personName} — to‘lov") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Qolgan summa: ${Formatters.formatMoney(debt.remainingAmount, debt.currency)}",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = payText,
                    onValueChange = { payText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("To‘lov summasi (${debt.currency})") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { payText = (debt.remainingAmount / 2.0).toLong().coerceAtLeast(1L).toString() }) {
                        Text("Yarmini")
                    }
                    TextButton(onClick = { payText = debt.remainingAmount.toLong().toString() }) {
                        Text("To‘liq")
                    }
                }
            }
        },
        confirmButton = {
            val amt = payText.toDoubleOrNull() ?: 0.0
            TextButton(
                enabled = amt > 0.0,
                onClick = { onConfirm(amt) }
            ) {
                Text("Tasdiqlash", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Bekor qilish") }
        }
    )
}

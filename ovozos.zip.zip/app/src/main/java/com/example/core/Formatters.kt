package com.example.core

import java.security.MessageDigest
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Formatters {

    private val uzWeekdays = arrayOf(
        "Yakshanba", "Dushanba", "Seshanba", "Chorshanba",
        "Payshanba", "Juma", "Shanba"
    )

    private val ruWeekdays = arrayOf(
        "Воскресенье", "Понедельник", "Вторник", "Среда",
        "Четверг", "Пятница", "Суббота"
    )

    private val enWeekdays = arrayOf(
        "Sunday", "Monday", "Tuesday", "Wednesday",
        "Thursday", "Friday", "Saturday"
    )

    private val uzMonths = arrayOf(
        "yanvar", "fevral", "mart", "aprel", "may", "iyun",
        "iyul", "avgust", "sentyabr", "oktyabr", "noyabr", "dekabr"
    )

    private val ruMonths = arrayOf(
        "января", "февраля", "марта", "апреля", "мая", "июня",
        "июля", "августа", "сентября", "октября", "ноября", "декабря"
    )

    private val enMonths = arrayOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )

    fun formatMoney(
        amount: Double,
        currency: String,
        hidden: Boolean = false,
        showSign: Boolean = false
    ): String {
        if (hidden) return "••••••"
        val symbols = DecimalFormatSymbols(Locale.US).apply {
            groupingSeparator = ' '
            decimalSeparator = '.'
        }
        val isWhole = amount % 1.0 == 0.0
        val pattern = if (isWhole || currency == "UZS") "#,##0" else "#,##0.##"
        val formatted = DecimalFormat(pattern, symbols).format(kotlin.math.abs(amount))
        val sign = when {
            amount < 0 -> "−"
            showSign && amount > 0 -> "+"
            else -> ""
        }
        return when (currency.uppercase(Locale.US)) {
            "USD" -> "$sign$$formatted"
            "EUR" -> "$sign€$formatted"
            "RUB" -> "$sign$formatted ₽"
            else -> "$sign$formatted so‘m"
        }
    }

    fun formatNumber(value: Double): String {
        val symbols = DecimalFormatSymbols(Locale.US).apply {
            groupingSeparator = ' '
            decimalSeparator = '.'
        }
        val pattern = if (value % 1.0 == 0.0) "#,##0" else "#,##0.#"
        return DecimalFormat(pattern, symbols).format(value)
    }

    fun formatFullDateHeader(millis: Long = System.currentTimeMillis(), lang: String = "uz"): String {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val monthIdx = cal.get(Calendar.MONTH)
        val dowIdx = cal.get(Calendar.DAY_OF_WEEK) - 1
        return when (lang) {
            "ru" -> "${ruWeekdays[dowIdx]}, $day ${ruMonths[monthIdx]}"
            "en" -> "${enWeekdays[dowIdx]}, ${enMonths[monthIdx]} $day"
            else -> "${uzWeekdays[dowIdx]}, $day-${uzMonths[monthIdx]}"
        }
    }

    fun formatShortDate(millis: Long, pattern: String = "dd.MM.yyyy", lang: String = "uz"): String {
        if (millis <= 0L) return ""
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        return when (pattern) {
            "yyyy-MM-dd" -> SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(millis))
            "d MMM" -> {
                val day = cal.get(Calendar.DAY_OF_MONTH)
                val m = cal.get(Calendar.MONTH)
                when (lang) {
                    "ru" -> "$day ${ruMonths[m].take(3)}"
                    "en" -> "${enMonths[m].take(3)} $day"
                    else -> "$day-${uzMonths[m].take(3)}"
                }
            }
            else -> SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date(millis))
        }
    }

    fun formatTime24(millis: Long): String {
        if (millis <= 0L) return ""
        return SimpleDateFormat("HH:mm", Locale.US).format(Date(millis))
    }

    fun formatDateTime24(millis: Long, pattern: String = "dd.MM.yyyy", lang: String = "uz"): String {
        if (millis <= 0L) return ""
        return "${formatShortDate(millis, pattern, lang)}, ${formatTime24(millis)}"
    }

    fun dateKeyFor(millis: Long = System.currentTimeMillis()): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(millis))
    }

    fun startOfDay(millis: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = millis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return cal.timeInMillis
    }

    fun endOfDay(millis: Long = System.currentTimeMillis()): Long {
        return startOfDay(millis) + 86_400_000L - 1L
    }

    fun isSameDay(a: Long, b: Long): Boolean {
        if (a <= 0L || b <= 0L) return false
        return startOfDay(a) == startOfDay(b)
    }

    fun isToday(millis: Long): Boolean = isSameDay(millis, System.currentTimeMillis())

    fun isTomorrow(millis: Long): Boolean {
        val tomorrow = startOfDay() + 86_400_000L
        return isSameDay(millis, tomorrow)
    }

    fun isThisWeek(millis: Long): Boolean {
        if (millis <= 0L) return false
        val start = startOfDay()
        val end = start + 7L * 86_400_000L - 1L
        return millis in start..end
    }

    fun isOverdue(millis: Long, completed: Boolean): Boolean {
        if (completed || millis <= 0L) return false
        return millis < startOfDay()
    }

    fun daysRemaining(deadlineMillis: Long): Int? {
        if (deadlineMillis <= 0L) return null
        val diff = startOfDay(deadlineMillis) - startOfDay()
        return (diff / 86_400_000L).toInt()
    }

    fun isInPeriod(millis: Long, period: String, nowMillis: Long = System.currentTimeMillis()): Boolean {
        if (millis <= 0L) return false
        val start = when (period) {
            "day" -> startOfDay(nowMillis)
            "week" -> startOfDay(nowMillis) - 6L * 86_400_000L
            "year" -> startOfDay(nowMillis) - 364L * 86_400_000L
            else -> startOfDay(nowMillis) - 29L * 86_400_000L // month
        }
        return millis >= start && millis <= endOfDay(nowMillis)
    }

    fun greetingForHour(name: String, lang: String = "uz"): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val firstName = name.trim().split(Regex("\\s+")).firstOrNull().orEmpty()
        val suffix = if (firstName.isNotEmpty()) ", $firstName" else ""
        return when (lang) {
            "ru" -> when (hour) {
                in 5..11 -> "Доброе утро$suffix"
                in 12..17 -> "Добрый день$suffix"
                in 18..22 -> "Добрый вечер$suffix"
                else -> "Доброй ночи$suffix"
            }
            "en" -> when (hour) {
                in 5..11 -> "Good morning$suffix"
                in 12..17 -> "Good afternoon$suffix"
                in 18..22 -> "Good evening$suffix"
                else -> "Good night$suffix"
            }
            else -> when (hour) {
                in 5..11 -> "Xayrli tong$suffix"
                in 12..17 -> "Xayrli kun$suffix"
                in 18..22 -> "Xayrli kech$suffix"
                else -> "Xayrli tun$suffix"
            }
        }
    }

    fun initialsFor(name: String): String {
        val parts = name.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        return when {
            parts.isEmpty() -> "?"
            parts.size == 1 -> parts[0].take(2).uppercase(Locale.US)
            else -> "${parts[0].first()}${parts[1].first()}".uppercase(Locale.US)
        }
    }

    fun hashPin(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}

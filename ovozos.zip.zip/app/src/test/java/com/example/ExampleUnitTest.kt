package com.example

import com.example.core.Formatters
import com.example.core.guessExpenseCategory
import com.example.data.model.DebtItem
import com.example.data.model.FinanceTransaction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun greetingUsesFirstNameOnly() {
        val greeting = Formatters.greetingForHour("Tohirjon Ergashev", "uz")
        assertTrue(greeting.endsWith(", Tohirjon"))
        assertFalse(greeting.contains("Ergashev"))
    }

    @Test
    fun periodFilteringWorksAcrossDayWeekMonthYear() {
        val now = System.currentTimeMillis()
        val twoDaysAgo = now - 2L * 86_400_000L
        val tenDaysAgo = now - 10L * 86_400_000L
        val hundredDaysAgo = now - 100L * 86_400_000L

        assertTrue(Formatters.isInPeriod(now, "day", now))
        assertFalse(Formatters.isInPeriod(twoDaysAgo, "day", now))
        assertTrue(Formatters.isInPeriod(twoDaysAgo, "week", now))
        assertFalse(Formatters.isInPeriod(tenDaysAgo, "week", now))
        assertTrue(Formatters.isInPeriod(tenDaysAgo, "month", now))
        assertFalse(Formatters.isInPeriod(hundredDaysAgo, "month", now))
        assertTrue(Formatters.isInPeriod(hundredDaysAgo, "year", now))
    }

    @Test
    fun expenseCategoryAutoDetectionWorksForUzbekTerms() {
        assertEquals("Oziq-ovqat", guessExpenseCategory("Tushlik uchun 60 ming"))
        assertEquals("Transport", guessExpenseCategory("Yandex taksi"))
        assertEquals("Sog‘liq", guessExpenseCategory("Dorixona dori"))
        assertEquals("Boshqa", guessExpenseCategory("Noma’lum to‘lov"))
    }

    @Test
    fun debtRemainingAndExpenseFilteringStaySeparate() {
        val debt = DebtItem(
            id = "d1",
            personName = "Anvar",
            direction = "borrowed",
            originalAmount = 500_000.0,
            paidAmount = 150_000.0,
            currency = "UZS",
            closed = false
        )
        assertEquals(350_000.0, debt.remainingAmount, 0.01)

        val rawTransactions = listOf(
            FinanceTransaction(id = "t1", kind = "expense", amount = 60_000.0, title = "Tushlik"),
            FinanceTransaction(id = "t2", kind = "income", amount = 1_000_000.0, title = "Oylik"),
            FinanceTransaction(id = "t3", kind = "debt_payment", amount = 150_000.0, title = "Anvar")
        )
        val expensesOnly = rawTransactions.filter { it.kind == "expense" }
        assertEquals(1, expensesOnly.size)
        assertEquals("t1", expensesOnly.first().id)
    }
}
